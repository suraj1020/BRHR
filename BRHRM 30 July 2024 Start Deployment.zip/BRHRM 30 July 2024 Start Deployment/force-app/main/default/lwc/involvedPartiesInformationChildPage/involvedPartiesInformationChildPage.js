import { LightningElement, track, api, wire } from 'lwc';
import { gql, graphql } from "lightning/uiGraphQLApi";
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { loadStyle } from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/Colors'
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { refreshApex } from '@salesforce/apex';
import IncidentUser_Object from '@salesforce/schema/Involved_Party__c';
import RelationtoBakerRipley_Field from '@salesforce/schema/Involved_Party__c.Relation_to_BakerRipley__c';
import NonEmployee_Field from '@salesforce/schema/Involved_Party__c.Non_Employee_Type__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
import getRolePicklist from '@salesforce/apex/CaseCreation.getRolePicklist';
import { reduceErrors } from 'c/lwcUtility';

export default class InvolvedPartiesInformationChildPage extends LightningElement {
    @api courseData = [];
    actions = [
        { label: 'Edit', name: 'edit' },
        { label: 'Delete', name: 'delete' },
    ];
    @track columnsList = [{
        label: "Name", fieldName: "Name", cellAttributes: {
            class: { fieldName: 'accountColor' }, alignment: 'center'
        }
    },
    {
        label: "Role", fieldName: "Member_Role__c", cellAttributes: {
            class: { fieldName: 'amountColor' },
            iconName: { fieldName: 'iconName' }, iconPosition: 'right', alignment: 'center'
        }
    },
    {
        label: "Relation to BakerRipley", fieldName: "Relation_to_BakerRipley__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    {
        label: "Primary Contact", fieldName: "IsPrimary__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    {
        label: "Description", fieldName: "DescriptionLong__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    { 
        type : 'action', initialWidth:100,
        typeAttributes:{rowActions:this.actions},
        cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    ];
    // {
    //     label: 'Action',
    //     type: 'button-icon',
    //     typeAttributes: {
    //         iconName: 'action:delete',
    //         title: 'Delete',
    //         variant: 'border-filled',
    //         rowActions: actions,
    //         alternativeText: 'Delete'
    //     },
    //     cellAttributes: {
    //         class: { fieldName: 'industryColor' }, alignment: 'center'
    //     }
    // }

    @api incidentMemberList = [];
    @track dataList = [];
    isCssLoaded = false;
    @api currentPage;
    @api recordTypeName;
    @api caseObj = {};
    isLoaded = true;
    @api damageData = [];

    @track relationToBakerRipleyoptions = [];
    @track MemberRoleoptions = [];
    @track nonEmployeeOptions = [];
    @api incidentUserObj = {};
    checkAddParticipant = false;
    checkEmp = false;
    checkNonEmp = false;
    showDataTable = false;
    selectedUserID;
    @track recordIds;
    @track records;
    @track errors;
    showrole = false;
    emailRegex = "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/";
    @api injuryData = [];
    patter = "/^\d{10}$/";
    @wire(getObjectInfo, { objectApiName: IncidentUser_Object })
    objectInfo;
    @track learningAndDevelopmentCheck = false;
    isEdit = false
    isPrimaryValue;
    isEditPrimary = false

    @wire(getPicklistValues, { recordTypeId: "$objectInfo.data.defaultRecordTypeId", fieldApiName: RelationtoBakerRipley_Field })
    relationtoBakerRipleyPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.relationToBakerRipleyoptions = [...this.relationToBakerRipleyoptions, { value: val.value, label: val.label }];
            });
            console.log('this.relationToBakerRipleyoptions--> ' + JSON.stringify(this.relationToBakerRipleyoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    @wire(getPicklistValues, { recordTypeId: "$objectInfo.data.defaultRecordTypeId", fieldApiName: NonEmployee_Field })
    nonEmployeePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.nonEmployeeOptions = [...this.nonEmployeeOptions, { value: val.value, label: val.label }];
            });
            console.log('this.MemberRoleoptions--> ' + JSON.stringify(this.nonEmployeeOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }



    handleAddParticipants() {
        this.incidentUserObj = {};
        this.checkAddParticipant = true;
        this.checkEmp = false;
        this.checkNonEmp = false;
        this.isEdit = false;
    }


    connectedCallback() {
        let obj1 = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj1;
        console.log('120-->' + JSON.stringify(this.caseObj));
        console.log('107-->' + JSON.stringify(this.incidentMemberList));
        let dataList = JSON.parse(JSON.stringify(this.incidentMemberList));
        this.dataList = dataList;
        let counter = 1;
        getRolePicklist({
            recordTypeName: this.recordTypeName,
            pcType: this.caseObj.P_C_Type__c
        })
            .then(result => {
                if(result.length > 0){
                result.forEach(val => {
                    this.MemberRoleoptions = [...this.MemberRoleoptions, { value: val.value, label: val.label }];
                    this.showrole = true;
                });
                }
                else {
                    this.showrole = false;
                }
            }).catch(error => {
                this.displayMessage("Error", "error", reduceErrors(error).toString());
                this.isLoaded = true;
            })
        this.dataList.forEach(el => {
            if (el.hasOwnProperty('External_User_Name__c')) {
                el.Name = el.External_User_Name__c;
            } else {
                if (el.hasOwnProperty('Incident_Member__r')) {
                    console.log('Yes')
                    el.Name = el.Incident_Member__r.Name;
                }
            }
            el.rowId = counter;
            counter++;
        })
        console.log('this.dataList', JSON.stringify(this.dataList));
        let obj = JSON.parse(JSON.stringify(this.incidentUserObj));
        this.incidentUserObj = obj;
        if (this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(() => {
            console.log("Loaded Successfully")
        }).catch(error => {
            console.error("Error in loading the colors")
        })

        if (this.dataList.length > 0) {
            this.showDataTable = true;
        }
        else {
            this.showDataTable = false;
        }

        if (this.caseObj.P_C_Type__c == "Training and Development") {
            this.learningAndDevelopmentCheck = true;
        }

        if(this.caseObj.P_C_Type__c == 'Accommodation' || this.caseObj.P_C_Type__c == 'Benefits' || this.caseObj.P_C_Type__c == 'Compensation' || this.caseObj.P_C_Type__c == 'Employee Management' || this.caseObj.P_C_Type__c == 'P&C General Inquires' || this.caseObj.P_C_Type__c == 'HR Information System') {
            this.columnsList = this.columnsList.filter((each) => each.fieldName != 'Member_Role__c')
        }
        console.log('columnsList------183------> ' , JSON.stringify(this.columnsList))

    }

    handlePicker(event) {
        this.recordIds = event.detail.recordId;
        console.log('asasasa122s' + event.detail.recordId);
        console.log('asasa' + this.recordIds);
        this.incidentUserObj[event.target.name] = event.detail.recordId;
    }


    handleChange(event) {
        console.log('asasasas' + JSON.stringify(event.target.value));
        console.log('--126-->' + JSON.stringify(this.dataList));

        this.incidentUserObj[event.target.name] = event.target.value;
        if (event.target.name == 'IsPrimary__c') {
            if(!this.isEdit) {
                this.incidentUserObj.IsPrimary__c = event.target.checked;
                this.isEditPrimary = false
            } else {
                this.isPrimaryValue = event.target.checked
                this.incidentUserObj.IsPrimary__c = false
                this.isEditPrimary = true
            }
            
        }
        if (event.target.name == 'External_User_Name__c') {
            this.incidentUserObj.Name = event.target.value;
        }
        if (event.target.name == 'Relation_to_BakerRipley__c') {
            console.log('aaaaa');
            // if (event.target.value == 'Non-Employee') {
            //     console.log('Non Employee selected');
            //     this.checkEmp = false;
            //     this.checkNonEmp = true;
            // }

            if (event.target.value == 'Employee') {
                console.log('employee selected');
                this.checkNonEmp = false;
                this.checkEmp = true;
            }
            else {
                this.checkEmp = false;
                this.checkNonEmp = true;
            }
        }
        console.log('this.datalist--> ' + JSON.stringify(this.dataList));
    }

    handleCancel() {
        console.log('inside handleCancel');
        this.checkAddParticipant = false;
    }

    @wire(graphql, {
        query: gql`
      query bigAccounts($recordIds: ID) {
        uiapi {
          query {
            User(where: { Id: { eq: $recordIds } }, first: 1) {
              edges {
                node {
                  Id                  
                  Name {
                    value
                  }
                }
              }
            }
          }
        }
      }
    `,
        variables: "$variables",
    })
    graphqlQueryResult({ data, errors }) {
        if (data) {
            console.log('Line 175');
            let userRecord = data.uiapi.query.User.edges.map((edge) => edge.node);
            console.log('====>' + JSON.stringify(userRecord));
            console.log('--175====>' + userRecord[0].Name.value);
            this.incidentUserObj.Name = userRecord[0].Name.value;

        }
        this.errors = errors;
    }

    get variables() {
        return {
            recordIds: this.recordIds,
        };
    }

    handleSave() {
        let allValid = true;
        let allCBValid = true;
        let lrpValid = true;
        let roleValid = true;
        if (this.incidentUserObj.Relation_to_BakerRipley__c == 'Employee') {
            lrpValid = false;
            roleValid = false;
            lrpValid = [...this.template.querySelectorAll("lightning-record-picker")].reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);

            console.log('roleValid--220->' + roleValid);
            roleValid = [...this.template.querySelectorAll(".validRole")].reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);
            console.log('roleValid--225->' + roleValid);
        }
        else {
            allValid = false;
            allCBValid = false;

            var emailVal = this.template.querySelector(".email")
            console.log('yhan pe kya aa rha h--->>>> ' , emailVal.required)
            if(emailVal.value != '' && emailVal.value != "") {
                if(this.validateEmail(emailVal.value)) {
                    allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
                    allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
                } else {
                    this.displayMessage("Add Email!", "error", "Please add email in correct format. ex: abc@example.com")
                }
            } else {
                allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
                    allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
            }
            
        }
        let isPrimary = false;
        if (this.dataList.length > 0) {
            this.dataList.forEach(el => {
                if (el.IsPrimary__c) {
                    isPrimary = true;
                }
            })
        }
        let primary = true;
        if (this.incidentUserObj.IsPrimary__c && isPrimary) {
            primary = false;
            this.displayMessage("Error!!", "error", "Only One Involved Party can be primary.");
        }

        if (allValid && allCBValid && lrpValid && roleValid && primary) {
            console.log('inside handleSave');
            var randomId = Math.random().toString(16).slice(2);
            this.incidentUserObj['userId'] = this.selectedUserID;
            this.dataList.push(this.incidentUserObj);
            try {
                console.log('number:::', this.dataList.length);
            } catch (ex) {
                console.log('catch:::' + ex);
            }
            this.dataList = [...this.dataList];
            this.handleCancel();
            console.log('zxzxz');
            console.log('number:::', this.dataList.length);
            if (this.dataList.length > 0) {
                let counter = 1;
                this.dataList.forEach(el => {
                    el.rowId = counter;
                    counter++;
                })
                this.showDataTable = true;
            }
        }
        console.log('datalist11 on save--::' + JSON.stringify(this.dataList));

        //this.dataList.length = 0;
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    @api handleNext() {
        console.log('@@----in the next for save & next..........')
        if (this.dataList.length > 0) {
            let isPrimary = false;
            this.dataList.forEach(el => {
                if (el.IsPrimary__c) {
                    isPrimary = true;
                }
            })
            if (isPrimary) {
                this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.dataList }));
            }
            else {
                this.displayMessage("Error!!", "error", "Add at least one involved party's as a Primary Member.");
            }
        } else {
            this.displayMessage("Please check your entries.", "error", "Please add at least one party’s record to proceed");
        }
    }

    @api handlePrevious() {
        this.dispatchEvent(new CustomEvent('previousclick', { detail: this.dataList }));
    }

    handleRowAction(event) {
        const action = event.detail.action;
        const rowss = event.detail.row;

        switch (action.name) {
            case 'edit':
                this.isEdit = true
                this.isEditPrimary = false
                if (rowss.Relation_to_BakerRipley__c == 'Employee') {
                    this.checkNonEmp = false;
                    this.checkEmp = true;
                }
                else {
                    this.checkEmp = false;
                    this.checkNonEmp = true;
                }
                this.incidentUserObj = rowss
                console.log('@in edit row id----> ' , JSON.stringify(this.dataList)) 
                break;
            case 'delete':
                this.dataList = this.dataList?.filter(data => data.rowId !== event.detail.row.rowId);
                console.log('Inside rowAction');
                const row = event.detail.row.rowId;
                if (this.dataList.length < 1) {
                    this.showDataTable = false;
                }
                break;
        }
    }

    handleEditSave() {
        let allValid = true;
        let allCBValid = true;
        let lrpValid = true;
        let roleValid = true;
        if (this.incidentUserObj.Relation_to_BakerRipley__c == 'Employee') {
            lrpValid = false;
            roleValid = false;
            lrpValid = [...this.template.querySelectorAll("lightning-record-picker")].reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);

            roleValid = [...this.template.querySelectorAll(".validRole")].reduce((validSoFar, inputCmp) => {
                inputCmp.reportValidity();
                return validSoFar && inputCmp.checkValidity();
            }, true);
        }
        else {
            allValid = false;
            allCBValid = false;

            var emailVal = this.template.querySelector(".email")
            console.log('yhan pe kya aa rha h--->>>> ' , emailVal.required)
            if(emailVal.value != '' && emailVal.value != "") {
                if(this.validateEmail(emailVal.value)) {
                    allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
                    allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
                } else {
                    this.displayMessage("Add Email!", "error", "Please add email in correct format. ex: abc@example.com")
                }
            } else {
                allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
                    allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
                        inputCmp.reportValidity();
                        return validSoFar && inputCmp.checkValidity();
                    }, true);
            }
            
        }
        console.log('line 487 data list----> ' , JSON.stringify(this.dataList))
        let primary = true;
        let isPrimary = false
        if(this.isEditPrimary) {
            this.dataList.forEach(el => {
                console.log('each data---> ' , el.IsPrimary__c)
                if (el.IsPrimary__c) {
                    isPrimary = true;
                }
            })
            if (this.isPrimaryValue && isPrimary) {
                primary = false;
                this.displayMessage("Error!!", "error", "Only One Involved Party can be primary.");
            }
        }
        

        if (allValid && allCBValid && lrpValid && roleValid && primary) {
            console.log('inside handleSaveEdit');
            this.incidentUserObj['userId'] = this.selectedUserID;
            if(this.isEditPrimary) {
                this.incidentUserObj.IsPrimary__c = this.isPrimaryValue
            }
            const i = this.dataList.findIndex(x => x.rowId === this.incidentUserObj.rowId)
            this.dataList[i] = this.incidentUserObj
            this.dataList.map(obj => this.incidentUserObj.rowId === obj.rowId || obj);
            this.dataList = [...this.dataList];
            console.log('dataList length:::', this.dataList.length);
            console.log('in edit data----> ' , JSON.stringify(this.dataList))
            console.log('isPrimary val=------> ',  isPrimary)
            if (this.dataList.length > 0) {
                this.showDataTable = true;
                this.isEdit = false;
                this.isEditPrimary = false
                return refreshApex(this.dataList);
            }
        }
    }

    handleEditCancle() {
        this.isEdit = false
        this.showDataTable = true
        this.isEditPrimary = false
    }

    handleAccountSelection(event) {
        this.selectedUserID = event.detail.Id;
        console.log("the selected record id is" + event.detail);
        console.log("selectedUserID" + this.selectedUserID);
        console.log("selectedName--> " + event.detail.Name);

        this.incidentUserObj.Name = event.detail.Name;
        this.incidentUserObj.Incident_Member__c = event.detail.Id;
    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }

    @api
    handleSaveAndExit() {
        console.log('this.currentPage', this.currentPage);
        console.log('this.recordTypeName', this.recordTypeName);
        console.log('caseObj', JSON.stringify(this.caseObj));
        let isPrimary = false;
        if (this.dataList.length > 0) {
            this.dataList.forEach(el => {
                if (el.IsPrimary__c) {
                    isPrimary = true;
                }
            })
        }
        if (isPrimary) {
            if (this.dataList.length > 0) {
                this.isLoaded = false;
                this.caseObj.Status = 'Draft';
                this.caseObj.CurrentPage__c = this.currentPage;
                let incidentMemberLists = JSON.parse(JSON.stringify(this.dataList));
                console.log('@incident member list-----> in save & exit----:::: ' , JSON.stringify(incidentMemberLists))
                incidentMemberLists.forEach(Obj => {
                    if (Obj.hasOwnProperty('rowId')) {
                        delete Obj.rowId;
                    }
                    console.log('obj->' + JSON.stringify(Obj));
                });
                let injuryDataList = JSON.parse(JSON.stringify(this.injuryData));
                injuryDataList.forEach(Obj => {
                    if (Obj.hasOwnProperty('rowIndex')) {
                        delete Obj.rowIndex;
                    }
                    console.log('obj->' + JSON.stringify(Obj));
                });

                let damageData = JSON.parse(JSON.stringify(this.damageData));
                damageData.forEach(Obj => {
                    if (Obj.hasOwnProperty('rowId')) {
                        delete Obj.rowId;
                    }
                    console.log('obj->' + JSON.stringify(Obj));
                });

                let courInf = JSON.parse(JSON.stringify(this.courseData));
                courInf.forEach(Obj => {
                    if (Obj.hasOwnProperty('rowId')) {
                        delete Obj.rowId;
                    }
                    console.log('obj->' + JSON.stringify(Obj));
                });
                createCaseOnSubmit({
                    caseObj: this.caseObj,
                    fileData: [],
                    incidentUserList: incidentMemberLists,
                    recordTypeName: this.recordTypeName,
                    injuryData: injuryDataList,
                    damageData: damageData,
                    courseInformation: courInf
                })
                    .then(result => {
                        if (result) {
                            this.isLoaded = true;
                            this.displayMessage("Success", "success", "Case saved as draft.");
                            this.dispatchEvent(new CustomEvent('saveexit'));
                        } else {
                            this.isLoaded = true;
                        }
                    }).catch(error => {
                        this.displayMessage("Error", "error", reduceErrors(error).toString());
                        this.isLoaded = true;
                    })
            } else {
                this.displayMessage("Please check your entries.", "error", "Please fill required fields");
            }
        }
        else {
            this.displayMessage("Error!!", "error", "Add at least one involved party's as a Primary Member.");
        }

    }
}