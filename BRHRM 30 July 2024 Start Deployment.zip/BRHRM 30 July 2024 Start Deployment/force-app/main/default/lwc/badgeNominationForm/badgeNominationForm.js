import { LightningElement, track, api, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import basePath from '@salesforce/community/basePath';
import { RefreshEvent } from 'lightning/refresh';
import getLoggedInUserBadges from '@salesforce/apex/BadgeNominationFormHandler.getLoggedInUserBadges';
import getSpecialBadges from '@salesforce/apex/BadgeNominationFormHandler.getSpecialBadges';
import saveBadges from '@salesforce/apex/BadgeNominationFormHandler.saveBadges';
import validateNominationProcess from '@salesforce/apex/BadgeNominationFormHandler.validateNominationProcess';

export default class BadgeNominationForm extends NavigationMixin(LightningElement) {
    commBasePath = basePath;
    communityUrl;
    @track loggedEmployeeBadge = []
    @track nominationBadges = []
    @track recognitionBadges = []
    isShowNominationModal = false
    @track selectedBadgeDetails = []
    nominationBadgeId;
    @track employeeDetails = {}
    @track publicGroupDetails = {}
    badgeType;
    isShowRecognitionModal = false
    badgeFound = false
    isShowBadgeDetailsTable = false
    isMyBadgesTableVisible = false
    recognitionName;
    isEnableNominationButton = true
    startDateNomination;
    endDateNomination;
    isLoading = false
    isToggleValueRecognition = false
    isEmployeeSearch = true
    isPublicGroupSearch = false
    @track objectApiName = 'Employee'

    createArrayObject() {
        let response = {}
        response.Id = ''
        response.imageUrl = ''
        response.giverId = ''
        response.giverName = ''
        response.recipientId = ''
        response. recipientName = ''
        response.badgeId = ''
        response.badgeName = ''
        response.badgeCount = 0
        return response
    }

    findOcc(arr, key){ 
      let arr2 = []; 
        
      arr.forEach((x)=>{ 
        if(x.BadgeType__c == 'Nomination') {
            if(x.ApprovalStatus__c == 'Approved By Nomination Team' && arr2.some((val)=>{ return val[key] == x[key] })) { 
                arr2.forEach((k)=>{ 
                    if(k[key] === x[key]){  
                        k["occurrence"]++ 
                    } 
                }) 
            } else {
                let a = {} 
                a[key] = x[key] 
                a["occurrence"] = 1 
                arr2.push(a); 
            } 
        } else {
            if(arr2.some((val)=>{ return val[key] == x[key] })) { 
                arr2.forEach((k)=>{ 
                    if(k[key] === x[key]){  
                        k["occurrence"]++ 
                    } 
                }) 
            } else {
                let a = {} 
                a[key] = x[key] 
                a["occurrence"] = 1 
                arr2.push(a); 
            } 
        }
        
      })
      return arr2 
    } 

    removeDuplicates(arr) {
        let newArray = [];
        let uniqueObject = {};

        for (let i in arr) {
            var objTitle = arr[i]['badgeId'];
            uniqueObject[objTitle] = arr[i];
        }

        for (let i in uniqueObject) {
            newArray.push(uniqueObject[i]);
        }

        return newArray;
    }

    connectedCallback() {
        this.isLoading = true
        this.communityUrl = `https://${location.host}${this.commBasePath}`;
        getLoggedInUserBadges({}).then(result=> {
            if(result.success) {
                this.isLoading = false
                if(JSON.parse(result.employeeData).Title__c == 'Director' || JSON.parse(result.employeeData).Title__c == 'Sr Director') {
                    this.isEnableNominationButton = false
                }
                let key = 'DefinitionId'
                console.log('here---> on load-----> ' , (result.response))
                JSON.parse(result.response).forEach(eachData=> {
                    if(eachData.ApprovalStatus__c == 'Approved by Nomination Team' && eachData.BadgeType__c == 'Nomination') {
                        console.log('how many-->')
                        var obj = this.createArrayObject()
                        obj.Id = eachData.Id
                        obj.imageUrl = eachData.ImageUrl
                        obj.giverId = eachData.GiverId
                        obj.giverName = eachData.Giver.Name
                        obj.recipientId = eachData.RecipientId
                        obj.recipientName = eachData.Recipient.Name
                        obj.badgeId = eachData.DefinitionId
                        obj.badgeName = eachData.Definition.Name
                        this.findOcc(JSON.parse(result.response), key).forEach(each=> {
                            if(each.DefinitionId == eachData.DefinitionId) {
                                obj.badgeCount = each.occurrence
                            }
                        })
                        this.loggedEmployeeBadge.push(obj)
                        console.log('in nomination----> ' , JSON.stringify(this.loggedEmployeeBadge))
                    } else if(eachData.BadgeType__c == 'Recognition') {
                        var obj = this.createArrayObject()
                        obj.Id = eachData.Id
                        obj.imageUrl = eachData.ImageUrl
                        obj.giverId = eachData.GiverId
                        obj.giverName = eachData.Giver.Name
                        obj.recipientId = eachData.RecipientId
                        obj.recipientName = eachData.Recipient.Name
                        obj.badgeId = eachData.DefinitionId
                        obj.badgeName = eachData.Definition.Name
                        this.findOcc(JSON.parse(result.response), key).forEach(each=> {
                            if(each.DefinitionId == eachData.DefinitionId) {
                                obj.badgeCount = each.occurrence
                            }
                        })
                        this.loggedEmployeeBadge.push(obj)
                    }
                })
                this.loggedEmployeeBadge = this.removeDuplicates(this.loggedEmployeeBadge)
                this.loggedEmployeeBadge.sort(function(a,b) {
                    if(a.badgeName < b.badgeName) {
                        return -1
                    }
                    if (a.badgeName > b.badgeName) {
                        return 1;
                    }
                    return 0;
                })
                if(this.loggedEmployeeBadge.length > 0) {
                    this.badgeFound = true
                    console.log('this.badgesLoogedUser------> ' , JSON.stringify(this.loggedEmployeeBadge))
                } else {
                    this.badgeFound = false
                }
            } else {
                this.isLoading = false
            }
        })
    }

    upDoc(title) {
        let pageUrl;
        if(title == 'ViewAll') {
            pageUrl = this.communityUrl + '/my-badges';
        } else if(title == 'PerformanceSelection'){
            pageUrl = this.communityUrl + '/recognition';
        }
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: pageUrl
            }
        },
            true
        );
    }

    handleClick(event) {
        this.isLoading = true
        getSpecialBadges({}).then(response=> {
            this.startDateNomination = response.startDate
            this.endDateNomination = response.endDate
            this.isLoading = false
            JSON.parse(response.allBadges).forEach(eachBadge=> {
                JSON.parse(response.metaBadges).forEach(eachMeta=> {
                    if(eachBadge.Name == eachMeta) {
                        var obj = {
                            badgeId : '',
                            badgeName : '',
                            badgeURL : '',
                            backgroundColor : '',
                            recognitionName : '',
                            selected : false,
                            sqNo : 0
                        }
                        obj.badgeId = eachBadge.Id
                        obj.badgeName = eachMeta
                        obj.badgeURL = eachBadge.ImageUrl
                        obj.recognitionName = eachBadge.Recognition_name__c
                        obj.sqNo = eachBadge.Sequence_Number__c
                        this.nominationBadges.push(obj)
                        this.nominationBadges.sort(function(a,b) {
                            if(a.sqNo < b.sqNo) {
                                return -1
                            }
                            if (a.sqNo > b.sqNo) {
                                return 1;
                            }
                            return 0;
                        })
                    } else {
                        var obj1 = {
                            badgeId : '',
                            badgeName : '',
                            badgeURL : '',
                            backgroundColor : '',
                            recognitionName : '',
                            selected : false
                        }
                        obj1.badgeId = eachBadge.Id
                        obj1.badgeName = eachBadge.Name
                        obj1.badgeURL = eachBadge.ImageUrl
                        obj1.recognitionName = eachBadge.Recognition_name__c
                        obj1.sqNo = eachBadge.Sequence_Number__c
                        this.recognitionBadges.push(obj1)
                    }
                })
            })
            this.recognitionBadges = this.removeDuplicates(this.recognitionBadges)
            this.recognitionBadges = this.recognitionBadges.filter((name) => !this.nominationBadges.some((e) => e.badgeName === name.badgeName))
            this.recognitionBadges.sort(function(a,b) {
                if(a.sqNo < b.sqNo) {
                    return -1
                }
                if (a.sqNo > b.sqNo) {
                    return 1;
                }
                return 0;
            })
        })
        if(event.target.title == 'Nomination') {
            this.badgeType = event.target.title
            this.isShowNominationModal = true
            this.isShowRecognitionModal = false
            this.isToggleValueRecognition = false
        } else if(event.target.title == 'Recognition') {
            this.badgeType = event.target.title
            this.isShowRecognitionModal = true
            this.isShowNominationModal = false
            this.isToggleValueRecognition = false
        } else if(event.target.title == 'ViewAll') {
            this.isShowBadgeDetailsTable = true
            this.isMyBadgesTableVisible = true
            this.upDoc(event.target.title);
        } else if(event.target.title == 'CloseTable') {
            this.isShowBadgeDetailsTable = false
        } else if(event.target.title == 'PerformanceSelection') {
            this[NavigationMixin.Navigate]({
                type: 'standard__namedPage',
                attributes: {
                    pageName: 'home'
                }
            });
        }
    }

    selectImage(event) {
        if(this.badgeType == 'Nomination') {
            this.nominationBadges.forEach(eachBadge=> {
                eachBadge.selected = false
                eachBadge.backgroundColor = 'background-color:white;'
            })
            var index = event.target.dataset.index
            if( this.nominationBadges[index].selected) {
                this.nominationBadges[index].backgroundColor = 'background-color:white;'
                this.nominationBadges[index].selected = false
            } else {
                this.nominationBadges[index].backgroundColor = 'background-color:darkgray;'
                this.nominationBadges[index].selected = true
                this.nominationBadgeId = event.target.dataset.id
                this.recognitionName = this.nominationBadges[index].recognitionName
            }
        } else {
            this.recognitionBadges.forEach(eachBadge=> {
                eachBadge.selected = false
                eachBadge.backgroundColor = 'background-color:white;'
            })
            var index = event.target.dataset.index
            if( this.recognitionBadges[index].selected) {
                this.recognitionBadges[index].backgroundColor = 'background-color:white;'
                this.recognitionBadges[index].selected = false
            } else {
                this.recognitionBadges[index].backgroundColor = 'background-color:darkgray;'
                this.recognitionBadges[index].selected = true
                this.nominationBadgeId = event.target.dataset.id
                this.recognitionName = this.recognitionBadges[index].recognitionName
            }
        }
        
    }

    lookupRecord(event) {
        if(this.objectApiName == 'Employee') {
            this.employeeDetails = event.detail.selectedRecord
        } else {
            this.publicGroupDetails = event.detail.selectedRecord
            console.log('this.publicGroupDetails-----> ' ,JSON.stringify(this.publicGroupDetails))
        }
        
    }

    onDescriptionChange(event) {
        this.additionalComment = event.target.value != null || event.target.value != '' ? event.target.value : null
    }

    saveNominationFormEmployee(event) {
        this.isLoading = true
        if(!this.isPublicGroupSearch) {
            if((this.nominationBadgeId != null || this.nominationBadgeId != undefined) && (this.employeeDetails != null || this.employeeDetails != undefined) && (this.additionalComment != null || this.additionalComment != undefined || this.additionalComment != '')) {
                validateNominationProcess({startDate : this.startDateNomination, endDate : this.endDateNomination, employeeDetails : JSON.stringify(this.employeeDetails), badgeId : this.nominationBadgeId}).then(result=> {
                    if(result) {
                        this.isLoading = false
                        const event = new ShowToastEvent({
                            title: 'Error',
                            message: 'You can nominate an employee with same badge only once during the nomination period.',
                            variant: 'error',
                            mode: 'dismissable'
                        });
                        this.dispatchEvent(event);
                    } else {
                        console.log('nomination id---> ' , this.nominationBadgeId)
                        console.log('employeeDetails value---> ' , this.employeeDetails)
                        //if((this.nominationBadgeId != null || this.nominationBadgeId != undefined) && (this.employeeDetails != null || this.employeeDetails != undefined)) {
                            saveBadges({badgeId : this.nominationBadgeId, employeeDetails : JSON.stringify(this.employeeDetails), comments : this.additionalComment, badgeType : this.badgeType, recognitionName : this.recognitionName, publicGroupDetails: JSON.stringify(this.publicGroupDetails), isPublicGroupSearch : this.isPublicGroupSearch}).then(response=> {
                                if(response.success) {
                                    this.isLoading = false
                                    this.isShowNominationModal = false
                                    this.isShowRecognitionModal = false
                                    var msg;
                                    if(this.badgeType == 'Nomination') {
                                        msg = 'Nomination has been sent for approval.'
                                    } else {
                                        msg = 'Badge has been assigned successfully.'
                                    }
                                    
                                    const event = new ShowToastEvent({
                                        title: response.response,
                                        message: msg,
                                        variant: 'success',
                                        mode: 'dismissable'
                                    });
                                    this.dispatchEvent(event);
                                    // this.isShowNominationModal = false
                                    // this.isShowRecognitionModal = false
                                    this.additionalComment = null
                                    this.employeeDetails = null
                                    this.nominationBadgeId = null
                                    this.nominationBadges = []
                                    this.recognitionBadges = []
                                    this.dispatchEvent(new RefreshEvent());
                                } else {
                                    this.isLoading = false
                                    const event = new ShowToastEvent({
                                        title: 'Error',
                                        message: response.response.split(',')[1].split(':')[0],
                                        variant: 'error',
                                        mode: 'dismissable'
                                    });
                                    this.dispatchEvent(event);
                                }
                            })
                        //}
                    }
                })
            } else {
                this.isLoading = false
                const event = new ShowToastEvent({
                    title: 'Error',
                    message: 'Please select badge and employee to proceed.',
                    variant: 'error',
                    mode: 'dismissable'
                });
                this.dispatchEvent(event);
            }
        } else {
            if((this.nominationBadgeId != null || this.nominationBadgeId != undefined) && (this.publicGroupDetails != null || this.publicGroupDetails != undefined) && (this.additionalComment != null || this.additionalComment != undefined || this.additionalComment != '')) {
                saveBadges({badgeId : this.nominationBadgeId, employeeDetails : JSON.stringify(this.employeeDetails), comments : this.additionalComment, badgeType : this.badgeType, recognitionName : this.recognitionName, publicGroupDetails: JSON.stringify(this.publicGroupDetails), isPublicGroupSearch : this.isPublicGroupSearch}).then(response=> {
                    if(response.success) {
                        this.isLoading = false
                        this.isShowNominationModal = false
                        this.isShowRecognitionModal = false
                        var msg;
                        if(this.badgeType == 'Nomination') {
                            msg = 'Nomination has been sent for approval.'
                        } else {
                            msg = 'Badge has been assigned successfully to the public group.'
                        }
                        
                        const event = new ShowToastEvent({
                            title: response.response,
                            message: msg,
                            variant: 'success',
                            mode: 'dismissable'
                        });
                        this.dispatchEvent(event);
                        // this.isShowNominationModal = false
                        // this.isShowRecognitionModal = false
                        this.additionalComment = null
                        this.employeeDetails = null
                        this.publicGroupDetails = null
                        this.nominationBadgeId = null
                        this.nominationBadges = []
                        this.recognitionBadges = []
                        this.isEmployeeSearch = true
                        this.dispatchEvent(new RefreshEvent());
                    } else {
                        this.isLoading = false
                        var msg = response.response.split(',')[1].split(':')[0] + ' ' + 'Your user might be present in the group.'
                        const event = new ShowToastEvent({
                            title: 'Error',
                            message: msg,
                            variant: 'error',
                            mode: 'dismissable'
                        });
                        this.dispatchEvent(event);
                    }
                })
            } else {
                this.isLoading = false
                const event = new ShowToastEvent({
                    title: 'Error',
                    message: 'Please select badge and employee to proceed.',
                    variant: 'error',
                    mode: 'dismissable'
                });
                this.dispatchEvent(event);
            }
        }
        
    }

    saveRecognitionFormEmployee() {
        this.saveNominationFormEmployee()
    }

    hideModalBox() {
        this.isShowNominationModal = false
        this.nominationBadges = []
        this.isShowRecognitionModal = false
        this.additionalComment = null
        this.recognitionBadges = []
        this.isToggleValueRecognition = false
        this.isEmployeeSearch = true
    }

    handleChange(event) {
        if(event.target.name == 'TypeToogle') {
            this.isToggleValueRecognition = event.target.checked
            if(event.target.checked) {
                this.isPublicGroupSearch = true
                this.isEmployeeSearch = false
                this.objectApiName = 'Group'
            } else {
                this.isEmployeeSearch = true
                this.isPublicGroupSearch = false
                this.objectApiName = 'Employee'
            }
        }
    }
}