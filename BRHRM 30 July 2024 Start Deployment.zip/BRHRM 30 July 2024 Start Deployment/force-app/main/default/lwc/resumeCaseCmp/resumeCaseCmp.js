import { LightningElement, api, wire, track } from 'lwc';
import getCaseRecord from '@salesforce/apex/CaseCreation.getCaseRecordInfo';
import basePath from '@salesforce/community/basePath';
import { NavigationMixin } from 'lightning/navigation';
export default class ResumeCaseCmp extends NavigationMixin (LightningElement) {
    commBasePath = basePath;
    communityUrl;
    @api recordId;
    isLoaded = false;
    @track caseObj = {};
    showResumeButton;
    recordTypeName;

    connectedCallback() {
        console.log('record Id of case page', this.recordId);
        this.communityUrl = `https://${location.host}${this.commBasePath}`;
        this.getCaseValue();
    }

    getCaseValue() {
        this.isLoaded = true;
        getCaseRecord({
            caseId: this.recordId
        })
            .then(result => {
                if (result != null) {
                    this.isLoaded = false;
                    this.caseObj = JSON.parse(JSON.stringify(result));
                    if (this.caseObj.Status == 'Draft') {
                        this.showResumeButton = true;
                    } else {
                        this.showResumeButton = false;
                    }
                    this.recordTypeName = this.caseObj.RecordType.DeveloperName;
                    console.log('this.caseObj--> ', JSON.stringify(this.caseObj));
                    console.log('this.showResumeButton--> ', this.showResumeButton);
                    console.log('this.recordTypeName--> ', this.recordTypeName);
                } else {
                    this.isLoaded = false;
                }
            }).catch(error => {
                this.isLoaded = false;;
            })
    }

    handleCaseChange(event) {
        let pageUrl = '';
        if (this.recordTypeName == 'Agency_Incident_Reporting') {
            pageUrl = this.communityUrl + '/incidentreportpage?id=' + this.recordId;
        } else if (this.recordTypeName == 'Compliance_Related_Case') {
            pageUrl = this.communityUrl + '/compliance?id=' + this.recordId;
        } else {
            pageUrl = this.communityUrl + '/people-and-culture-report-page?id=' + this.recordId;
        }
        console.log('pageUrl', pageUrl);
        window.location.assign(pageUrl);
        //this.navigateToCmp(pageUrl);
    }

    // navigateToCmp(pageUrl) {
    //     this[NavigationMixin.Navigate](
    //       {
    //         type: "standard__webPage",
    //         attributes: {
    //           url: pageUrl,
    //         },
    //       },
    //       true, 
    //     );
    //   }
}