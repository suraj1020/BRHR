import { LightningElement, wire, track, api } from 'lwc';
import getEnrolledTraining from '@salesforce/apex/TrainingDetailsPageController.getEnrolledTraining';
import getUnEnrolledTraining from '@salesforce/apex/TrainingDetailsPageController.getUnEnrolledTraining';
import getUpdateRecord from '@salesforce/apex/TrainingDetailsPageController.updateRecord';

import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class TrainingDetailsPage extends LightningElement {
    @api recordId;
    @track trainingData;
    trainingType = '';
    articleUrl = '';
    lmsUrl = '';
    onlineMeetingUrl = '';
    priority = '';
    priorityFlag = '';
    description = '';
    startDate = '';
    dueDate = '';
    endDate = '';
    mandatory = '';
    status = '';
    learningPath = '';
    updatedDescription = '';
    recordLink = '';
    @track disabled = false;
    isReadOnly = true;
    isSelfPacedTraining = false;
    articleType = false;
    lmsType = false;
    onlineMeetingType = false;
    inPersonType = false;
    city = '';
    country = '';
    postalCode = '';
    province = '';
    street = '';
    trainingEnrolled = false;
    @track priorityFlagSrc = ' ';

    get statusOption() {
        return [
            //{ label: '-- None --', value: '' },
            { label: 'New', value: 'New' },
            { label: 'In Progress', value: 'In Progress' },
            { label: 'Completed', value: 'Completed' },
        ];
    }


    @wire(getEnrolledTraining, { enrolledTrainingId: '$recordId' })
    trainingDetails({ error, data }) {
        console.log('Line 42--> '+ this.recordId+ 'date--> '+ JSON.stringify(data));
        
        if (data !== undefined && data !== null && data !== '' && Object.keys(data).length >0) {
            this.trainingData = data;
            console.log(this.recordId+' this.trainingData-48- '+JSON.stringify(this.trainingData));

            this.trainingEnrolled = true;
            this.trainingType = this.trainingData.Training_type__c;
            this.articleUrl = this.trainingData.Learning_and_Development__r.Article_URL__c;
            this.lmsUrl = this.trainingData.Learning_and_Development__r.LMS_URL__c;
            this.onlineMeetingUrl = this.trainingData.Learning_and_Development__r.Online_Meeting_URL__c;
            this.priority = this.trainingData.Learning_and_Development__r.Priority__c;
            this.priorityFlag = this.trainingData.Learning_and_Development__r.Priority_Flag__c;
            if (this.priorityFlag.includes('flag_green')) {
                this.priorityFlagSrc = '/img/samples/flag_green.gif';
            } else if (this.priorityFlag.includes('flag_yellow')) {
                this.priorityFlagSrc = '/img/samples/flag_yellow.gif';
            } else if (this.priorityFlag.includes('flag_red')) {
                this.priorityFlagSrc = '/img/samples/flag_red.gif';
            }           
            this.updatedDescription = this.trainingData.Learning_and_Development__r.Training_Content__c;
            this.startDate = this.trainingData.Learning_and_Development__r.Start_Datetime__c;  
            this.dueDate = this.trainingData.Learning_and_Development__r.Tdate__c;  
            if(this.trainingData.Training_type__c == 'Self-paced'){
                this.isSelfPacedTraining = true;
                this.startDate = '';
            }
            if(this.trainingData.Completed_Date__c){
                this.endDate = this.trainingData.Learning_and_Development__r.End_Datetime__c;
            }else{
                this.endDate = this.trainingData.Learning_and_Development__r.End_Datetime__c;
            }
            this.mandatory = this.trainingData.Learning_and_Development__r.isMandatory__c;
            if (this.trainingData && this.trainingData.Learning_Path__r && this.trainingData.Learning_Path__r.Name !== undefined){
                this.learningPath = this.trainingData.Learning_Path__r.Name;
            }
            this.status = this.trainingData.Status__c;
            if(this.trainingData.Status__c == 'Completed'){
                this.disabled = true;
            }
            console.log('Line 78--> '+ this.status);
            this.recordLink = '/employeeservicesample/s/employee-learning-and-development/'+this.recordId+'?tabset-6d52ea33=2';

            this.city = this.trainingData.Learning_and_Development__r.Address__City__s ;
            this.country = this.trainingData.Learning_and_Development__r.Address__CountryCode__s ;
            this.postalCode = this.trainingData.Learning_and_Development__r.Address__PostalCode__s ;
            this.province = this.trainingData.Learning_and_Development__r.Address__StateCode__s ;
            this.street = this.trainingData.Learning_and_Development__r.Address__Street__s ;
            
            console.log('endDate->'+ this.endDate);
            console.log('Startdate--> '+this.startDate);
            console.log('trainingType-75-> '+ this.trainingType);
            this.articleType = this.trainingType =='Article' ? true : false;
            this.lmsType = this.trainingType == 'LMS' ? true : false;
            this.onlineMeetingType = this.trainingType== 'Online' ? true : false;
            this.inPersonType = this.trainingType== 'In Person' ? true : false;
            
        } else if (error) {
            console.error('Error:', error);
        }
        
    }
    

    @wire(getUnEnrolledTraining, { enrolledTrainingId: '$recordId' })
    trainingDetails1({ error, data }) {
        console.log('Line 81--> '+ this.recordId);
        if (data !== null && data !== undefined && data !== '' && Object.keys(data).length >0) {
            this.trainingData = data;
            console.log(this.recordId+' this.trainingData-92- '+JSON.stringify(this.trainingData));

            this.trainingEnrolled = false;
            this.trainingType = this.trainingData.Training_Type__c;
            this.articleUrl = this.trainingData.Article_URL__c;
            this.lmsUrl = this.trainingData.LMS_URL__c;
            this.onlineMeetingUrl = this.trainingData.Online_Meeting_URL__c;
            this.priority = this.trainingData.Priority__c;
            this.priorityFlag = this.trainingData.Priority_Flag__c;
             if (this.priorityFlag.includes('flag_green')) {
                this.priorityFlagSrc = '/img/samples/flag_green.gif';
            } else if (this.priorityFlag.includes('flag_yellow')) {
                this.priorityFlagSrc = '/img/samples/flag_yellow.gif';
            } else if (this.priorityFlag.includes('flag_red')) {
                this.priorityFlagSrc = '/img/samples/flag_red.gif';
            }    
            this.updatedDescription = this.trainingData.Training_Content__c;
            this.startDate = this.trainingData.Start_Datetime__c;  
            this.dueDate = this.trainingData.Tdate__c;  
            this.endDate = this.trainingData.End_Datetime__c;            
            this.mandatory = this.trainingData.isMandatory__c;
            this.status = this.trainingData.Status__c;
            this.recordLink = '/employeeservicesample/s/employee-learning-and-development/'+this.recordId+'?tabset-6d52ea33=2';
            this.city = this.trainingData.Address__City__s ;
            this.country = this.trainingData.Address__CountryCode__s ;
            this.postalCode = this.trainingData.Address__PostalCode__s ;
            this.province = this.trainingData.Address__StateCode__s ;
            this.street = this.trainingData.Address__Street__s ;

            if(this.status == 'Completed'){
                this.disabled = true;
            }
            console.log('Line 129--> '+ this.status);

            if(this.trainingData.Training_Type__c == 'Self-paced'){
                this.isSelfPacedTraining = true;
                this.startDate = '';
            }

            console.log('endDate->'+ this.endDate);
            console.log('Startdate--> '+this.startDate);
            console.log('trainingType-114-> '+ this.trainingType);
            this.articleType = this.trainingType =='Article' ? true : false;
            this.lmsType = this.trainingType == 'LMS' ? true : false;
            this.onlineMeetingType = this.trainingType== 'Online' ? true : false;
            this.inPersonType = this.trainingType== 'In Person' ? true : false;
            
        } else if (error) {
            console.error('Error:', error);
        }
        
    }

    getUpdatedValue(event){
        this.updatedDescription = event.target.value;
    }
    updateStatus(event){
        this.status = event.detail.value;
        console.log(this.recordId);
        console.log(this.status);

        getUpdateRecord({ enrolledTrainingId: this.recordId, updatedStatus: this.status })
            .then((result) => {
                if(result.isSuccess) {
                    this.toastPopup('Status updated successfully!', 'success');
                } else {
                    this.toastPopupError(result.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error updating record:', error);
                this.toastPopupError('An error occurred while updating the status. Please try again.', 'error');
            });
    }

    markAsComplete(event){
        console.log('Line 158-->');
        this.disabled = true;
        this.status = 'Completed';
        console.log('Line 161-->'+ this.status);
        getUpdateRecord({ enrolledTrainingId: this.recordId, updatedStatus: this.status});
        this.toastPopup('Status updated successfully!!');
    }

    get buttonClass() {
        return this.disabled ? 'custom-disabled-button' : 'custom-enabled-button';
    }     

    toastPopup(message){
        const toastEvent = new ShowToastEvent({
            title: 'Success',
            message: message,
            variant: 'success',
        });
        this.dispatchEvent(toastEvent);
    }

    toastPopupError(message){
        const toastEvent = new ShowToastEvent({
            title: 'Error',
            message: message,
            variant: 'success',
        });
        this.dispatchEvent(toastEvent);
    }

}