import { LightningElement, wire, track, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import knowladgeArticle from'@salesforce/apex/CaseCtrl.knowladgeArticle';
export default class CaseHomePage extends NavigationMixin (LightningElement) {
    value = '';
    subjectValue='';
    knowledgeArticleStore;
    subjectSearchCheck = false;

    get options() {
        return [
            { label: 'Incident Related Case', value: 'Incident Related Case' },
            { label: 'People & Culture Related Case', value: 'People & Culture Related Case' },
            { label: 'Compliance Related Case', value: 'Compliance Related Case' },
        ];
    }

    handleChange(event) {
        this.value = event.detail.value;
        console.log("----this.value:" + this.value);
    }

    handleSubjectChange(event) {
        this.subjectSearchCheck = true;
        this.subjectValue = event.detail.value;
        console.log('subjectValue -- '+this.subjectValue);

        knowladgeArticle({ subject: this.subjectValue })
		.then(result => {
            if(result){  
                if(result == '' || result == undefined || result == 'undefined'){
                    this.knowledgeArticleStore = '';
                }else{
                    this.knowledgeArticleStore = result;
                }              
			    
                console.log('Knowledge -- '+JSON.stringify(result));
            }
            
		})
		.catch(error => {
		    console.log('Error -- '+error);
		})
    }

    caseNextPage(event){
        console.log('value -- '+this.value);
        let nextPageURL = "";
        
        if(this.value == 'Incident Related Case' && this.subjectValue){
            console.log('this.value -- '+this.value);
            nextPageURL ="/employeeservicesample/s/incidentreportpage?subject="+this.subjectValue;
        }else if(this.value == 'People & Culture Related Case' && this.subjectValue){
            console.log('subjectValue -- '+this.subjectValue);
            nextPageURL ="/employeeservicesample/s/people-and-culture-report-page?subject="+this.subjectValue; 
        }else if(this.value == 'Compliance Related Case' && this.subjectValue){
            console.log('this.value -- '+this.value);
            nextPageURL ="/employeeservicesample/s/compliance?subject="+this.subjectValue; 
        }else{
            if(this.subjectValue){
                this.displayMessage("Required field missing!", "error", "Please select the case type.");
            }else{
                this.displayMessage("Write the issue in subject!", "error", "Please search your issue in subject before raise a case.");
            }
        }
        this[NavigationMixin.Navigate]({
                "type": "standard__webPage",
                "attributes": {
                    "url": nextPageURL
                }
        });

    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }
}