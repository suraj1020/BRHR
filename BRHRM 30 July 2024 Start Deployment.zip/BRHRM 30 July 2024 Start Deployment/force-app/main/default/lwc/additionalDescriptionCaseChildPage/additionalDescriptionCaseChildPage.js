import { LightningElement, track, api } from 'lwc';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { reduceErrors } from 'c/lwcUtility';
export default class AdditionalDescriptionCaseChildPage extends LightningElement {

    @api caseObj = {};
    @api incidentMemberList = [];
    @track fileData = [];
    @track showpill = false;
    @api fileD = [];
    isLoaded = true;
    @api recordTypeName;
    @api injuryData = [];
    @api damageData = [];
    @api showAck;
    @api courseData = [];

    connectedCallback() {
        console.log('this.recordTypeName>' + this.recordTypeName);
        console.log('--13-->' + JSON.stringify(this.incidentMemberList));
        let obj = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj;
        console.log('--this.caseObj-->' + JSON.stringify(this.caseObj));
        console.log('--this.fileD-->' + JSON.stringify(this.fileD));
        if (this.fileD.length > 0) {
            this.fileData = [...this.fileD];
            this.showpill = true;
        }
    }
  
   

    handleChange(event) {
        this.caseObj[event.target.name] = event.target.value;
        console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));
    }

    handleFileUploaded(event) {
        console.log('Enter 14--> ' + JSON.stringify(event.target.files));
        // let preLen = 0;
        // if(this.fileData != null && this.fileData != undefined && this.fileData.length >0){
        //     preLen = this.fileData.length;
        // }
        if (event.target.files.length > 0) {
            for (var i = 0; i < event.target.files.length; i++) {
                let file = event.target.files[i];
                this.readfile(file);
            }
        }
    }

    removeReceiptImage(event) {
        var index = event.currentTarget.dataset.id;
        console.log('index-8->', index);
        console.log('--20-->' + this.fileData.length);
        this.fileData.splice(index, 1);
        console.log('--22-->' + this.fileData.length);
        this.fileData = [...this.fileData];
    }

    readfile(file) {
        let reader = new FileReader();
        reader.onload = () => {
            console.log('Line 67');
            var base64 = reader.result.split(',')[1];
            console.log('Line 69');
            let fileDataa = {
                'fileName': file.name,
                'fileContent': base64,
            }
            console.log('Line 78-->' + JSON.stringify(fileDataa));
            console.log('line 72--> ' + JSON.stringify(this.fileData));
            this.fileData.push(fileDataa);
            console.log('Line 82-->' + JSON.stringify(this.fileData));
            this.showpill = true;
            this.fileData = [...this.fileData];
            //const l = this.fileData.length - preLen;
            console.log('this.fileData.length--89->' + this.fileData.length);

            // console.log('lone 79-->'+ l);
            // console.log('count-90->'+ count);
            // if(count == l){
            //     this.dispatchEvent(new CustomEvent('fileupload', {
            //         detail: {
            //             filesData: this.fileData,
            //             pacName: this.peclName,
            //             conId: this.conId,
            //             peclid: this.peclid,
            //             type: this.type
            //         }
            //     }));
            // }

        }
        reader.readAsDataURL(file);

    }

    @api
    handleNext() {

        this.caseObj.Status = 'New';
        let incidentMemberLists = JSON.parse(JSON.stringify(this.incidentMemberList));
        console.log('Line 83 Submit');
        console.log('subject',this.valueFromParent)
        console.log('list-->' + JSON.stringify(incidentMemberLists));
        incidentMemberLists.forEach(Obj => {
            if (Obj.hasOwnProperty('rowId')) {
                delete Obj.rowId;
            }
            console.log('obj->' + JSON.stringify(Obj));
        });
        let injuryDataList = JSON.parse(JSON.stringify(this.injuryData));
        injuryDataList.forEach(Obj => {
            if (Obj.hasOwnProperty('rowIndex')) {
                delete Obj.rowIndex;
            }
            console.log('obj->' + JSON.stringify(Obj));
        });

        let damageData = JSON.parse(JSON.stringify(this.damageData));
        damageData.forEach(Obj => {
            if (Obj.hasOwnProperty('rowId')) {
                delete Obj.rowId;
            }
            console.log('obj->' + JSON.stringify(Obj));
        });

        console.log('list-96->' + JSON.stringify(incidentMemberLists)); // Nahar bhai is list ko apex me pass krke case ke related me INSERT krwa dena bs
        console.log('this.caseObj>' + JSON.stringify(this.caseObj))
        console.log('this.recordTypeName>' + this.recordTypeName);
        console.log('injuryDataList>' + JSON.stringify(injuryDataList))
        let courInf = JSON.parse(JSON.stringify(this.courseData));
        courInf.forEach(Obj => {
            if (Obj.hasOwnProperty('rowId')) {
                delete Obj.rowId;
            }
            console.log('obj->' + JSON.stringify(Obj));
        });
        this.isLoaded = false;
        createCaseOnSubmit({
            caseObj: this.caseObj,
            fileData: this.fileData,
            incidentUserList: incidentMemberLists,
            recordTypeName: this.recordTypeName,
            injuryData: injuryDataList,
            damageData: damageData,
            courseInformation: courInf,
        })
            .then(result => {
                if (result) {
                    this.isLoaded = true;
                    let obj = JSON.parse(JSON.stringify(result));
                    console.log('this.obj--> ', JSON.stringify(obj));
                    console.log('this.caseData--> ', JSON.stringify(obj.caseObj));
                    this.dispatchEvent(new CustomEvent('insertcase', { detail: obj.caseObj.CaseNumber }));
                }
            }).catch(error => {
                this.displayMessage("Error", "error", reduceErrors(error).toString());
                this.isLoaded = true;
            })

    }

    @api handlePrevious() {
        this.dispatchEvent(new CustomEvent('previousclick', {
            detail: {
                file: this.fileData,
                caseObject: this.caseObj
            }
        }));
    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }
}