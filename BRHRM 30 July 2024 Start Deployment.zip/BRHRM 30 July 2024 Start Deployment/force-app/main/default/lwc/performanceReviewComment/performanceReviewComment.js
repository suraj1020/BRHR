import { LightningElement, track, api, wire } from 'lwc';
import getInitialDetails from '@salesforce/apex/PerformanceReviewComment.getInitialDetails';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class PerformanceReviewComment extends LightningElement 
{
    dataRecords = [];

    connectedCallback()
    {
        getInitialDetails()
        .then(result => {
            console.log("This is new Data" , result);
            this.dataRecords = result
            console.log("------this.dataRecords--------" , this.dataRecords);
        })
        .catch(error => {
            this.error = error;
        })
        // .then(result => {
        //     var records = result;
        //     var dummyData = [];
        //     console.log("------records 12------>" , records);
        //     records.forEach(function(element){
        //         console.log("-------eachrecord---------" , element);
        //         if(element != null){
        //             console.log("-------eachrecord---------" , element);
        //             let elt = {};
        //             elt.Id = element.Id;
        //             console.log("---Id--->" , elt.Id);
        //             elt.GiverName = element.Employee__r.User.Manager.Name;
        //             console.log("---Giver Name--->" , elt.GiverName);
        //             elt.Designation = element.Employee__r.JobProfile;
        //             console.log("---Designation--->" , elt.Designation);
        //             dummyData.push(elt);
        //         }
        //     });
        //     console.log("-----dummy Data 27-----------" , dummyData);
        //     this.dataRecords = dummyData;
        // })
        // .catch(error => {
        //     this.error = error;
        //     console.log("------error------" , this.error);
        // })
    }
}