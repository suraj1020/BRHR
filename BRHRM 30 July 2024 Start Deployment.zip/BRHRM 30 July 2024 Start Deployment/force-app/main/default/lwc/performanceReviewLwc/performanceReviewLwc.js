import { LightningElement, track, wire } from 'lwc';
import getInitialDetails from '@salesforce/apex/PerformanceReviewController.getInitialDetails';
import updateComment from '@salesforce/apex/PerformanceReviewController.updateComment';
import updateGoalComment from '@salesforce/apex/PerformanceReviewController.updateGoalComment';
import getPerformanceRecords from '@salesforce/apex/PerformanceReviewController.getPerformanceRecords';
import handleSave from '@salesforce/apex/PerformanceReviewController.handleSave';
import updateKpiRating from '@salesforce/apex/PerformanceReviewController.updateKpiRating';
import updateGoal from '@salesforce/apex/PerformanceReviewController.updateGoal';
import editGoal from '@salesforce/apex/PerformanceReviewController.editGoal';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { reduceErrors } from 'c/lwcUtility';
import savePIPComment from '@salesforce/apex/PerformanceImprovementPlanController.savePIPComment';


export default class PerformanceReviewLwc extends LightningElement {
    typeGoal;
    totalweightage;
    goalOldWeightage;
    name;
    type;
    showComments = false;
    updateStartDate;
    updateEndDate;
    updateDescription;
    updateSuccessMeasurement;
    updateManagerComments;
    selectedId;
    selectedName;
    isLoading = true;
    @track kpiweightage;
    weightageModal = false;
    updateGoalModal = false;
    statusModal = false;
    statusNewValue;
    weightageNumber;
    goalId;
    commentSave = false;
    @track showTask = false;
    @track showTaskDetails = false;
    @track goalIdToSend = '';
    displayText;
    reviewValues = [];
    reviewResults = [];
    @track listOfKPIsGoalsMap = [];
    @track listOfCompetencyGoalsMap = [];
    compentencyList = [];
    performanceReviewList = [];
    activeTab = 'KPI';
    employeeReadOnly = true;
    managerReadOnly = true;
    showTeamsList = false;
    showAdditionalGoals = false;
    @track showGoal = false;
    yearValuesList = [];
    showCommentsModal = false;
    isEmployee;
    selectedEmployeeId;
    selectedEmployeeName;
    feedbacktype;
    employeeList;
    empRec;
    selectedYear;
    teamListForManager = [];
    additionalGoalsList = [];
    @track viewAsManager = false;
    isLoading = false;
    additionalGoalsListTemp = [];
    performanceReviewId;
    managerReview;
    employeeReview;
    managerRating;
    employeeRating;
    kpiRecordMap;
    checkManager = false;
    addCommentModal = false;
    goalCommentModal = false;
    commentValue;
    goalCommentValue;
    @track kpiId;
    @track prfLstToUpdate = { "SObjectType": "Performance_Review_Feedback__c" };
    @track searchTermType;
    placeholder;
    @track searchByName = false;
    @track searchTermValue;
    ratingModalBox = false;
    kpiIdToUpdateRating;
    ratingValue;
    @track isShowRecordTypeKPI = false;
    @track isShowEditKPIModal = false;
    @track kpiCompObjectEdit = {}
    @track nameCmp;

    openRatingModal(event) {
        this.ratingModalBox = true;
        this.kpiIdToUpdateRating = event.target.dataset.id;
        console.log('kpiIdToUpdateRating', this.kpiIdToUpdateRating)
    }

    handleNewKPI() {
        this.isShowRecordTypeKPI = true;
    }

    handleNewKPIActionPopUp(event) {
        this.isShowRecordTypeKPI = event.detail.closePopUp;
    }

    closeRatingModal() {
        this.ratingModalBox = false;
    }

    handleEditKPIActionPopUp(event) {
        this.isShowEditKPIModal = event.detail.closePopUp;
        var dataKpi = event.detail.onEditData;
        if(this.nameOfModal == 'kpiEdit') {
            console.log('dataKpi---> > > >' , JSON.stringify(dataKpi))
            const i = this.listOfKPIsGoalsMap.findIndex(x => x.key === dataKpi.key)
            this.listOfKPIsGoalsMap[i] = dataKpi
            this.listOfKPIsGoalsMap.map(obj => dataKpi.key === obj.key || obj);
            this.listOfKPIsGoalsMap = [...this.listOfKPIsGoalsMap];
        } else if(this.nameOfModal == 'competencyEdit') {
            console.log('dataKpi---> > > >' , JSON.stringify(dataKpi))
            const i = this.listOfCompetencyGoalsMap.findIndex(x => x.key === dataKpi.key)
            this.listOfCompetencyGoalsMap[i] = dataKpi
            this.listOfCompetencyGoalsMap.map(obj => dataKpi.key === obj.key || obj);
            this.listOfCompetencyGoalsMap = [...this.listOfCompetencyGoalsMap];
        }
        
    }

    showEditModalKPI(event) {
        let index = event.target.dataset.index
        this.isShowEditKPIModal = true
        this.nameOfModal = event.target.name
        if(event.target.name == 'kpiEdit') {
            this.kpiCompObjectEdit = this.listOfKPIsGoalsMap[index]
        } else if(event.target.name == 'competencyEdit') {
            this.kpiCompObjectEdit = this.listOfCompetencyGoalsMap[index]
        }
        this.isShowRecordTypeKPI = false
    }

    submitRating() {
        this.isLoading = true;
        console.log('kpiIdToUpdateRating', this.kpiIdToUpdateRating)
        console.log('ratingValue', this.ratingValue)
        let isEmployeeOrManager = this.viewAsManager == true ? false : this.isEmployee;
        updateKpiRating({ kpiId: this.kpiIdToUpdateRating, isEmployee: isEmployeeOrManager, ratingValue: this.ratingValue })
            .then(result => {
                this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
            })
            .catch(error => {
                this.isLoading = false;
                this.showToast('Error', reduceErrors(error).toString(), 'error');
            });
    }

    handleRatingChange(event) {
        this.ratingValue = event.target.value;
    }

    get searchOptions() {
        return [
            { label: '-- None --', value: '' },
            { label: 'KPI Name', value: 'Name' },
        ];
    }

    get statusOption() {
        return [
            //{ label: '-- None --', value: '' },
            { label: 'Not Started', value: 'Not Started' },
            { label: 'In-Progress', value: 'In-Progress' },
            { label: 'Completed', value: 'Completed' },
        ];
    }

    get typeOptions() {
        return [
            { label: 'Formal Goal', value: 'Formal Goal' },
            { label: 'Additional Goal', value: 'Additional Goal' },
        ];
    }


    handleChange(event) {
        if (event.detail.value == 'Name') {
            this.searchByName = true;
        } else {
            this.searchByName = false;
        }

    }

    handleSearchType(event) {
        this.searchTermValue = event.detail.value;
        console.log('----this.searchTermValue--' + this.searchTermValue);
        this.searchTermValue = this.searchTermValue.toLowerCase();
        let tempData = [];
        this.additionalGoalsListTemp.forEach(element => {
            if (element.KPIs_Reference__r != null) {
                tempData.push(element);

            }
        });

        console.log('-----tempData--Line : 77--' + JSON.stringify(tempData));
        console.log('-- 78 - this.searchTermValue: ' + this.searchTermValue);
        if (this.searchTermValue) {
            this.additionalGoalsList = tempData.filter(item =>
                item.KPIs_Reference__r.Name.toLowerCase().includes(this.searchTermValue));
        } else {
            this.additionalGoalsList = this.additionalGoalsListTemp;
        }
    }

    handleEdit() {
        if (this.isEmployee && !this.viewAsManager) {
            this.employeeReadOnly = false;
        } else {
            this.managerReadOnly = false;
        }
    }

    handleToggleChange(event) {
        if (!event.target.checked) {
            this.viewAsManager = false;
            this.fetchPerformanceRecords(this.employeeList[0].Id, this.employeeList[0].Name);
        }
        this.showTeamsList = event.target.checked;
    }
    get showManagerComments() {
        return this.viewAsManager || !this.isEmployee;
    }
    get editButtonVisibility() {
        return this.isEmployee && !this.viewAsManager ? this.employeeReadOnly : this.managerReadOnly;
    }
    handleCancel() {
        this.isEmployee && !this.viewAsManager ? this.employeeReadOnly = true : this.managerReadOnly = true;
    }
    get SubmitButtonVisibility() {
        return this.performanceReviewList.length ?
            this.isEmployee && !this.viewAsManager ? !this.performanceReviewList[0].Submitted_By_Employee__c
                : !this.performanceReviewList[0].Submitted_By_Manager__c
            : false;
    }

    get getButtonVisibility() {
        let today = new Date().setHours(0, 0, 0, 0);
        if (this.performanceReviewList.length && this.isEmployee && this.viewAsManager) {
            let startDate = new Date(this.performanceReviewList[0].Manager_Start_Date__c).setHours(0, 0, 0, 0);
            let endDate = new Date(this.performanceReviewList[0].Manager_Due_Date__c).setHours(0, 0, 0, 0);
            return (today >= startDate && today <= endDate);
        } else if (this.performanceReviewList.length && this.isEmployee && !this.viewAsManager) {
            let startDate = new Date(this.performanceReviewList[0].Start_Date__c).setHours(0, 0, 0, 0);
            let endDate = new Date(this.performanceReviewList[0].Due_Date__c).setHours(0, 0, 0, 0);
            return today >= startDate && today <= endDate;
        } else {
            return false;
        }
    }

    showCommentModal(event) {
        this.showComments = true;
        const idx = event.currentTarget.dataset.id;
        this.kpiId = idx;
        this.goalId = null;
    }
    showGoalCommentModal(event) {
        this.showComments = true;
        const idx = event.currentTarget.dataset.id;
        this.goalId = idx;
        this.kpiId = null;
    }
    closeModalOfShowComments(event) {
        this.showComments = event.detail;
    }
    handleYearChange(event) {
        this.selectedYear = event.target.value;
        //this.displayText = 'Performance Review Evaluation - ' + this.selectedYear;
        this.displayText = 'Performance Evaluation - Annual Review';
        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
        console.log('this.selectedYear -- ' + this.selectedYear + ' -- ' + this.displayText);
    }

    /*handleRefresh()
     {
       console.log('Refresh called '+this.selectedEmployeeId+ ' -- '+this.selectedEmployeeName);      
        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
     }*/

    connectedCallback() {
        console.log("---------in CMP :" );
        this.isLoading = true;
        this.nameCmp = 'PRL'
        const d = new Date();
        let month = d.getMonth();
        let year = d.getFullYear();
        this.selectedYear = year.toString();
        //this.displayText = 'Performance Review Evaluation - ' + this.selectedYear;
        this.displayText = 'Performance Evaluation - Annual Review';
        console.log('connectedCallback -- ' + this.selectedYear + ' -- ' + this.displayText);
        this.yearValuesList = [...this.yearValuesList, { label: (year - 1).toString(), value: (year - 1).toString() }, { label: year.toString(), value: year.toString() }];
        getInitialDetails()
            .then(result => {
                console.log('result', JSON.stringify(result));
                this.isLoading = false;
                this.reviewValues = result.optionList;
                let employeeList = result.employeeList;
                this.employeeList = employeeList;
                //this.yearValuesList = result.yearValuesList;
                if (employeeList.length > 0) {
                    this.isEmployee = true;
                    this.selectedEmployeeId = employeeList[0].Id;
                    this.selectedEmployeeName = employeeList[0].Name;
                    this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
                    //this.fetchPerformanceRecords(employeeList[0].Id, employeeList[0].Name);
                } else {
                    this.isEmployee = false;
                }
                if (result.teamListForManager) {
                    this.teamListForManager = result.teamListForManager;
                }
            })
            .catch(error => {
                this.isLoading = false;
                this.showToast('Error', reduceErrors(error).toString(), 'error');
            });
    }
    /*@wire(getInitialDetails)
    wiredGetInitialDetails({ error, data }) {
        if (data) {
            this.isLoading = false;
            this.reviewValues = data.optionList;
            let employeeList = data.employeeList;
            this.employeeList = employeeList;
            this.yearValuesList = data.yearValuesList;

            if (employeeList.length > 0) {
                this.isEmployee = true;
                this.selectedEmployeeId = employeeList[0].Id;
                this.selectedEmployeeName = employeeList[0].Name;
                this.fetchPerformanceRecords(
                    employeeList[0].Id,
                    employeeList[0].Name
                );
            }

            if (data.teamListForManager) {
                this.teamListForManager = data.teamListForManager;
            }
        } else if (error) {
            this.isLoading = false;
            this.showToast('Error', this.reduceErrors(error).toString(), 'error');
        }
    }*/

    handleValueSelectedOnEmployee(event) {
        this.selectedId = event.detail.id ? event.detail.id : event.target.value;
        this.selectedName = event.detail.mainField ? event.detail.mainField : event.target.options.find(opt => opt.value === event.detail.value).label;
        this.viewAsManager = true;
        this.employeeReadOnly = true;
        //this.isEmployee = false;
        this.managerReadOnly = true;
        this.selectedEmployeeId = this.selectedId;
        this.selectedEmployeeName = this.selectedName;
        console.log('---- 320 this.selectedEmployeeId: ' + this.selectedEmployeeId);
        console.log('---- 321 this.selectedEmployeeName: ' + this.selectedEmployeeName);
        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
    }

    @track managerOverallRating = 0;
    @track managerOverallComment;
    @track managerOverallRatingCompetency = 0;
    @track managerOverallCommentCompentency;
    @track managerOverallRatingFinal = 0;
    @track managerOverallCommentFinal;

    @track employeeOverallRating = 0;
    @track employeeOverallRatingCompetency = 0;
    @track employeeOverallRatingFinal = 0;

    fetchPerformanceRecords(empId, empName) {
        this.isLoading = true;
        console.log('---- 338 empId: ' + empId);
        console.log('---- 339 empName: ' + empName);
        console.log('---- 340 this.selectedYear: ' + this.selectedYear);
        getPerformanceRecords({ employeeId: empId, employeeName: empName, selectedYear: this.selectedYear })
            .then(result => {
                console.log('--- 343 JSON.stringify(result): ' + JSON.stringify(result));
                if (result) {
                    this.isLoading = false;
                    this.reviewResults = result;
                    let kPIsToGoalsMap = result.kPIsToGoalsMap;
                    let competencyToGoalsMap = result.competencyToGoalsMap;
                    let listOfKPIsGoalsMapTemp = [];
                    let listOfCompetencyGoalsMap = [];
                    if (kPIsToGoalsMap) {
                        for (let key in kPIsToGoalsMap) {
                            listOfKPIsGoalsMapTemp.push({ key: key, value: kPIsToGoalsMap[key], kpiData: result.kpiRecordMap[key] });
                        }
                        this.listOfKPIsGoalsMap = listOfKPIsGoalsMapTemp;
                        console.log('this.listOfKPIsGoalsMap', JSON.stringify(this.listOfKPIsGoalsMap));
                        this.managerOverallRating = 0;
                        this.managerOverallRatingFinal = 0;
                        
                        this.employeeOverallRating = 0;
                        this.employeeOverallRatingFinal = 0;

                        if (this.listOfKPIsGoalsMap.length > 0) {
                            this.listOfKPIsGoalsMap.forEach(el => {
                                if (el.kpiData.hasOwnProperty('Employee_Rating__c')) {
                                    this.employeeOverallRating = this.employeeOverallRatingFinal + parseInt(el.kpiData.Employee_Rating__c);
                                }
                                if (el.kpiData.hasOwnProperty('Manager_Rating__c')) {
                                    this.managerOverallRating = this.managerOverallRating + parseInt(el.kpiData.Manager_Rating__c);
                                }
                            })
                            console.log('this.managerOverallRating', this.managerOverallRating);
                            this.managerOverallRating = parseFloat(this.managerOverallRating / this.listOfKPIsGoalsMap.length).toFixed(1);
                            console.log('this.managerOverallRating', typeof this.managerOverallRating);

                            this.employeeOverallRating = parseFloat(this.employeeOverallRating / this.listOfKPIsGoalsMap.length).toFixed(1);
                            this.employeeOverallRatingFinal = this.employeeOverallRating;
                            
                            if(parseFloat(this.managerOverallRating) > 2.5) {
                                this.managerOverallComment = 'Exceed Goals';
                            }else if(parseFloat(this.managerOverallRating) > 1.5) {
                                this.managerOverallComment = 'Meet Goals';
                            }else {
                                this.managerOverallComment = 'Growth Opportunity';
                            }
                            console.log('this.managerOverallComment', this.managerOverallComment);
                        }

                        this.managerOverallRatingFinal = this.managerOverallRating;
                        this.managerOverallCommentFinal = this.managerOverallComment;
                    }
                    if (competencyToGoalsMap) {
                        for (let key in competencyToGoalsMap) {
                            listOfCompetencyGoalsMap.push({ key: key, value: competencyToGoalsMap[key], kpiData: result.kpiRecordMap[key] });
                        }
                        this.listOfCompetencyGoalsMap = listOfCompetencyGoalsMap;
                        this.managerOverallRatingCompetency = 0;

                        if (this.listOfCompetencyGoalsMap.length > 0) {
                            this.listOfCompetencyGoalsMap.forEach(el => {
                                if (el.kpiData.hasOwnProperty('Employee_Rating__c')) {
                                    this.employeeOverallRatingCompetency = this.employeeOverallRatingCompetency + parseInt(el.kpiData.Employee_Rating__c);
                                }
                                
                                if (el.kpiData.hasOwnProperty('Manager_Rating__c')) {
                                    this.managerOverallRatingCompetency = this.managerOverallRatingCompetency + parseInt(el.kpiData.Manager_Rating__c);
                                }
                            })
                            console.log('this.managerOverallRatingCompetency', this.managerOverallRatingCompetency);
                            this.managerOverallRatingCompetency = parseFloat(this.managerOverallRatingCompetency / this.listOfCompetencyGoalsMap.length).toFixed(1);
                            console.log('this.managerOverallRating', typeof this.managerOverallRatingCompetency);
                            if(parseFloat(this.managerOverallRatingCompetency) > 2.5) {
                                this.managerOverallCommentCompentency = 'Exceed Goals';
                            }else if(parseFloat(this.managerOverallRatingCompetency) > 1.5) {
                                this.managerOverallCommentCompentency = 'Meet Goals';
                            }else {
                                this.managerOverallCommentCompentency = 'Growth Opportunity';
                            }
                            this.managerOverallRatingFinal = parseFloat((parseFloat(this.managerOverallRatingFinal) + parseFloat(this.managerOverallRatingCompetency)) / 2).toFixed(1);

                            this.employeeOverallRatingFinal = parseFloat((parseFloat(this.employeeOverallRatingFinal) + parseFloat(this.employeeOverallRatingCompetency)) / 2).toFixed(1);

                            if(parseFloat(this.managerOverallRatingFinal) > 2.5) {
                                this.managerOverallCommentFinal = 'Exceed Goals';
                            }else if(parseFloat(this.managerOverallRatingFinal) > 1.5) {
                                this.managerOverallCommentFinal = 'Meet Goals';
                            }else {
                                this.managerOverallCommentFinal = 'Growth Opportunity';
                            }
                        }
                    }

                    if (result.compentencyList) {
                        this.compentencyList = result.compentencyList;
                    }
                    if (result.performanceReviewList) {
                        this.performanceReviewList = result.performanceReviewList;
                        this.performanceReviewId = result.performanceReviewList[0].Id;
                    }
                    if (result.additionalGoalsList) {
                        this.additionalGoalsList = result.additionalGoalsList;
                        this.additionalGoalsListTemp = result.additionalGoalsList;
                    }
                    if (result.empRec) {
                        this.empRec = result.empRec;
                    }

                } else {
                    this.isLoading = false;
                    this.performanceReviewList = [];
                    this.compentencyList = [];
                    this.listOfKPIsGoalsMap = [];
                    this.additionalGoalsList = [];
                    this.additionalGoalsListTemp = [];
                }
                this.ratingModalBox = false;
            })
            .catch(error => {
                this.isLoading = false;
                this.showToast('Error', reduceErrors(error).toString(), 'error');
            });

    }

    getkpiValueForKey1(getParam) {
        console.log('KPI record' + ' -- ' + getParam);
        return 'this.kpiRecordMap Test';
    }

    handleEmployeeCommentsChange(event) {
        this.updateChangeValue(event, 'Employee_Comments__c');
    }
    handleManagerCommentsChange(event) {
        this.updateChangeValue(event, 'Manager_Comments__c');
    }
    handleEmployeeRating(event) {
        this.updateChangeValue(event, 'Rating__c');
    }
    handleManagerRating(event) {
        this.updateChangeValue(event, 'Manager_Ratings__c');
    }
    handleOverallRating(event) {
        let targetValue = event.target.value;
        let performanceReviewList = [...this.performanceReviewList];
        performanceReviewList[0].Overall_Ratings__c = targetValue;
        this.performanceReviewList = performanceReviewList;
    }
    handleManagerOverallComments(event) {
        let targetValue = event.target.value;
        let performanceReviewList = [...this.performanceReviewList];
        performanceReviewList[0].Manager_Overall_Comments__c = targetValue;
        this.performanceReviewList = performanceReviewList;
    }

    updateChangeValue(event, fieldName) {
        //alert("UpdateChangeValue");
        let targetValue = event.target.value;
        let index = event.target.dataset.index;
        let parentindex = event.target.dataset.parentindex;
        let tabType = event.target.dataset.tabtype;
        if (tabType === 'KPI') {
            let listOfKPIsGoalsMapTemp = [...this.listOfKPIsGoalsMap];
            let performanceFeedBack = listOfKPIsGoalsMapTemp[parentindex].value[index];
            performanceFeedBack[fieldName] = targetValue;
            this.listOfKPIsGoalsMap = listOfKPIsGoalsMapTemp;
        } else if (tabType === 'Compentency') {
            let compentencyList = [...this.compentencyList];
            let performanceFeedBack = compentencyList[index];
            performanceFeedBack[fieldName] = targetValue;
            this.compentencyList = compentencyList;
        } else {
            let additionalGoalsList = [...this.additionalGoalsList];
            let performanceFeedBack = additionalGoalsList[index];
            performanceFeedBack[fieldName] = targetValue;
            this.additionalGoalsList = additionalGoalsList;
        }
    }

    handleActive(event) {
        this.activeTab = event.target.value;
    }
    handleAddComments() {
        this.feedbacktype = 'add comments';
        this.showCommentsModal = true;
    }
    handleGetComments() {
        this.feedbacktype = 'getComments';
        this.showCommentsModal = true;
    }
    handleAddGoals() {
        this.showAdditionalGoals = true;
    }

    handleTaskClick(event) {
        const idx = event.currentTarget.dataset.id;
        console.log('-----idx---' + idx);
        const name = event.target.name
        if(name == 'compGoal') {
            this.goalIdToSend = this.listOfCompetencyGoalsMap[0].value[0].Goal__r.Id;
        } else {
            this.goalIdToSend = this.listOfKPIsGoalsMap[0].value[0].Goal__r.Id;
        }
        
        console.log('-----this.selectedEmployeeId---' + JSON.stringify(this.selectedEmployeeId));
        this.showTask = true;
    }

    handleTaskViewClick(event) {
        const idx = event.currentTarget.dataset.id;
        const name = event.target.name
        if(name == 'compGoal') {
            this.goalIdToSend = this.listOfCompetencyGoalsMap[0].value[0].Goal__r.Id;
        } else {
            this.goalIdToSend = this.listOfKPIsGoalsMap[0].value[0].Goal__r.Id;
        }
        this.showTaskDetails = true;
    }

    closeModalOfCreateTaskForGoal(event) {
        this.showTask = event.detail;
        this.showTaskDetails = event.detail;
        console.log('this.showTask-- ' + this.showTask + ' -- ' + this.showTaskDetails);
    }
    openGoalPopup(event) {
        this.typeGoal = 'KPI';
        this.showGoal = true;
        this.kpiId = event.target.dataset.id;
        this.kpiweightage = event.target.dataset.kpiweightage;
        this.goalofwhich = event.target.dataset.goalOfWhich;
        console.log('440-- ' + this.showGoal);
    }
    openCompetencyGoalPopup(event) {
        this.typeGoal = 'Competency';
        this.showGoal = true;
        this.kpiId = event.target.dataset.id;
        this.kpiweightage = event.target.dataset.kpiweightage;
        this.goalofwhich = event.target.dataset.goalOfWhich;
        console.log('448-- ' + this.showGoal);
    }
    openGoalPopupFalse(event) {
        this.showGoal = event.detail;
        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
        this.showGoal = false;
        console.log('454-- ' + this.showGoal);
    }
    openAddCommentModal(event) {
        this.commentSave = false;
        this.addCommentModal = true;
        this.kpiId = event.target.dataset.id;
        this.checkManager = event.target.dataset.showManager;
    }
    openGoalCommentModal(event) {
        this.commentSave = false;
        this.goalCommentModal = true;
        this.goalId = event.target.dataset.id;
        console.log('this.goalId --' + this.goalId);
        this.checkManager = event.target.dataset.showManager;
        this.goalCommentValue = '';
    }
    updateStatusModal(event) {
        this.statusModal = true;
        this.weightageModal = false;
        this.goalId = event.target.dataset.id;
        this.statusNewValue = event.target.dataset.status;
    }

    updateWeightageModal(event) {
        this.statusModal = true;
        this.weightageModal = true;
        this.goalId = event.target.dataset.id;
        this.kpiweightage = event.target.dataset.kpiweightage;
        this.goalOldWeightage = event.target.dataset.kpiweightage;
        this.totalweightage = event.target.dataset.totalweightage;
        console.log('this.kpiWeigtage -- ' + this.kpiweightage);
    }
    updateGoal(event) {
        this.updateGoalModal = true;
        this.goalId = event.target.dataset.id;
        this.updateStartDate = event.target.dataset.startdate;
        this.updateEndDate = event.target.dataset.enddate;
        this.updateDescription = event.target.dataset.description;
        this.updateSuccessMeasurement = event.target.dataset.successmeasurement;
        this.updateManagerComments = event.target.dataset.managercomments;
        this.type = event.target.dataset.type;
        this.name = event.target.dataset.name;
        this.weightageNumber = event.target.dataset.kpiweightage;
        this.goalOldWeightage = event.target.dataset.kpiweightage;
        this.totalweightage = event.target.dataset.totalweightage;
        this.statusNewValue = event.target.dataset.status;
    }
    closeGoalModal() {
        this.updateGoalModal = false;
    }
    handleWeightageChange(event) {
        this.weightageNumber = event.target.value;
        this.statusNewValue = '';
    }
    handleUpdateStartDateChange(event) {
        console.log('updateStartDate -- ');
        this.updateStartDate = event.target.value;
    }
    handleUpdateEndDateChange(event) {
        console.log('updateEndDate -- ');
        this.updateEndDate = event.target.value;
    }
    handleUpdateDescriptionChange(event) {
        console.log('updateDescription -- ');
        this.updateDescription = event.target.value;
    }
    handleUpdateSuccessMeasurementChange(event) {
        console.log('updateSuccessMeasurement -- ');
        this.updateSuccessMeasurement = event.target.value;
    }
    handleType(event) {
        this.type = event.detail.value;
    }
    handleName(event) {
        this.name = event.target.value;
    }
    commentHandler(event) {
        this.commentValue = event.detail.value;
    }
    goalCommentHandler(event) {
        this.goalCommentValue = event.detail.value;
    }
    submitDetails() {
        this.commentSave = true;
        if (this.commentValue === undefined || this.commentValue == '') {
            this.showToast('Error!', 'An empty comment cannot be accepted.', 'error');
        } else {
            updateComment({ kpiId: this.kpiId, comment: this.commentValue, managerCheck: this.checkManager })
                .then(result => {
                    console.log(result);
                    if (result == 'Success') {
                        this.showToast('Success!', 'Comments saved!.', 'success');
                        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
                        this.addCommentModal = false;
                        this.commentValue = '';
                    }
                    else {
                        this.showToast('Error!!', 'error', result);
                    }
                }
                )
                .catch(error => { });

            savePIPComment({ pIPId: null, comment: this.commentValue, caId: null, kpiId: this.kpiId })
                .then((result) => {
                    if (result == 'SUCCESS') {
                        this.showToast('Success!', 'Comments saved!.', 'success');
                        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
                        this.addCommentModal = false;
                        this.commentValue = '';
                    }
                    else {
                        this.showToast('Error!!', 'error', result);
                    }
                })
        }
    }

    updateGoalStatus() {
        let weightageDifference;
        let newWeightage;
        if (parseInt(this.goalOldWeightage) < parseInt(this.weightageNumber)) {
            weightageDifference = parseInt(this.weightageNumber) - parseInt(this.goalOldWeightage);
            newWeightage = parseInt(this.totalweightage) + parseInt(weightageDifference);
        } else {
            weightageDifference = parseInt(this.goalOldWeightage) - parseInt(this.weightageNumber);
            newWeightage = parseInt(this.totalweightage) - parseInt(weightageDifference);
        }
        
        console.log(' -- ' + this.totalweightage + ' -- ' + this.weightageNumber + ' -- ' + this.goalOldWeightage + ' -- ' + newWeightage);
        if (this.weightageModal && this.weightageNumber === undefined) {
            this.showToast('Error!', 'Weightage should not be empty.', 'error');
        } else if (parseInt(newWeightage) > 100) { //}else if(parseInt(this.weightageNumber) > 100){
            this.showToast('Error!', 'Under a KPI or Competency all goal weightage cannot be more then 100%.', 'error');
        } else if (!this.weightageModal && this.statusNewValue === undefined) {
            this.showToast('Error!', 'Status should not be empty.', 'error');
        } else {
            this.statusModal = false;
            this.weightageModal = false;
            console.log('update goal --> ');
            updateGoal({ toUpdateGoalId: this.goalId, status: this.statusNewValue, goalWeightage: this.weightageNumber })
                .then(result => {
                    console.log(' updated goal');
                    console.log(result);
                    if (result == 'Success') {
                        this.showToast('Success!', 'Changes saved successfully!.', 'success');
                        this.weightageNumber = '';
                        this.goalOldWeightage = '';
                        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
                        this.addCommentModal = false;
                    }
                    else {
                        this.showToast('Error!!', 'error', result);
                    }
                }
                )
                .catch(error => { });
        }

    }

    submitGoalComment() {
        if (this.goalCommentValue === undefined) {
            this.showToast('Error!', 'An empty comment cannot be accepted.', 'error');
        } else {
            updateGoalComment({ goalId: this.goalId, comment: this.goalCommentValue })
                .then(result => {
                    console.log(result);
                    if (result == 'Success') {
                        this.showToast('Success!', 'Comments saved!.', 'success');
                        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
                        this.goalCommentModal = false;
                    }
                    else {
                        this.showToast('Error!', 'error', result);
                    }
                }
                )
                .catch(error => { });
            savePIPComment({ pIPId: null, comment: this.goalCommentValue, caId: null, kpiId: null, goalId: this.goalId })
                .then((result) => {
                    if (result == 'SUCCESS') {
                        this.showToast('Success!', 'Comments saved!.', 'success');
                        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
                        this.goalCommentModal = '';
                    }
                    else {
                        this.showToast('Error!!', 'error', result);
                    }
                })
        }
    }

    handleSubmit() {
        console.log('this.goalId -- ' + this.kpiweightage);
        var prf = {};
        prf.Id = this.goalId;
        prf.Name = this.name;
        prf.Type__c = this.type;
        prf.Weightage__c = this.weightageNumber;
        prf.Description__c = this.updateDescription;
        prf.Start_Date__c = this.updateStartDate;
        prf.End_Date__c = this.updateEndDate;
        prf.Success_Measurement__c = this.updateSuccessMeasurement;

        let weightageDifference;
        let newWeightage;
        if (parseInt(this.goalOldWeightage) < parseInt(this.weightageNumber)) {
            weightageDifference = parseInt(this.weightageNumber) - parseInt(this.goalOldWeightage);
            newWeightage = parseInt(this.totalweightage) + parseInt(weightageDifference);
            console.log('newWeightage1 -- ' + newWeightage + ' -- ' + parseInt(this.totalweightage) + ' -- ' + parseInt(weightageDifference));
        } else {
            weightageDifference = parseInt(this.goalOldWeightage) - parseInt(this.weightageNumber);
            newWeightage = parseInt(this.totalweightage) - parseInt(weightageDifference);
            console.log('newWeightage2 -- ' + newWeightage + ' -- ' + parseInt(this.totalweightage) + ' -- ' + parseInt(weightageDifference));

        }

        console.log('this.weightageNumber -- ' + this.weightageNumber + ' this.kpiweightage -- ' + this.kpiweightage + ' this.goalOldWeightage -- ' + this.goalOldWeightage + ' newWeightage -- ' + newWeightage);

        if (this.updateSuccessMeasurement === '' || this.updateSuccessMeasurement == undefined || this.updateSuccessMeasurement == null || this.updateDescription === '' || this.updateDescription == undefined|| this.updateDescription == null || this.name === '' || this.weightageNumber === '' || this.updateStartDate === null || this.updateEndDate === null || this.updateStartDate === undefined || this.updateEndDate === undefined) {
            this.showToast('Error!', 'Required fields missing.', 'error');
        } else if (parseInt(newWeightage) > 100) {
            console.log(' --------- ' + this.kpiweightage);
            this.showToast('Error!', 'Under a KPI or Competency all goal weightage cannot be more then 100%.', 'error');
        } else if(this.updateStartDate > this.updateEndDate) {
            this.showToast('Error!', 'Start Date can not be after end date.', 'error');
        } else {
            this.updateGoalModal = false;
            editGoal({ prf: JSON.stringify(prf) })
                .then(result => {
                    console.log(result);
                    if (result == 'Success') {
                        this.showToast('Success!', 'Goal updated successfully!', 'success');
                        this.fetchPerformanceRecords(this.selectedEmployeeId, this.selectedEmployeeName);
                    }
                    else {
                        this.showToast('Error!', result, 'error');
                    }
                }
                )
                .catch(error => { });
        }
    }

    closeModal() {
        this.addCommentModal = false;
        this.statusModal = false;
        this.weightageNumber = '';
    }
    goalCloseModal() {
        this.goalCommentModal = false;
    }
    closeCommentModal() {
        this.showCommentsModal = false;
        this.showAdditionalGoals = false;
        this.showTask = false;
    }

    handleSave(event) {
        let isSave = event.target.value;
        this.isLoading = true;
        let goalListToUpdate = [];
        let isValid = true;
        let perfObj = {};

        let listOfKPIsGoalsMapTemp = [...this.listOfKPIsGoalsMap];
        for (let i = 0; i < listOfKPIsGoalsMapTemp.length; i++) {
            let goalsList = listOfKPIsGoalsMapTemp[i].value;
            for (let j = 0; j < goalsList.length; j++) {
                let obj = {};
                obj.Id = goalsList[j].Id;
                obj.Rating__c = goalsList[j].Rating__c;
                obj.Manager_Comments__c = goalsList[j].Manager_Comments__c;
                obj.Employee_Comments__c = goalsList[j].Employee_Comments__c;
                obj.Manager_Ratings__c = goalsList[j].Manager_Ratings__c;
                isValid = this.checkRecordValid(obj, isSave);
                if (!isValid) break;
                goalListToUpdate.push(obj);
            }
        }

        if (isValid) {
            let compentencyList = [...this.compentencyList];
            for (let i = 0; i < compentencyList.length; i++) {
                let obj = {};
                obj.Id = compentencyList[i].Id;
                obj.Rating__c = compentencyList[i].Rating__c;
                obj.Manager_Comments__c = compentencyList[i].Manager_Comments__c;
                obj.Employee_Comments__c = compentencyList[i].Employee_Comments__c;
                obj.Manager_Ratings__c = compentencyList[i].Manager_Ratings__c;
                isValid = this.checkRecordValid(obj, isSave);
                if (!isValid) break;
                goalListToUpdate.push(obj);
            }
        }
        if (isValid) {
            let additionalGoalsList = [...this.additionalGoalsList];
            for (let i = 0; i < additionalGoalsList.length; i++) {
                let obj = {};
                obj.Id = additionalGoalsList[i].Id;
                obj.Name = additionalGoalsList[i].Name;
                obj.Additional_Goal_Description__c = additionalGoalsList[i].Additional_Goal_Description__c;
                obj.Status__c = additionalGoalsList[i].Status__c;
                obj.Measure_of_success__c = additionalGoalsList[i].Measure_of_success__c;
                obj.Learning_and_Development__c = additionalGoalsList[i].Learning_and_Development__c;
                obj.Start_Date__c = additionalGoalsList[i].Start_Date__c;
                obj.End_Date__c = additionalGoalsList[i].End_Date__c;
                obj.Manager_Comments__c = additionalGoalsList[i].Manager_Comments__c;
                obj.Employee_Comments__c = additionalGoalsList[i].Employee_Comments__c;
                obj.Manager_Ratings__c = additionalGoalsList[i].Manager_Ratings__c;
                obj.Rating__c = additionalGoalsList[i].Rating__c;
                isValid = this.checkRecordValid(obj, isSave);
                if (!isValid) break;
                goalListToUpdate.push(obj);
            }
        }
        if (isValid) {
            perfObj.Id = this.performanceReviewList[0].Id;
            perfObj.Overall_Ratings__c = this.performanceReviewList[0].Overall_Ratings__c;
            perfObj.Manager_Overall_Comments__c = this.performanceReviewList[0].Manager_Overall_Comments__c;
            let performanceReviewList = this.performanceReviewList;
            if (this.isEmployee && isSave !== 'save') {
                if (!this.viewAsManager) {
                    perfObj.Submitted_By_Employee__c = true;
                    performanceReviewList[0].Submitted_By_Employee__c = true;
                } else {
                    if (!perfObj.Manager_Overall_Comments__c || !perfObj.Overall_Ratings__c) {
                        isValid = false;
                    } else {
                        perfObj.Submitted_By_Manager__c = true;
                        performanceReviewList[0].Submitted_By_Manager__c = true;
                    }
                }
            }
            this.performanceReviewList = performanceReviewList;
        }
        if (!isValid) {
            this.isLoading = false;
            let goalListToUpdate = [];
            this.showToast('Required Field Missing', 'All the fields uunder KPI,Competency and Additional goals must be filled for submitting a recorc', 'error');
        } else {
            handleSave({ goalsList: goalListToUpdate, performance: perfObj })
                .then(result => {
                    this.isLoading = false;
                    this.showToast('', 'Record Updated Succesfully', 'success');
                    this.managerReadOnly = true;
                    this.employeeReadOnly = true;
                })
                .catch(error => {
                    this.isLoading = false;
                    this.showToast('Error', reduceErrors(error).toString(), 'error');
                });
        }

    }
    checkRecordValid(obj, isSave) {
        if (this.isEmployee && isSave !== 'save') {
            if (!this.viewAsManager) {
                if (!obj.Rating__c || !obj.Employee_Comments__c) {
                    return false;
                }
            } else {
                if (!obj.Manager_Comments__c || !obj.Manager_Ratings__c) {
                    return false;
                }

            }
        }
        return true;
    }
    // Handle picklist change event
    handlePicklistChange(event) {
        this.selectedValue = event.detail.value;
    }

    // Handle input change event when editing
    handleInputChange(event) {
        this.editedValue = event.target.value;
    }

    // Enable editing mode
    handleEdit() {
        this.isEditing = true;
        this.editedValue = this.selectedValue; // Initialize edited value with the current selection
    }

    updateStatus(event) {
        this.statusNewValue = event.detail.value;
        this.weightageNumber = '';
    }

    showToast(title, msg, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: msg,
            variant: variant,
        });
        this.dispatchEvent(event);
    }

    iconName = 'utility:chevronright'
    toggleSection(event) {
        let buttonid = event.currentTarget.dataset.buttonid;
        console.log('buttonid', buttonid)
        let currentsection = this.template.querySelector('div[data-id="' + buttonid + '"]');
        const toggleButton = this.template.querySelector('lightning-icon[data-id="' + buttonid + '"]');

        if (currentsection) {
            const displayStyle = window.getComputedStyle(currentsection).getPropertyValue('display');
            if (displayStyle === 'none') {
                currentsection.style.display = 'block';
                toggleButton.iconName = 'utility:chevrondown';
            } else {
                currentsection.style.display = 'none';
                toggleButton.iconName = 'utility:chevronright';
            }
        }
        console.log('currentsection', currentsection)
    }

}