import { LightningElement } from 'lwc';

export default class CaseRecordFormCommunity extends LightningElement 
{
    showChildModal = false
    handleButtonClick(){
        this.showChildModal = true;
    }

    handleClose(event){
        this.showChildModal = event.detail.showModal;
    }
}