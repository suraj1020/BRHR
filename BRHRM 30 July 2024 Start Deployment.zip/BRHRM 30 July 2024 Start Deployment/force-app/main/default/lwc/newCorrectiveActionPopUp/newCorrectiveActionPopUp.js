import { LightningElement, track, api, wire } from 'lwc';
import { getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import { ShowToastEvent } from "lightning/platformShowToastEvent";
import { getObjectInfo , getPicklistValues} from 'lightning/uiObjectInfoApi';
import Corrective_Action_Form_Object from '@salesforce/schema/Corrective_Action_Form__c';
import insertCorrectiveActionForm from '@salesforce/apex/PerformanceImprovementPlanController.insertCorrectiveActionForm';
import updateCorrectiveActionForm from '@salesforce/apex/PerformanceImprovementPlanController.updateCorrectiveActionForm';
import getEmpUnderMangerPicklist from '@salesforce/apex/PerformanceImprovementPlanController.getEmpUnderMangerPicklist';

export default class NewCorrectiveActionPopUp extends LightningElement {
    @track correctiveActionObj = {"SObjectType" : "Corrective_Action_Form__c"};
    @api correctiveActionObjEdit = {}
    @api showNewCorrectiveActionPopUp = false;
    @api showSelectRecType = false;
    brhaviouralRecTypeId = '';
    performanceRecTypeId = '';
    @track behCorrectiveActionForm = [];
    @track perCorrectiveActionForm = [];
    @track behCausationlst = [];
    @track perCausationlst = [];
    @track employeeObject = {};
    behaviouralRecType = false;
    performanceRecType = false;
    showOtherCautionField = false;
    value = '';
    isLoading = false
    @api showEditCorrectiveActionPopUp = false;
    buttonNameOnEdit;
    @track conflictVal = []
    showField = false

    get options() {
        return [
            { label: 'Behavioral', value: 'Be' },
            { label: 'Performance', value: 'PE' },
        ];
    }

    connectedCallback(){
        this.isLoading = true
        this.getEmpPickValues();
        if(this.showEditCorrectiveActionPopUp) {
            this.correctiveActionObj = JSON.parse(JSON.stringify(this.correctiveActionObjEdit));
            if(this.correctiveActionObjEdit.RecordType.Name == 'Performance') {
                this.performanceRecType = true;
                this.behaviouralRecType = false;
                this.isLoading = false
            } else if(this.correctiveActionObjEdit.RecordType.Name == 'Behavioral') {
                this.performanceRecType = false;
                this.behaviouralRecType = true;
                this.isLoading = false
            }

            if (this.correctiveActionObjEdit.hasOwnProperty('Causation__c')) {
                if(Array.isArray(this.correctiveActionObjEdit.Causation__c)) {
                    this.conflictVal = [...this.conflictVal, ...this.correctiveActionObjEdit.Causation__c]
                    if(this.conflictVal.includes('Others')) {
                        this.showOtherCautionField = true;
                    } else {
                        this.showOtherCautionField = false;
                    }
                }else {
                    this.conflictVal = [...this.conflictVal, ...this.correctiveActionObjEdit.Causation__c.split(', ')]
                    if(this.conflictVal.includes('Others')) {
                        this.showOtherCautionField = true;
                    } else {
                        this.showOtherCautionField = false;
                    }
                }
            }
        }
        
        console.log('in connectedcallback from edit data---> > > ' , JSON.stringify(this.correctiveActionObj))
    }

    getEmpPickValues(){
        getEmpUnderMangerPicklist()
        .then(result => {
            this.employeeObject = result;
            this.isLoading = false
        })
        .catch(error => {
            this.isLoading = false
            console.log("---error found while getting picklist values :" + JSON.stringify(error));
        })
    }

    @wire(getObjectInfo, { objectApiName: Corrective_Action_Form_Object })
    getRecTypeIds({error,data}){
       if(data){
        let objArray  = data.recordTypeInfos;
        for (let i in objArray){
            if(objArray[i].name =="Behavioral"){
                this.brhaviouralRecTypeId = objArray[i].recordTypeId;
                console.log("----this.brhaviouralRecTypeId :" + this.brhaviouralRecTypeId);
            }

            if(objArray[i].name == "Performance"){
                this.performanceRecTypeId = objArray[i].recordTypeId;
                console.log("----this.performanceRecTypeId :" + this.performanceRecTypeId);
            }
        }
        }else if(error){
            console.log("error : " + JSON.stringify(error));
        }
    };

    @wire(getPicklistValuesByRecordType, { objectApiName: Corrective_Action_Form_Object, recordTypeId:  '$performanceRecTypeId'})
    performancePicklistValues({error, data}){
    	if(data){
            console.log("--------data in performance"  + JSON.stringify(data));
            let correctiveActionLevels = data.picklistFieldValues.Corrective_Action_Level__c.values;
            console.log("--------correctiveActionLevels"  + JSON.stringify(correctiveActionLevels));
            for (let i = 0; i < correctiveActionLevels.length; i++) {
                this.perCorrectiveActionForm.push({
                    label: correctiveActionLevels[i].label,
                    value: correctiveActionLevels[i].value
                });
            }

            let causationLst = data.picklistFieldValues.Causation__c.values;
            console.log("--------causationLst"  + JSON.stringify(causationLst));
            for (let i = 0; i < causationLst.length; i++) {
                this.perCausationlst.push({
                    label: causationLst[i].label,
                    value: causationLst[i].value
                });
            }

            if(this.perCorrectiveActionForm.length > 0 ) {
                this.showField = true
            }
            console.log("-----this.perCausationlst :" + JSON.stringify(this.perCausationlst));
            console.log("-----this.perCorrectiveActionForm :" + JSON.stringify(this.perCorrectiveActionForm));
        }else if(error){
        	console.log("----error : " + JSON.stringify(error));
        }
    }

    @wire(getPicklistValuesByRecordType, { objectApiName: Corrective_Action_Form_Object, recordTypeId:  '$brhaviouralRecTypeId'})
    behaviouralPicklistValues({error, data}){
    	if(data){
            let causationLst = data.picklistFieldValues.Causation__c.values;
            for (let i = 0; i < causationLst.length; i++) {
                this.behCausationlst.push({
                    label: causationLst[i].label,
                    value: causationLst[i].value
                });
            }

            let correctiveActionLevels = data.picklistFieldValues.Corrective_Action_Level__c.values;
            for (let i = 0; i < correctiveActionLevels.length; i++) {
                this.behCorrectiveActionForm.push({
                    label: correctiveActionLevels[i].label,
                    value: correctiveActionLevels[i].value
                });
            }
            if(this.behCorrectiveActionForm.length > 0 ) {
                this.showField = true
            }
            console.log("-----this.behCorrectiveActionForm :" + JSON.stringify(this.behCorrectiveActionForm));
            console.log("-----this.behCausationlst :" + JSON.stringify(this.behCausationlst));
        }else if(error){
        	console.log("----error : " + JSON.stringify(error));
        }
    }

    handleCloseEdit(event) {
        this.showEditCorrectiveActionPopUp = false;
        this.dispatchEvent(new CustomEvent('closepopup', {
            detail : {
                closePopUp : this.showEditCorrectiveActionPopUp
            }
        }));
    }

    handleChange(event){
        console.log('name in change---> ' , event.target.name)
        console.log('value in change---> ' , event.target.value)
        if(event.target.name == "selectRecType"){
            if(event.target.value == "Be"){
                this.correctiveActionObj.RecordTypeId = this.brhaviouralRecTypeId;
                this.performanceRecType = false;
                this.behaviouralRecType = true;
            }else if(event.target.value == "PE"){
                this.correctiveActionObj.RecordTypeId = this.performanceRecTypeId;
                this.behaviouralRecType = false;
                this.performanceRecType = true;
            }
        }

        if(event.target.name == "Causation__c"){
            if(event.target.value.includes("Others")){
                this.correctiveActionObj.Causation__c = event.target.value;
                this.showOtherCautionField = true;
            }else{
                this.showOtherCautionField = false;
            }
        }else if(event.target.value != "Be" && event.target.value != "PE"){
            this.correctiveActionObj[event.target.name] = event.target.value;
        }
    }

    handleEditSave(event) {
        this.isLoading = true
        this.buttonNameOnEdit = event.target.name
        const date = new Date();
        var inputDate = new Date(this.correctiveActionObj.Next_Review_Date__c);
        if(inputDate.setHours(0,0,0,0) < date.setHours(0,0,0,0)) {
            this.isLoading = false
            const evt = new ShowToastEvent({
                title: "Aww! Date is not future date!!",
                message: "Please fill the future date.",
                variant: "error"
            });
            this.dispatchEvent(evt);
        }else {
            if(this.correctiveActionObj.Employee_Name__c){
                updateCorrectiveActionForm({objCorrectiveAction : this.correctiveActionObj, buttonName : this.buttonNameOnEdit})
                .then(result => {
                    const evt = new ShowToastEvent({
                        title: "Record updated successfully!!",
                        message: "Corrective Action Form updated successfully.",
                        variant: "success"
                    });
                    this.dispatchEvent(evt);
                    this.showEditCorrectiveActionPopUp = false;
                    this.isLoading = false;
                    this.dispatchEvent(new CustomEvent('closepopup', {
                        detail : {
                            closePopUp : this.showEditCorrectiveActionPopUp,
                            onEditData : this.correctiveActionObj
                        }
                    }));
                })
                .catch(error => {
                    console.log("---error found :" + JSON.stringify(error));
                    const evt = new ShowToastEvent({
                        title: "Aww! Something went wrong!!",
                        message: "Please check all the values and save again.",
                        variant: "error"
                    });
                    this.dispatchEvent(evt);
                })
            }else{
                this.isLoading = false
                const evt = new ShowToastEvent({
                    title: "Aww! Something went wrong!!",
                    message: "Please fill all the mandatory fields and save again.",
                    variant: "error"
                });
                this.dispatchEvent(evt);
            }
        }
    }

    handleClick(event){
        if(event.target.name == "nextClick"){
            if(this.correctiveActionObj.RecordTypeId){
                this.showSelectRecType = false;
                this.showNewCorrectiveActionPopUp = true;
            }else{
                const evt = new ShowToastEvent({
                    title: "Please select a Record Type!!",
                    message: "Select a recordtype to move forward.",
                    variant: "error"
                });
                this.dispatchEvent(evt);
            }
        }

        if(event.target.name == "cancelClick"){
            this.showSelectRecType = false;
            this.showNewCorrectiveActionPopUp = false;
            this.showSelectRecType = this.showNewCorrectiveActionPopUp;
            this.dispatchEvent(new CustomEvent('closepopup', {
                detail : {
                    closePopUp : this.showSelectRecType
                }
            }));
        }

        if(event.target.name == "saveCorrectiveRecord"){
            this.isLoading = true
            const date = new Date();

            var inputDate = new Date(this.correctiveActionObj.Next_Review_Date__c);
            console.log("---inserted Corrective Rec Id :" + JSON.stringify(this.correctiveActionObj));
            if(inputDate.setHours(0,0,0,0) < date.setHours(0,0,0,0)) {
                this.isLoading = false
                const evt = new ShowToastEvent({
                    title: "Aww! Date is not future date!!",
                    message: "Please fill the future date.",
                    variant: "error"
                });
                this.dispatchEvent(evt);
            } else {
                if(this.correctiveActionObj.Employee_Name__c){
                    insertCorrectiveActionForm({objCorrectiveAction : this.correctiveActionObj})
                    .then(result => {
                        const evt = new ShowToastEvent({
                            title: "Record created successfully!!",
                            message: "New Corrective Action Form created successfully.",
                            variant: "success"
                        });
                        this.dispatchEvent(evt);
                        this.showNewCorrectiveActionPopUp = false;
                        this.isLoading = false;
                        this.dispatchEvent(new CustomEvent('closepopup', {
                            detail : {
                                closePopUp : this.showNewCorrectiveActionPopUp
                            }
                        }));
                    })
                    .catch(error => {
                        console.log("---error found :" + JSON.stringify(error));
                        const evt = new ShowToastEvent({
                            title: "Aww! Something went wrong!!",
                            message: "Please check all the values and save again.",
                            variant: "error"
                        });
                        this.dispatchEvent(evt);
                    })
                }else{
                    this.isLoading = false
                    const evt = new ShowToastEvent({
                        title: "Aww! Something went wrong!!",
                        message: "Please fill all the mandatory fields and save again.",
                        variant: "error"
                    });
                    this.dispatchEvent(evt);
                }
            }
            
        }
    }
}