import { LightningElement, api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createActionPlan from '@salesforce/apex/CreateTaskForGoalController.createActionPlan';
import deleteSelectedRecord from '@salesforce/apex/CreateTaskForGoalController.deleteSelectedRecord';
import updateExistingActionPlanAndTask from '@salesforce/apex/CreateTaskForGoalController.updateExistingActionPlanAndTask';
import getExistingActionPlanAndTask from '@salesforce/apex/CreateTaskForGoalController.getExistingActionPlanAndTask';
import getpipExistingActionPlanAndTask from '@salesforce/apex/CreateTaskForGoalController.getpipExistingActionPlanAndTask';
import getTypePicklistValues from '@salesforce/apex/CreateTaskForGoalController.getTypePicklistValues';
import getPriorityPicklistValues from '@salesforce/apex/CreateTaskForGoalController.getPriorityPicklistValues';
import getStatusPicklistValues from '@salesforce/apex/CreateTaskForGoalController.getStatusPicklistValues';

export default class CreateTaskForGoal extends LightningElement {

    @api goalId;
    @api pipId;
    @api caId;
    @api empId;
    @api isModalOpen;
    @api isModalOpenInitial;
    @track isUpdateButtonShow = false;
    @track isEdited = false;
    @track showExistingData = false;
    @track showSpinner = false;
    @track taskRecToDisplayLst = [];
    @track actionPlanObj = { "SObjectType": "LabsActionPlans__ActionPlan__c" };
    @track existingData = [];
    @track typePicklistOptions = [];
    @track priorityPicklistOptions = [];
    @track statusPicklistOptions = [];
    @track showSaveButton = true;
    @api loggedInUser;

    connectedCallback() {
        this.getPicklistValues();
        this.getExistingActionPlanAndTaskDetails();
    }

    getExistingActionPlanAndTaskDetails() {
        if (this.goalId && this.empId) {
            console.log('---------');
            getExistingActionPlanAndTask({ goalId: this.goalId, empId: this.empId })
                .then(result => {
                    if (result != null && result != undefined && result != '') {
                        this.showExistingData = true;
                        this.existingData = result;
                        console.log('----this.existingData---' + JSON.stringify(this.existingData));
                        for (let i = 0; i < this.existingData.length; i++) {
                            this.existingData[i].isEdited = false;
                        }
                    } else {
                        this.showExistingData = false;
                        this.existingData = [];
                        console.log('----There is no existing data available---');
                    }
                })
                .catch(error => {
                    console.log('------error while fetching existing records-----' + JSON.stringify(error));
                })
        }
        if (this.pipId || this.caId) {
            console.log('---------');
            getpipExistingActionPlanAndTask({ pipId: this.pipId , caId : this.caId })
                .then(result => {
                    if (result != null && result != undefined && result != '') {
                        this.showExistingData = true;
                        this.existingData = result;
                        console.log('----this.existingData---' + JSON.stringify(this.existingData));
                        for (let i = 0; i < this.existingData.length; i++) {
                            this.existingData[i].isEdited = false;
                        }
                    } else {
                        this.showExistingData = false;
                        this.existingData = [];
                        console.log('----There is no existing data available---');
                    }
                })
                .catch(error => {
                    console.log('------error while fetching existing records-----' + JSON.stringify(error));
                })
        }
    }

    handleChange(event) {
        if (event.target.name == 'actionPlanName') {
            this.actionPlanObj.Name = event.detail.value;
        }
        else if (event.target.name == 'planStartDate') {
            this.actionPlanObj.LabsActionPlans__StartDate__c = event.detail.value;

        }
        else if (event.target.name == 'planEndDate') {
            this.actionPlanObj.Plan_End_Date__c = event.target.value;
        }
        else if (event.target.name == 'taskName') {
            const idx = event.currentTarget.dataset.index;
            this.taskRecToDisplayLst[idx].LabsActionPlans__Subject__c = event.target.value;
        }
        else if (event.target.name == 'type') {
            const idx = event.currentTarget.dataset.index;
            this.taskRecToDisplayLst[idx].LabsActionPlans__Type__c = event.target.value;
        }
        else if (event.target.name == 'priority') {
            const idx = event.currentTarget.dataset.index;
            this.taskRecToDisplayLst[idx].LabsActionPlans__Priority__c = event.target.value;

        }
        else if (event.target.name == 'status') {
            const idx = event.currentTarget.dataset.index;
            this.taskRecToDisplayLst[idx].LabsActionPlans__Status__c = event.target.value;
        }
        else if (event.target.name == 'dueDate') {
            const idx = event.currentTarget.dataset.index;
            this.taskRecToDisplayLst[idx].LabsActionPlans__ActivityDate__c = event.target.value;
        }
        else if (event.target.name == 'startDate') {
            const idx = event.currentTarget.dataset.index;
            this.taskRecToDisplayLst[idx].Start_Date__c = event.target.value;
        }
        //----------------------------------------------------------------------
        else if (event.target.name == 'actionPlanStartDateToBeSave') {
            const idx = event.currentTarget.dataset.index;
            this.existingData[idx].actionPlanStartDate = event.target.value;
        }
        else if (event.target.name == 'actionPlanTaskSubjectToBeSave') {
            const idx = event.currentTarget.dataset.index;
            console.log('----------')
            this.existingData[idx].taskSubject = event.target.value;
        }
        else if (event.target.name == 'actionPlanTaskPriorityToBeSave') {
            const idx = event.currentTarget.dataset.index;
            this.existingData[idx].taskPriority = event.target.value;
        }
        else if (event.target.name == 'actionPlanTaskStatusToBeSave') {
            const idx = event.currentTarget.dataset.index;
            this.existingData[idx].taskStatus = event.target.value;
        }
        else if (event.target.name == 'actionPlanTaskTypeToBeSave') {
            const idx = event.currentTarget.dataset.index;
            this.existingData[idx].taskType = event.target.value;
        }
        else if (event.target.name == 'actionPlanTaskTypeToBeSave') {
            const idx = event.currentTarget.dataset.index;
            this.existingData[idx].taskDueDate = event.target.value;
        }
    }

    addTaskHandler(event) {
        this.taskRecToDisplayLst.push({
            SObjectType: "LabsActionPlans__APTask__c",
            Id: null,
            LabsActionPlans__Subject__c: '',
            LabsActionPlans__Type__c: '',
            LabsActionPlans__Priority__c: '',
            LabsActionPlans__Status__c: '',
            Start_Date__c: '',
            LabsActionPlans__ActivityDate__c: ''
        });
    }

    addClickHandler(event) {
        const idx = event.currentTarget.dataset.index;

        this.existingData.unshift({
            actionPlanName: this.existingData[idx].actionPlanName,
            actionPlanStartDate: '',
            actionPlanEndDate: '',
            taskSubject: '',
            taskPriority: '',
            taskType: '',
            taskStatus: '',
            actionPlanId: this.existingData[idx].actionPlanId,
            taskGoalId: this.existingData[idx].taskGoalId,
            taskId: null,
            isEdited: true
        });

        this.isUpdateButtonShow = true;
    }

    editClickHandler(event) {
        const idx = event.currentTarget.dataset.index;
        console.log('------idx-----' + idx);
        this.existingData[idx].isEdited = true;
        this.isUpdateButtonShow = true;
    }

    saveClickHandler() {
        this.existingData = this.existingData.map(task => {
            const { isEdited, ...rest } = task;
            return rest;
        });

        let actionPlanTaskToBeUpsert = [];
        let tempArray = [];

        this.existingData.forEach(function (item) {
            const actionPlanData = {
                Id: item.actionPlanId,
                LabsActionPlans__StartDate__c: item.actionPlanStartDate,
                Employee__c: item.actionPlanEmpId,
                Performance_Improvement_Plan__c: item.actionPlanPipId,
                Corrective_Action_Form__c : item.actionPlanCAId
            };
            tempArray.push(actionPlanData);

            const actionPlanTaskData = {
                Id: item.taskId,
                Goal__c: item.taskGoalId,
                LabsActionPlans__Action_Plan__c: item.actionPlanId,
                LabsActionPlans__Priority__c: item.taskPriority,
                LabsActionPlans__Status__c: item.taskStatus,
                LabsActionPlans__Subject__c: item.taskSubject,
                LabsActionPlans__Type__c: item.taskType
            };
            actionPlanTaskToBeUpsert.push(actionPlanTaskData);
        });

        const uniqueObjectsMap = new Map();

        tempArray.forEach(item => {
            uniqueObjectsMap.set(item.Id, item);
        });

        let actionPlanLstToBeUpsert = Array.from(uniqueObjectsMap.values());

        let isArrayFilled = false;

        for (let i = 0; i < actionPlanTaskToBeUpsert.length; i++) {
            if (actionPlanTaskToBeUpsert[i].LabsActionPlans__Subject__c && actionPlanTaskToBeUpsert[i].LabsActionPlans__Type__c && actionPlanTaskToBeUpsert[i].LabsActionPlans__Status__c && actionPlanTaskToBeUpsert[i].LabsActionPlans__Priority__c) {
                isArrayFilled = true;
            } else {
                isArrayFilled = false;
                break;
            }
        }

        // actionPlanTaskToBeUpsert.forEach(function(obj){
        //     if(obj.LabsActionPlans__Subject__c && obj.LabsActionPlans__Type__c && obj.LabsActionPlans__Status__c && obj.LabsActionPlans__Priority__c){
        //         isArrayFilled = true;
        //     }
        //     else{
        //         isArrayFilled = false;
        //         return;
        //     }
        // });


        console.log('-----isArrayFilled--' + JSON.stringify(isArrayFilled));

        console.log('-----this.existingData--127--' + JSON.stringify(actionPlanLstToBeUpsert));
        console.log('-----this.existingData--128--' + JSON.stringify(actionPlanTaskToBeUpsert));

        if (isArrayFilled) {
            updateExistingActionPlanAndTask({ actionPlanLst: actionPlanLstToBeUpsert, actionPlanTaskLst: actionPlanTaskToBeUpsert })
                .then(result => {
                    this.isUpdateButtonShow = false;
                    this.showNotification('Records updated Successfully!!', result, 'success');
                    this.getExistingActionPlanAndTaskDetails();
                    console.log('----Success---------' + result);
                })
                .catch(error => {
                    console.log('----Error Found while updating---------' + JSON.stringify(error));
                })
        } else {
            this.showNotification('Please fill required fields!!', 'All fields are mandatory while updating a record.', 'error');
            this.getExistingActionPlanAndTaskDetails();
        }


    }

    handleSave() {
        if (this.empId) {
            this.actionPlanObj.Employee__c = this.empId;
        }
        else if (this.pipId) {
            this.actionPlanObj.Performance_Improvement_Plan__c = this.pipId;
        }
        else if(this.caId){
            this.actionPlanObj.Corrective_Action_Form__c = this.caId;
        }
        console.log('---this.taskRecToDisplayLst----120---' + JSON.stringify(this.taskRecToDisplayLst));

        let isDateValid = false;
        let isArrayFilled = false;

        if (this.taskRecToDisplayLst.length > 0) {
            for (let i = 0; i < this.taskRecToDisplayLst.length; i++) {
                if (this.goalId) {
                    this.taskRecToDisplayLst[i].Goal__c = this.goalId;
                }
                if (this.taskRecToDisplayLst[i].LabsActionPlans__Subject__c && this.taskRecToDisplayLst[i].LabsActionPlans__Type__c && this.taskRecToDisplayLst[i].LabsActionPlans__Status__c && this.taskRecToDisplayLst[i].LabsActionPlans__Priority__c) {
                    isArrayFilled = true;
                } else {
                    isArrayFilled = false;
                    break;
                }
            }

            if (isArrayFilled) {

                for (let i = 0; i < this.taskRecToDisplayLst.length; i++) {
                    if (this.taskRecToDisplayLst[i].LabsActionPlans__ActivityDate__c > this.actionPlanObj.LabsActionPlans__StartDate__c && this.taskRecToDisplayLst[i].LabsActionPlans__ActivityDate__c < this.actionPlanObj.Plan_End_Date__c &&
                        this.taskRecToDisplayLst[i].Start_Date__c > this.actionPlanObj.LabsActionPlans__StartDate__c && this.taskRecToDisplayLst[i].Start_Date__c < this.actionPlanObj.Plan_End_Date__c &&
                        this.taskRecToDisplayLst[i].Start_Date__c < this.taskRecToDisplayLst[i].LabsActionPlans__ActivityDate__c) {
                        isDateValid = true;
                    }
                    else {
                        isDateValid = false;
                        break;
                    }
                }

                if (isDateValid) {
                    this.showSaveButton = false;
                    createActionPlan({ actionPlanObj: this.actionPlanObj, actionPlanTaskLst: this.taskRecToDisplayLst })
                        .then(result => {
                            this.showNotification('Records Saved Successfully!!', result, 'success');
                            this.closeModal();
                            this.showSpinner = true;
                            setTimeout(() => {
                                this.showSpinner = false;

                            }, 0.1);

                        })
                        .catch(error => {
                            console.log('----Error----' + JSON.stringify(error));
                        })
                } else {
                    this.showNotification('Enter Dates in valid range!', 'Task Dates should lie between Plan Start Date & End Date', 'error');
                }
            } else {
                this.showNotification('Please fill required fields!!', 'All fields are mandatory while creating a record.', 'error');
            }
        } else {
            this.showNotification('Please add Task too!!', 'Adding at least a task is mandatory while creating a record.', 'error');
        }
    }

    addDeleteClickHandler(event) {
        //let button = event.getSource();
    	//button.set('v.disabled',true);
        
        const idx = event.currentTarget.dataset.index;
        console.log('------idx-----' + idx);
        let idToBeDeletedOfTask = this.existingData[idx].taskId;
        this.existingData[idx].delete = true;
        console.log('------idToBeDeletedOfTask-----' + idToBeDeletedOfTask);

        if (idToBeDeletedOfTask) {
            deleteSelectedRecord({ toBeDeleteTaskRecId: idToBeDeletedOfTask })
                .then(result => {
                    this.showNotification('Task Deleted Successfully!!', result, 'success');
                    this.getExistingActionPlanAndTaskDetails();
                })
                .catch(error => {
                    console.log('--------error succeed---' + JSON.stringify(error));
                    this.showNotification('Some error occured!!', 'Task is not deleted yet.', 'error');
                })
        }
    }

    showNotification(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }

    getPicklistValues() {
        getTypePicklistValues()
            .then(result => {
                this.typePicklistOptions = result;
            })
            .catch(error => {
                console.log('---error---' + JSON.stringify(error));
            })

        getPriorityPicklistValues()
            .then(result => {
                this.priorityPicklistOptions = result;
            })
            .catch(error => {
                console.log('---error---' + JSON.stringify(error));
            })

        getStatusPicklistValues()
            .then(result => {
                this.statusPicklistOptions = result;
            })
            .catch(error => {
                console.log('---error---' + JSON.stringify(error));
            })
    }

    closeModal() {
        this.isModalOpen = false;

        this.dispatchEvent(new CustomEvent('showmodaloff', {
            detail: this.isModalOpen
        }));
    }

    handleCancelClick() {
        this.isModalOpen = false;

        this.dispatchEvent(new CustomEvent('showmodaloff', {
            detail: this.isModalOpen
        }));
    }

    cancelClickHandler() {
        this.isModalOpenInitial = false;

        this.dispatchEvent(new CustomEvent('showmodaloff', {
            detail: this.isModalOpen
        }));
    }

}
// import { LightningElement, api, track, wire } from 'lwc';
// import { ShowToastEvent } from 'lightning/platformShowToastEvent';
// import createActionPlan from '@salesforce/apex/CreateTaskForGoalController.createActionPlan';
// import updateExistingActionPlanAndTask from '@salesforce/apex/CreateTaskForGoalController.updateExistingActionPlanAndTask';
// import getExistingActionPlanAndTask from '@salesforce/apex/CreateTaskForGoalController.getExistingActionPlanAndTask';
// import getTypePicklistValues from '@salesforce/apex/CreateTaskForGoalController.getTypePicklistValues';
// import getPriorityPicklistValues from '@salesforce/apex/CreateTaskForGoalController.getPriorityPicklistValues';
// import getStatusPicklistValues from '@salesforce/apex/CreateTaskForGoalController.getStatusPicklistValues';

// export default class CreateTaskForGoal extends LightningElement {

//     @api goalId;
//     @api empId;
//     @api isModalOpen;
//     @api isModalOpenInitial;
//     @track isUpdateButtonShow = false;
//     @track isEdited = false;
//     @track showExistingData = false;
//     @track showSpinner = false;
//     @track taskRecToDisplayLst = [];
//     @track actionPlanObj = {"SObjectType" : "LabsActionPlans__ActionPlan__c"};
//     @track existingData = [];
//     //@track existingDataUpdatedActionPlan
//     @track typePicklistOptions = [];
//     @track priorityPicklistOptions = [];
//     @track statusPicklistOptions =[];

//     connectedCallback() {
//         this.getPicklistValues();
//         this.getExistingActionPlanAndTaskDetails();
//     }

//     getExistingActionPlanAndTaskDetails(){
//         if(this.goalId && this.empId){
//             console.log('---------');
//             getExistingActionPlanAndTask({goalId : this.goalId, empId : this.empId})
//             .then(result => {
//                 if(result != null && result != undefined && result != ''){
//                     this.showExistingData = true;
//                     this.existingData = result;
//                     console.log('----this.existingData---' + JSON.stringify(this.existingData));
//                     for (let i = 0; i < this.existingData.length; i++) {
//                         this.existingData[i].isEdited = false;
//                     }
//                 }else{
//                     console.log('----There is no existing data available---');
//                 }
//             })
//             .catch(error => {
//                 console.log('------error while fetching existing records-----' + JSON.stringify(error));
//             })
//         }
//     }

//     handleChange(event){
//         if(event.target.name == 'actionPlanName'){
//             this.actionPlanObj.Name = event.detail.value;
//         }
//         else if(event.target.name == 'planStartDate'){
//             this.actionPlanObj.LabsActionPlans__StartDate__c = event.detail.value;

//         }
//         else if(event.target.name == 'taskName'){
//             const idx = event.currentTarget.dataset.index;
//             this.taskRecToDisplayLst[idx].LabsActionPlans__Subject__c = event.target.value;
//         }
//         else if(event.target.name == 'type'){
//             const idx = event.currentTarget.dataset.index;
//             this.taskRecToDisplayLst[idx].LabsActionPlans__Type__c = event.target.value;
//         }
//         else if(event.target.name == 'priority'){
//             const idx = event.currentTarget.dataset.index;
//             this.taskRecToDisplayLst[idx].LabsActionPlans__Priority__c = event.target.value;

//         }
//         else if(event.target.name == 'status'){
//             const idx = event.currentTarget.dataset.index;
//             this.taskRecToDisplayLst[idx].LabsActionPlans__Status__c = event.target.value;
//         }//----------------------------------------------------------------------
//         else if(event.target.name == 'actionPlanStartDateToBeSave'){
//             const idx = event.currentTarget.dataset.index;
//             this.existingData[idx].actionPlanStartDate = event.target.value;
//         }
//         else if(event.target.name == 'actionPlanTaskSubjectToBeSave'){
//             const idx = event.currentTarget.dataset.index;
//             console.log('----------')
//             this.existingData[idx].taskSubject = event.target.value;
//         }
//         else if(event.target.name == 'actionPlanTaskPriorityToBeSave'){
//             const idx = event.currentTarget.dataset.index;
//             this.existingData[idx].taskPriority = event.target.value;
//         }
//         else if(event.target.name == 'actionPlanTaskStatusToBeSave'){
//             const idx = event.currentTarget.dataset.index;
//             this.existingData[idx].taskStatus = event.target.value;
//         }
//         else if(event.target.name == 'actionPlanTaskTypeToBeSave'){
//             const idx = event.currentTarget.dataset.index;
//             this.existingData[idx].taskType = event.target.value;
//         }
//     }

//     addTaskHandler(event){
//         this.taskRecToDisplayLst.push({
//             SObjectType : "LabsActionPlans__APTask__c",
//             Id: null,
//             LabsActionPlans__Subject__c : '',
//             LabsActionPlans__Type__c : '',
//             LabsActionPlans__Priority__c : '',
//             LabsActionPlans__Status__c : ''
//         });
//     }

//     addClickHandler(event){
//         const idx = event.currentTarget.dataset.index;

//         this.existingData.unshift({
//             actionPlanName : this.existingData[idx].actionPlanName,
//             actionPlanStartDate : '',
//             taskSubject : '',
//             taskPriority : '',
//             taskType : '',
//             taskStatus : '',
//             actionPlanId : this.existingData[idx].actionPlanId,
//             taskGoalId : this.existingData[idx].taskGoalId,
//             taskId : null,
//             isEdited : true
//         });

//         this.isUpdateButtonShow = true;
//     }

//     editClickHandler(event){
//         const idx = event.currentTarget.dataset.index;
//         console.log('------idx-----' + idx);
//         this.existingData[idx].isEdited = true;
//         this.isUpdateButtonShow = true;
//     }

//     saveClickHandler(){
//         this.existingData = this.existingData.map(task => {
//             const { isEdited, ...rest } = task;
//             return rest;
//         });

//         let actionPlanTaskToBeUpsert = [];
//         let tempArray = [];

//         this.existingData.forEach(function (item) {
//             const actionPlanData = {
//                 Id: item.actionPlanId,
//                 LabsActionPlans__StartDate__c: item.actionPlanStartDate,
//                 Employee__c: item.actionPlanEmpId
//             };
//             tempArray.push(actionPlanData);

//             const actionPlanTaskData = {
//                 Id: item.taskId,
//                 Goal__c : item.taskGoalId,
//                 LabsActionPlans__Action_Plan__c : item.actionPlanId,
//                 LabsActionPlans__Priority__c: item.taskPriority,
//                 LabsActionPlans__Status__c: item.taskStatus,
//                 LabsActionPlans__Subject__c: item.taskSubject,
//                 LabsActionPlans__Type__c: item.taskType
//             };
//             actionPlanTaskToBeUpsert.push(actionPlanTaskData);
//         });

//         const uniqueObjectsMap = new Map();

//         tempArray.forEach(item => {
//             uniqueObjectsMap.set(item.Id, item);
//         });

//         let actionPlanLstToBeUpsert = Array.from(uniqueObjectsMap.values());

//         console.log('-----this.existingData--127--' + JSON.stringify(actionPlanLstToBeUpsert));
//         console.log('-----this.existingData--128--' + JSON.stringify(actionPlanTaskToBeUpsert));

//         updateExistingActionPlanAndTask({ actionPlanLst: actionPlanLstToBeUpsert, actionPlanTaskLst : actionPlanTaskToBeUpsert})
//             .then(result => {
//                 this.isUpdateButtonShow = false;
//                 this.showNotification('Records updated Successfully!!', result , 'success');
//                 this.getExistingActionPlanAndTaskDetails();
//                 console.log('----Success---------' + result);
//             })
//             .catch(error => {
//                 console.log('----Error Found while updating---------' + JSON.stringify(error));
//             })
//     }

//     handleSave(){
//         for (let i = 0; i < this.taskRecToDisplayLst.length; i++) {
//             this.taskRecToDisplayLst[i].Goal__c = this.goalId;
//         }
//         this.actionPlanObj.Employee__c = this.empId;
//         console.log('---this.taskRecToDisplayLst----120---' + JSON.stringify(this.taskRecToDisplayLst));

//         if(this.actionPlanObj.Name && this.actionPlanObj.LabsActionPlans__StartDate__c && this.taskRecToDisplayLst){
//             createActionPlan({actionPlanObj : this.actionPlanObj, actionPlanTaskLst : this.taskRecToDisplayLst})
//             .then(result => {
//                 this.showSpinner = true;
//                 setTimeout(() => {
//                     this.showSpinner = false;
//                     this.showNotification('Records Saved Successfully!!', result , 'success');
//                     this.closeModal();
//                 }, 1000);

//             })
//             .catch(error => {
//                 console.log('----Error----' + JSON.stringify(error));
//             })
//         }else{
//             this.showNotification('Please fill required fields!!', 'Attempt to de-reference a null object' , 'error');
//         }
//     }

//     showNotification(title, message, variant) {
//         const evt = new ShowToastEvent({
//             title: title,
//             message: message,
//             variant: variant,
//         });
//         this.dispatchEvent(evt);
//     }

//     getPicklistValues(){
//         getTypePicklistValues()
//         .then(result => {
//             this.typePicklistOptions = result;
//         })
//         .catch(error => {
//             console.log('---error---' + JSON.stringify(error));
//         })

//         getPriorityPicklistValues()
//         .then(result => {
//             this.priorityPicklistOptions = result;
//         })
//         .catch(error => {
//             console.log('---error---' + JSON.stringify(error));
//         })

//         getStatusPicklistValues()
//         .then(result => {
//             this.statusPicklistOptions = result;
//         })
//         .catch(error => {
//             console.log('---error---' + JSON.stringify(error));
//         })
//     }

//     closeModal() {
//         this.isModalOpen = false;

//         this.dispatchEvent(new CustomEvent('showmodaloff', {
//             detail: this.isModalOpen
//         }));
//     }

//     handleCancelClick(){
//         this.isModalOpen = false;

//         this.dispatchEvent(new CustomEvent('showmodaloff', {
//             detail: this.isModalOpen
//         }));
//     }

//     cancelClickHandler(){
//         this.isModalOpenInitial = false;

//         this.dispatchEvent(new CustomEvent('showmodaloff', {
//             detail: this.isModalOpen
//         }));
//     }

// }