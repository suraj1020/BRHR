import { LightningElement, track, wire, api } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
//import Case_Object from '@salesforce/schema/Case';
import ConflictType_Field from '@salesforce/schema/Case.Conflict_Type__c';
import FIRST_TIME_REPORTING from '@salesforce/schema/Case.is_this_the_first_time_you_are_reporting__c';
import CONFLICT_INCLUDING_BAKER from '@salesforce/schema/Case.Does_this_Conflict_involved_BakerRIpley__c';
import ConflictExpect_Field from '@salesforce/schema/Case.How_long_is_the_conflict_expect_to_last__c';
import COMPLAINCE_TYPE from '@salesforce/schema/Case.Compliance_Type__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
export default class ComplianceGeneralInfoChildPage extends LightningElement {

    @api caseObj = {};
    @track caseRecordTypeId;
    @track caseIncidentRecordTypeId;
    @track conflictTypeoptions = [];
    @track firstTypeReportingList = [];
    @track conflictIncludeBakerRipley = [];
    @track conflictExpectoptions = [];
    @track complaineTypeOptions = [];
    showField = false;
    isLoaded = true;
    @api recordTypeName;
    @api currentPage;
    @track conflictVal = [];
    parameters = {};
    subject;
    complianceTypeValue;

    @wire(getObjectInfo, { objectApiName: Case_Object })
    objectInfo({ data, error }) {
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                console.log('rtis[element] ', rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Compliance Related Case') {
                    this.caseRecordTypeId = rtis[element].recordTypeId;
                    console.log('rtis[element].recordTypeId ', rtis[element].recordTypeId);
                }
            });
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: COMPLAINCE_TYPE })
    complainceTypePicklistValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            if (data.values.length > 0) {
                data.values.forEach(val => {
                    this.complaineTypeOptions = [...this.complaineTypeOptions, { value: val.value, label: val.label }];
                });
            }
            console.log('this.complaineTypeOptions--> ' + JSON.stringify(this.complaineTypeOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: ConflictType_Field })
    conflictTypePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            if (data.values.length > 0) {
                data.values.forEach(val => {
                    this.conflictTypeoptions = [...this.conflictTypeoptions, { value: val.value, label: val.label }];
                });
            }
            console.log('this.conflictTypeoptions--> ' + JSON.stringify(this.conflictTypeoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: FIRST_TIME_REPORTING })
    firstTypeReporting({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            if (data.values.length > 0) {
                data.values.forEach(val => {
                    this.firstTypeReportingList = [...this.firstTypeReportingList, { value: val.value, label: val.label }];
                });
            }
            console.log('this.firstTypeReportingList--> ' + JSON.stringify(this.firstTypeReportingList));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: CONFLICT_INCLUDING_BAKER })
    conflictIncludingBaker({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            if (data.values.length > 0) {
                data.values.forEach(val => {
                    this.conflictIncludeBakerRipley = [...this.conflictIncludeBakerRipley, { value: val.value, label: val.label }];
                });
            }
            console.log('this.conflictIncludeBakerRipley--> ' + JSON.stringify(this.conflictIncludeBakerRipley));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: ConflictExpect_Field })
    conflictExpectPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            if (data.values.length > 0) {
                data.values.forEach(val => {
                    this.conflictExpectoptions = [...this.conflictExpectoptions, { value: val.value, label: val.label }];
                });
            }
            console.log('this.conflictExpectoptions--> ' + JSON.stringify(this.conflictExpectoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    isNullOrUndefined(value) {
        return value === undefined || value === null;
    }

    connectedCallback() {
        console.log('@conect call back-------> ' , JSON.stringify(this.caseObj))
        console.log('@conect call back comtype val-------> ' , this.caseObj.Compliance_Type__c)
        this.parameters = this.getQueryParameters();
        this.subject = this.parameters.subject;
        console.log('this.parameters -- '+this.parameters.subject+' --- '+JSON.stringify(this.parameters));

        let obj = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj;
        if(!this.isNullOrUndefined(this.subject)) {
            this.caseObj.Subject = this.subject;
        } else {
            this.caseObj.Subject = this.caseObj.Subject
        }

        console.log('Complaince_Type__c val-----> ' , this.caseObj.Compliance_Type__c)
        if(!this.isNullOrUndefined(this.caseObj.Compliance_Type__c)) {
            this.showField = true;
        } else {
            this.showField = false;
        }
        // if (this.caseObj.hasOwnProperty('Complaince_Type__c')) {
        //     this.showField = true;
        // } else {
        //     this.showField = false;
        // }
        if (this.caseObj.hasOwnProperty('Conflict_Type__c')) {
            if(Array.isArray(this.caseObj.Conflict_Type__c)) {
                this.conflictVal = [...this.conflictVal, ...this.caseObj.Conflict_Type__c]
            }else {
                this.conflictVal = [...this.conflictVal, ...this.caseObj.Conflict_Type__c.split(';')]
            }
        }
        console.log('this.caseObj info child--> ' + JSON.stringify(this.caseObj));
        console.log('this.showField--> ' + JSON.stringify(this.showField));
    }

    getQueryParameters() {

        var params = {};
        var search = location.search.substring(1);

        if (search) {
            params = JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', (key, value) => {
                return key === "" ? value : decodeURIComponent(value)
            });
        }

        return params;
    }

    handleChange(event) {
        if (event.target.name == 'Compliance_Type__c') {
            this.showField = true;  
            this.complianceTypeValue = event.target.value  
        }
        this.caseObj[event.target.name] = event.target.value;
        console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));
    }

    @api
    handleNext() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDBValid = [...this.template.querySelectorAll("lightning-dual-listbox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        this.caseObj.Complaince_Type__c = this.complianceTypeValue
        if (allValid && allCBValid && allDBValid) {
            //this.caseObj.recordTypeId = this.caseRecordTypeId;
            console.log('this.caseObj before save and next', JSON.stringify(this.caseObj));
            this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.caseObj }));
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }
    }


    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }

    @api
    handleSaveAndExit() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDBValid = [...this.template.querySelectorAll("lightning-dual-listbox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        this.caseObj.Complaince_Type__c = this.complianceTypeValue
        console.log('yha pe case data---->>> ' , JSON.stringify(this.caseObj))
        if (allValid && allCBValid && allDBValid) {
            this.isLoaded = false;
            this.caseObj.Status = 'Draft';
            this.caseObj.CurrentPage__c = this.currentPage;
            createCaseOnSubmit({
                caseObj: this.caseObj,
                fileData: [],
                incidentUserList: [],
                recordTypeName: this.recordTypeName,
                injuryData: [],
                damageData: [],
                courseInformation: []
            })
                .then(result => {
                    if (result) {
                        this.isLoaded = true;
                        console.log('--92--> ' + result);
                        this.displayMessage("Success", "success", "Case saved as draft.");
                        this.dispatchEvent(new CustomEvent('saveexit'));
                    }
                }).catch(error => {
                    this.displayMessage("Error", "error", reduceErrors(error).toString());
                    this.isLoaded = true;
                })
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }

    }
}