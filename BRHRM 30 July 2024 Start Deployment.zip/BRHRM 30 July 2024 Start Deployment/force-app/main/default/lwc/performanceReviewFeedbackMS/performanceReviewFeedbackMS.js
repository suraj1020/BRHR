import { LightningElement, track, api } from 'lwc';
import getPerformanceReviewComment from '@salesforce/apex/PerformanceReviewCommentMS.getPerformanceReviewComment';
import saveComment from '@salesforce/apex/PerformanceReviewCommentMS.saveComment';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { reduceErrors } from 'c/lwcUtility';

export default class PerformanceReviewFeedbackMS extends LightningElement {
    commentRecords = [];
    @track isModalOpen = false;
    isLoading = false;
    @api performanceReviewId;
    @api type;

    @track commentValue;

    get showCommentField() {
        return this.type !== 'getComments';
    }

    connectedCallback() {
        if (this.type === 'getComments') {
            this.isLoading = true;
            getPerformanceReviewComment({ 'performanceReviewId': this.performanceReviewId })
                .then(result => {
                    this.isLoading = false;
                    this.commentRecords = result;
                    console.log('this.commentRecords'+JSON.stringify(this.commentRecords));
                })
                .catch(error => {
                    this.isLoading = false;
                    this.showToast('Error', reduceErrors(error).toString(), 'error');
                });
        }
    }

    commentHandler(event) {
        this.commentValue = event.detail.value;
    }

    submitDetails() {
        if (this.isInputValid()) {
            this.isLoading = true;
            saveComment({ commentValue: this.commentValue, performanceReviewId: this.performanceReviewId })
                .then(result => {
                    this.isLoading = false;
                    this.closeModal();
                }).catch(error => {
                    this.isLoading = false;
                    this.showToast('Error', reduceErrors(error).toString(), 'error');
                });
        }
    }
    isInputValid() {
        let isValid = true;
        let inputFields = this.template.querySelectorAll('.validate');
        inputFields.forEach(inputField => {
            if (!inputField.checkValidity()) {
                inputField.reportValidity();
                isValid = false;
            }
        });
        return isValid;
    }

    showToast(title, msg, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: msg,
            variant: variant,
        });
        this.dispatchEvent(event);
    }

    closeModal() {
        this.dispatchEvent(new CustomEvent("close"));
    }
}