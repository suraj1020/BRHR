import { LightningElement,track } from 'lwc';
import filterData from '@salesforce/apex/PerformanceImprovementPlanController.filterData';
import savePIPComment from '@salesforce/apex/PerformanceImprovementPlanController.savePIPComment';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import filterCorrectiveAction from '@salesforce/apex/PerformanceImprovementPlanController.filterCorrectiveAction';
import insertPIPRecord from '@salesforce/apex/PerformanceImprovementPlanController.insertPIPRecord';
import isUserIsAManager from '@salesforce/apex/PerformanceImprovementPlanController.isUserIsAManager';
import getEmpUnderMangerPicklist from '@salesforce/apex/PerformanceImprovementPlanController.getEmpUnderMangerPicklist';
import getuserIdOfSelectedEmployee from '@salesforce/apex/PerformanceImprovementPlanController.getuserIdOfSelectedEmployee';
import updatePIPRecord from '@salesforce/apex/PerformanceImprovementPlanController.updatePIPRecord';
import Id from "@salesforce/user/Id";

const columns = [
    {label: 'Name', fieldName: 'linkName', type: 'url',typeAttributes: {label: { fieldName: 'Name' }, target: '_blank'}},
    { label: 'Date', fieldName: 'Date__c', type: 'date', typeAttributes: {day: "numeric",month: "numeric",year: "numeric"},hideDefaultActions: true },
    { label: 'Employee Name', fieldName: 'EmployeeName', type: 'text', hideDefaultActions: true },
];

const Manager_PIPS = 'Manager PIPs'; 
const My_PIPS = 'My PIPs';
 
const filterOptions = [
    { value: My_PIPS, label: My_PIPS },
    { value: Manager_PIPS, label: Manager_PIPS },
];

export default class PerformanceImprovementPlanListView extends LightningElement {
    @track currentFilter = My_PIPS;
    @track isExpanded = false;
    itemsForCurrentView=[];
    @track itemsForEmployeeSelectedView = [];
    @track itemsForCorrectiveActionView=[];
    @track isLoaded = false;
    filterOptions = filterOptions;
    columns = columns;
    showTaskDetails = false;
    showTask = false;
    userId = Id;
    caDetails;
    editCA = false;
    showComments = false;
    name;
    dateT;
    acknowledgeDate;
    commentSave = false;
    @track bridgePlanObject = {"SObjectType" : "Performance_Improvement_Plan__c"};
    @track correctiveActionObjEdit = {}
    @track isNewBridgePlanClicked = false;
    @track isNewCorrectiveActionClicked = false;
    showNewPlanButton = false;
    @track employeeObject = {};
    @track selectedPlanEmployeeId;
    @track selectedCorrectiveEmployeeId;
    @track correctiveActionForSelectedEmp = [];
    currLogInEmp = '';
    todayDate;
    today;
    @track loggedInUser = true;
    selectedUserIdForTask;
    buttonNameOnEdit;
    @track showEditCorrectiveActionPopUp = false

    connectedCallback() {
        this.name= this.userId;
        this.acknowledgeDate = new Date();
        var today = new Date();
        this.today = today.toLocaleString();
        console.log(today.toLocaleString());
        var dd = String(today.getDate()).padStart(2, '0');
        var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        var yyyy = today.getFullYear();
        today = yyyy + '-' + mm + '-' + dd;
        this.todayDate = today;
        this.checkLoginUserisAManagerOrNot();
        this.loadData();
        this.getEmpPickValues();
    }

    getEmpPickValues(){
        getEmpUnderMangerPicklist()
        .then(result => {
            this.employeeObject = result;
            this.showNewPlanButton = this.employeeObject.isNewBridgePlanEnable;
        })
        .catch(error => {
            console.log("---error found while getting picklist values :" + JSON.stringify(error));
        })
    }
    
    loadData(){
        this.name= this.userId;
        var todayDate = new Date();
        this.acknowledgeDate = todayDate.toISOString();
        filterData()
            .then((result) => {
                result.forEach( ( record ) => {
                    const date = new Date();
                    const date2 = record.Comment_Added_Date__c;
                    console.log(date.getMonth()+1);
                    record.addComment = true;
                    this.managerId = record.Employee_Name__r.User.ManagerId;
                    if(this.userId == record.Employee_Name__r.User.ManagerId && (!date2 || (date2 && date.getDate() == date2.split('-')[2] && date.getFullYear() == date2.split('-')[0] && date.getMonth()+1 == date2.split('-')[1]))){
                        record.addComment = false;
                    }
                    if(record.Status__c == 'Rejected' && this.userId == record.Employee_Name__r.User.ManagerId) {
                        record.isEditable = true;
                    }
                    record.linkName = '/employeeservicesample/s/performance-improvement-plan/' + record.Id;
                    record.EmployeeName = record.Employee_Name__r.Name;

                    this.itemsForEmployeeSelectedView.push({employeeId : record.Employee_Name__c, employeeView: record});

                    if(record.Employee_Name__r.UserId == this.userId){
                        this.currLogInEmp = record.Employee_Name__c;
                        this.selectedUserIdForTask = record.Employee_Name__r.UserId
                        this.itemsForCurrentView.push(record);
                    } 
                });
                console.log('--- this.itemsForEmployeeSelectedView: ' + JSON.stringify(this.itemsForEmployeeSelectedView));
            })
            .catch((error) => {
                console.error(error);
            });

        filterCorrectiveAction({})
            .then((result) => {
                result.forEach( ( record ) => {
                    record.addComment = true;
                    record.linkName = '/employeeservicesample/s/corrective-action-form/' + record.Id;
                    if(this.userId == record.Employee_Name__r.User.ManagerId){
                        record.addComment = false;
                        if(record.Status__c == 'Rejected') {
                            record.isEditable = true;
                        }
                    }
                    console.log('--- record.Employee_s_Acknowledgement__c: ', record.Employee_s_Statement__c);
                    console.log('---- (this.userId == record.Employee_Name__r.UserId): ',(this.userId == record.Employee_Name__r.UserId));
                    if(this.userId == record.Employee_Name__r.UserId && !record.Employee_s_Statement__c){
                        record.ack = false;
                    }
                    else record.ack = true;

                    let causation = record.Causation__c;
                    if(causation != undefined && causation.includes(';')) {
                        record.Causation__c = causation.replaceAll(";", ", ");
                    }

                    this.correctiveActionForSelectedEmp.push({employeeId : record.Employee_Name__c, employeeView : record});

                    if(record.Employee_Name__r.UserId == this.userId){
                        this.selectedUserIdForTask = record.Employee_Name__r.UserId
                        this.itemsForCorrectiveActionView.push(record);
                    }

                    console.log('---- record.ack: ' + record.ack);
                    console.log('---- record.Name: ' + record.Name);
                });
            })
            .catch((error) => {
                console.error(error);
            });    
        this.isLoaded = false;
    }

    checkLoginUserisAManagerOrNot(){
        isUserIsAManager()
        .then(result => {
            this.showNewPlanButton = result;
        })
        .catch(error => {
            console.log("-----error found :" + JSON.stringify(error));
        })
    }

    handleChange(event){
        if(event.target.name == "bridgePlanCombobox"){
            this.selectedEmployeeId = event.detail.value;
            getuserIdOfSelectedEmployee({EmpId : this.selectedEmployeeId}).then(response=> {
                if(response == this.selectedUserIdForTask) {
                    this.loggedInUser = true
                } else {
                    this.loggedInUser = false
                }
            })
            this.itemsForCurrentView = [];
            this.itemsForEmployeeSelectedView.forEach(obj => {
                if(obj.employeeId == this.selectedEmployeeId){
                    this.itemsForCurrentView.push(obj.employeeView);
                }
            });
        }else if(event.target.name == "correctiveActionCombobox"){
            let selectedEmployeeId = event.target.value;
            getuserIdOfSelectedEmployee({EmpId : this.selectedEmployeeId}).then(response=> {
                if(response == this.selectedUserIdForTask) {
                    this.loggedInUser = true
                } else {
                    this.loggedInUser = false
                }
            })
            this.itemsForCorrectiveActionView = [];
            this.correctiveActionForSelectedEmp.forEach(obj => {
                if(obj.employeeId == selectedEmployeeId){
                    if(!this.loggedInUser && obj.Status__c == 'Rejected') {
                        obj.isEditable = true
                    }
                    let causation = obj.employeeView.Causation__c;
                    if(causation != undefined && causation.includes(';')) {
                        obj.employeeView.Causation__c = causation.replaceAll(";", ", ");
                    }
                    this.itemsForCorrectiveActionView.push(obj.employeeView);
                }
            })

            console.log("----this.itemsForCorrectiveActionView : " + JSON.stringify(this.itemsForCorrectiveActionView));
        }else{
            this.bridgePlanObject[event.target.name] = event.detail.value;
        }
    }

    showNotification(titleText, messageText, variant) {
        const evt = new ShowToastEvent({
          title: titleText,
          message: messageText,
          variant: variant
        });
        this.dispatchEvent(evt);
    }

    isEditBridgePlanClicked = false

    handleEditData(event) {
        console.log('name in edit----> ' , event.target.name)
        if(event.target.name == 'Bridge') {
            let index = event.target.dataset.id
            console.log('bridge data index---------> ' , JSON.stringify(this.itemsForCurrentView[index]))
            this.bridgePlanObject = this.itemsForCurrentView[index]
            this.isEditBridgePlanClicked = true
        } else if(event.target.name == 'Corrective') {
            let index = event.target.dataset.id
            this.correctiveActionObjEdit = this.itemsForCorrectiveActionView[index]
            this.showEditCorrectiveActionPopUp = true
            this.isNewCorrectiveActionClicked = false
        }
        console.log('this.showEditCorrectiveActionPopUp-------------> ' , this.showEditCorrectiveActionPopUp)
    }

    handleEditSave(event) {
        this.isLoaded = true
        this.buttonNameOnEdit = event.target.name
        if(this.bridgePlanObject.Employee_Name__c && this.bridgePlanObject.Reason_for_the_plan__c && this.bridgePlanObject.Next_review_dates__c >= new Date().toISOString()){
            updatePIPRecord({objPIP : this.bridgePlanObject, buttonName : this.buttonNameOnEdit}).then(result=> {
                this.isEditBridgePlanClicked = false
                this.isLoaded = false
                this.dispatchEvent(new CustomEvent('closepopup', {
                    detail : {
                        closePopUp : this.isEditBridgePlanClicked
                    }
                }));
                if(this.buttonNameOnEdit == 'bridgePlanSaveApprove') {
                    this.showNotification("Record has been updated!!", "Performance Record updated & sent for approval successfully!", "success");
                } else {
                    this.showNotification("Record has been updated!!", "Performance Record updated successfully!", "success");
                }
            }).catch(error => {
                console.log("----Aww error found :" + JSON.stringify(error));
                this.showNotification("Something went wrong!!", "Please check all the fields validations!", "error");
            })
        } else {
            this.isLoaded = false
            this.showNotification("Something went wrong!!", "Please fill all the mandatory fields and save again!.", "error");
        }
    }

    handleClick(event){
        this.isLoaded = true
        if(event.target.name == "bridgePlanSave"){
            console.log("---------Bridge Plan Record To be insert" + JSON.stringify(this.bridgePlanObject));
            if(this.bridgePlanObject.Employee_Name__c && this.bridgePlanObject.Reason_for_the_plan__c && this.bridgePlanObject.Next_review_dates__c >= new Date().toISOString()){
                insertPIPRecord({objPIP : this.bridgePlanObject})
                .then(result => {
                    this.isNewBridgePlanClicked = false;
                    this.isLoaded = false
                    console.log("--inserted PIP record ID: " + result);
                    this.dispatchEvent(new CustomEvent('closepopup', {
                        detail : {
                            closePopUp : this.isNewBridgePlanClicked
                        }
                    }));
                    this.showNotification("Record has been created!!", "Performance Record created successfully!.", "success");
                }).catch(error => {
                    console.log("----Aww error found :" + JSON.stringify(error));
                    this.showNotification("Something went wrong!!", "Please check all the fields validations!.", "error");
                })
            }else{
                this.isLoaded = false
                this.showNotification("Something went wrong!!", "Please fill all the mandatory fields and save again!.", "error");
            }
            
        }

        if(event.target.name == "cancelEvent"){
            this.isNewBridgePlanClicked = false;
            this.isEditBridgePlanClicked = false;
            this.isLoaded = false
        }

        if(event.target.name == "newPIPRecord"){
            this.isNewBridgePlanClicked = true;
            this.bridgePlanObject.Reason_for_the_plan__c = null
            this.bridgePlanObject.Performance_expectations_after_the_plan__c = null
            this.bridgePlanObject.Metrics_used_to_measure_improvement__c = null
            this.bridgePlanObject.Consequences_if_the_goal_is_or_is_not_ac__c = null
            this.bridgePlanObject.Specific_actions_to_improve__c = null
            this.bridgePlanObject.Next_review_dates__c = null
            this.isLoaded = false
        }

        if(event.target.name == "newCorrectiveAction"){
            this.isNewCorrectiveActionClicked = true;
            this.isLoaded = false
            console.log("---event.target.name: " + this.isNewCorrectiveActionClicked);
        }
    }

    handleNewCorrectiveActionPopUp(event){
        this.showEditCorrectiveActionPopUp = event.detail.closePopUp;
    }

    handleEditCorrectiveActionPopUp(event) {
        this.showEditCorrectiveActionPopUp = event.detail.closePopUp;
        var dataCorrective = event.detail.onEditData
        const i = this.itemsForCorrectiveActionView.findIndex(x => x.Id === dataCorrective.Id)
        this.itemsForCorrectiveActionView[i] = dataCorrective
        this.itemsForCorrectiveActionView.map(obj => dataCorrective.Id === obj.Id || obj);
        this.itemsForCorrectiveActionView = [...this.itemsForCorrectiveActionView];
    }

    handleActive(event) {
        this.activeTab = event.target.value;
    }
 
    get dropdownTriggerClass() {
        if (this.isExpanded) {
            return 'slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click custom_list_view slds-is-open'
        } else {
            return 'slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click custom_list_view'
        }
    }
 
    handleFilterChangeButton(event) {
        console.log('Inside');
        this.isLoaded = false;
        let filter = event.target.dataset.filter;
        this.isExpanded = !this.isExpanded;
        if (filter !== this.currentFilter) {
            this.currentFilter = event.target.dataset.filter;
            setTimeout(() => {
                this.handleFilterData(this.currentFilter), 0
            });
        } else {
            this.isLoaded = false;
        }
    }

    handleFilterData(filter) {
        this.name= this.userId;
        filterData({ filter: this.currentFilter })
            .then((result) => {
                console.log('resuult',result);
                result.forEach( ( record ) => {
                    record.linkName = '/employeeservicesample/s/performance-improvement-plan/' + record.Id;
                    record.EmployeeName = record.Employee_Name__r.Name;
                });                   
                this.itemsForCurrentView = result;
            })
            .catch((error) => {
                console.error(error);
            });
        this.isLoaded = false;
    }

    handleClickExtend() {
        this.isExpanded = !this.isExpanded;
    }
    pipIdToSend;
    caIdToSend;
    @track typeName;
    handleTaskClick(event) {
        this.pipIdToSend = event.currentTarget.dataset.id;
        this.caIdToSend= null;
        this.showTask = true;
    }
    handleTaskViewClick(event) {
        this.pipIdToSend = event.currentTarget.dataset.id;
        this.caIdToSend= null;
        this.showTaskDetails = true;
    }
    handlecaTaskClick(event) {
        this.pipIdToSend = null;
        this.caIdToSend= event.currentTarget.dataset.id;
        this.showTask = true;
    }
    handlecaTaskViewClick(event) {
        this.pipIdToSend = null;
        this.caIdToSend= event.currentTarget.dataset.id;
        this.showTaskDetails = true;
    }
    closeModalOfCreateTaskForGoal(event) {
        this.showTask = event.detail;
        this.showTaskDetails = event.detail;
        console.log('this.showTask-- ' + this.showTask + ' -- ' + this.showTaskDetails);
    }
    closeModalOfShowComments(event) {
        this.showComments = event.detail;
    }
    addCommentModal = false;
    commentValue='';
    pipId;
    caId;
    eStatement;
    openAddCommentModal(event) {
        this.commentSave = false;
        this.addCommentModal = true;
        this.pipId = event.target.dataset.id;
        this.commentValue = '';
    }
    opencaAddCommentModal(event) {
        this.commentSave = false;
        this.addCommentModal = true;
        this.caId = event.target.dataset.id;
        console.log(this.caId);
        this.commentValue = '';
    }
    showCommentModal(event){
        this.showComments = true;
        const idx = event.currentTarget.dataset.index;
        this.typeName = event.target.name
        if(event.target.name == 'BridgePlan') {
            this.caDetails = this.itemsForCurrentView[idx];
        } else {
            this.caDetails = this.itemsForCorrectiveActionView[idx];
        }
    }
    closeModal() {
        this.addCommentModal = false;
        this.editCA = false;
    }

    openCAModal(event){
        this.editCA = true;
        this.caId = event.target.dataset.id;
        console.log(this.caId);
    }

    handleError(event) {
        let message = event.detail.detail;
        //message = "Something went wrong!";
        this.showToast('error!!', message, 'error');
       //this.clearEditMode();
    }

    showToast(theTitle, theMessage, theVariant) {
        const event = new ShowToastEvent({
            title: theTitle,
            message: theMessage,
            variant: theVariant
        });
        this.dispatchEvent(event);
    }

    onChangeEA(event){
        this.name= this.userId;

        let ackDate = event.target.value;
        console.log('---- 361 ackDate: ' + ackDate);


    }

    onSuccess(){
        const evt = new ShowToastEvent({
                    title: 'Success!!',
                    message: 'Corrective action updated sucessfully.',
                    variant: 'success',
                    mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                    this.editCA = false;
                    this.loadData();
    }

    submitDetails() {
        this.commentSave = true;
        savePIPComment({ pIPId: this.pipId,comment : this.commentValue,caId:this.caId })
            .then((result) => {
                if(result == 'SUCCESS'){
                    
                    this.editMode = false;
                    let evt = new ShowToastEvent({
                    title: 'Success!!',
                    message: 'Comment updated sucessfully.',
                    variant: 'success',
                    mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                    this.closeModal();
                    this.loadData();
                }
                else{
                    let evt = new ShowToastEvent({
                    title: 'Error',
                    message: result,
                    variant: 'error',
                    mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                }
            })
            .catch((error) => {
                console.error(error);
            });
    }
    
    commentHandler(event) {
        this.commentValue = event.detail.value;
    }

    handleNewBridgePlanClick() {
        this.isNewBridgePlanClicked = true;
    }
}