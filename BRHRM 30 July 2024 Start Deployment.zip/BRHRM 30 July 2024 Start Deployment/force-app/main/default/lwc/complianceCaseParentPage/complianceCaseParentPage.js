import { LightningElement, track, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import { CurrentPageReference } from 'lightning/navigation';
import getCaseRecordInformation from '@salesforce/apex/CaseCreation.getCaseRecordData';
export default class ComplianceCaseParentPage extends NavigationMixin(LightningElement) {

    @track caseData = {};
    @track dataList = [];
    @track caseRecordTypeId;
    @track caseNumber;
    @track childcmpName = 'c-compliance-general-info-child-page';
    @track page1 = true;
    @track page2 = false;
    @track page3 = false;
    @track page4 = false;
    @track currentStep = 1;
    @track progressValue = 1;
    @track preVisibiliy = false;
    @track cancelVisibility = true;
    @track SEvisibility = true;
    @track SNvisibility = true;
    @track doneVisibility = false;
    @track submitVisibility = false;
    @track fileDataOfMember = [];
    recordTypeName = 'Compliance Related Case';
    communitPageReferenceId;
    isLoaded = false;


    progressStepList = [
        { label: 'General Info', value: 'General Info', index: 1 },
        { label: 'Involved Parties', value: 'Involved Parties', index: 2 },
        { label: 'Additional Description', value: 'Additional Description', index: 3 },
        { label: 'Confirmation', value: 'Confirmation', index: 4 },
    ]

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.communitPageReferenceId = currentPageReference.state?.id ? currentPageReference.state?.id : '';
        }
    }

    @wire(getObjectInfo, { objectApiName: Case_Object })
    objectInfo({ data, error }) {
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                console.log('rtis[element] ', rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Compliance Related Case') {
                    this.caseRecordTypeId = rtis[element].recordTypeId;
                    console.log('rtis[element].recordTypeId ', rtis[element].recordTypeId);
                }
            });
        }
    }

    connectedCallback() {
        console.log('this.communitPageReferenceId', this.communitPageReferenceId);
        this.getCaseValue();
    }

    getCaseValue() {
        this.isLoaded = true;
        getCaseRecordInformation({
            caseId: this.communitPageReferenceId
        })
            .then(result => {
                if (result) {
                    let obj = JSON.parse(JSON.stringify(result));
                    console.log('this.obj--> ', JSON.stringify(obj));
                    this.caseData = obj.caseObj;
                    console.log('this.caseData--> ', JSON.stringify(this.caseData));
                    this.dataList = obj.relatedIncidentUserList;
                    console.log('this.dataList--> ', JSON.stringify(this.dataList));
                    if (this.communitPageReferenceId) {
                        this.currentStep = obj.caseObj.CurrentPage__c;
                    }
                    console.log('this.currentStep--> ', this.currentStep);
                    this.pageChanger(this.currentStep);

                }
            }).catch(error => {

            }).finally(() => {
                this.isLoaded = false;;
            });
    }


    pageChanger(currentstep) {
        this.currentStep = currentstep;
        this.progressValue = currentstep;
        console.log('this.currentStep->' + this.currentStep);
        if (currentstep == 1) {
            this.page1 = true;
            this.page2 = this.page3 = this.page4 = !this.page1;
            this.childcmpName = 'c-compliance-general-info-child-page';

            this.preVisibiliy = false;
            this.cancelVisibility = true;
            this.SEvisibility = true;
            this.SNvisibility = true;
            this.doneVisibility = false;
            this.submitVisibility = false;
        }
        else if (currentstep == 2) {
            this.page2 = true;
            this.page1 = this.page3 = this.page4 = !this.page2;
            this.childcmpName = 'c-involved-parties-information-child-page';

            this.preVisibiliy = true;
            this.cancelVisibility = false;
            this.SEvisibility = true;
            this.SNvisibility = true;
            this.doneVisibility = false;
            this.submitVisibility = false;
        }
        else if (currentstep == 3) {
            this.page3 = true;
            this.page1 = this.page2 = this.page4 = !this.page3;
            this.childcmpName = 'c-additional-description-case-child-page';
            this.preVisibiliy = true;
            this.cancelVisibility = false;
            this.SEvisibility = false;
            this.SNvisibility = false;
            this.doneVisibility = false;
            this.submitVisibility = true;
        }
        else if (currentstep == 4) {
            this.page4 = true;
            this.page1 = this.page2 = this.page3 = !this.page4;

            this.preVisibiliy = false;
            this.cancelVisibility = false;
            this.SEvisibility = false;
            this.SNvisibility = false;
            this.doneVisibility = true;
            this.submitVisibility = false;
        }
    }

    handleProgressStepClick(event) {
        // console.log('currentcalue-->' + event.target.value);
        // if (!this.doneVisibility) {
        //     this.pageChanger(event.target.value);
        // }

        console.log('currentcalue-->' + event.target.value);
        console.log('this.progressValue', this.progressValue);
        if (event.target.value > this.progressValue) {
            console.log('this.currentStep', this.currentStep);
            console.log('this.childcmpName', this.childcmpName);
            const childComp = this.template.querySelector(this.childcmpName);
            childComp.handleNext();
        } else {
            if(event.target.value != 1)
            console.log('this.childcmpName', this.childcmpName);
            const childComp = this.template.querySelector(this.childcmpName);
            childComp.handlePrevious();
        }
        console.log('this.progressValue', this.progressValue);
        console.log('this.currentStep', this.currentStep);

    }

    handleSaveNext() {
        console.log('Next');
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handleNext();
    }

    handlePrevious() {
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handlePrevious();
    }

    handleSubmit() {
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handleNext();
    }

    handleCancel() {
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "/employeeservicesample/s/casehomepage"
            }
        });
    }

    handleDone() {
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "/employeeservicesample/s/casehomepage"
            }
        });
    }

    handleParties(event) {
        console.log('--188->' + JSON.stringify(event.detail));
        this.dataList = event.detail;
        this.pageChanger(this.currentStep + 1);
    }

    handlePartiesPrevious(event) {
        console.log('this.currentStep',this.currentStep)
        this.dataList = event.detail;
        this.pageChanger(this.currentStep - 1);
    }

    handleCaseEvent(event) {
        console.log('event--122-->' + event.detail);
        this.caseNumber = event.detail;
        if (this.caseNumber != null && this.caseNumber != '') {
            this.pageChanger(this.currentStep + 1);
        }
    }

    handlePreviousCaseEvent(event) {
        this.fileDataOfMember = event.detail.file;
        console.log('this.fileDataOfMember', JSON.stringify(this.fileDataOfMember));
        this.caseData = { ...this.caseData, ...event.detail.caseObject };
        console.log('this.caseDatar', JSON.stringify(this.caseData));
        this.pageChanger(this.currentStep - 1);
    }

    handleEvent(event) {
        console.log('event--116-->' + JSON.stringify(event.detail));
        this.caseData = { ...this.caseData, ...event.detail };

        console.log('event--120--> ' + JSON.stringify(this.caseData));
        this.pageChanger(this.currentStep + 1);
    }

    handleSaveExit() {
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handleSaveAndExit();
    }

    handleSaveAndExitMethod() {
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "/employeeservicesample/s/casehomepage"
            }
        });
    }
}