import { LightningElement, track, wire, api } from 'lwc';
import getMyTraining from '@salesforce/apex/TrainingController.getMyTrainings';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
import uId from '@salesforce/user/Id';
import getEmployeeData from '@salesforce/apex/TrainingController.getEmployeeData';
import statusPicklistValues from '@salesforce/apex/LearningPathController.statusPicklistValues';
import unEnrollTraining from '@salesforce/apex/TrainingController.unEnrollTraining';
import unEnrollLearningPath from '@salesforce/apex/TrainingController.unEnrollLearningPath';
import updateStatus from '@salesforce/apex/TrainingController.updateStatus';
import { reduceErrors } from 'c/lwcUtility';
import trainingUnenrollApproval from '@salesforce/label/c.Training_Unenroll_Approval';
import trainingUnenrollComment from '@salesforce/label/c.Training_Unenroll_Comment';
import trainingUnenrolled from '@salesforce/label/c.Training_Unenrolled';
import { NavigationMixin } from 'lightning/navigation';
//Learning Path -----------------------------------------------------------------------------------------------//
import getPath from '@salesforce/apex/LearningPathController.getEnrolledLearningPath';
import getEnrolledLearningPathTrainings from '@salesforce/apex/LearningPathController.getEnrolledLearningPathTrainings';

const column = [
    {
        label: 'Training Name', fieldName: 'TrainingNameUrl', type: 'url',
        typeAttributes: { label: { fieldName: 'TrainingName' }, target: '_blank' }
    },
    { label: 'Training Type', fieldName: 'TrainingType' },
    { label: 'Priority', fieldName: 'Priority' },

    { label: 'Status', fieldName: 'Status' },
    {
        label: "Start DateTime",
        fieldName: "startDateTime",
        type: "date",
        typeAttributes: {
            year: "numeric",
            month: "long",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        }
    },
    {
        label: "End DateTime",
        fieldName: "endDateTime",
        type: "date",
        typeAttributes: {
            year: "numeric",
            month: "long",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        }
    },
];
// END - Learning Path ---------------------------------------------------------------------------//

export default class MyAssignedTraining extends NavigationMixin(LightningElement) {

    @track wiredData = [];
    @track wiredDataLearningPath = [];
    @track trainingData = [];
    @track trainingDataDummy = [];
    userId = uId;
    empId = '';
    isLoading = true;
    showMessage = false;
    msg = '';
    learningPathMsg = '';
    @track statusOptions = [];
    highFlag = '/img/samples/flag_red.gif'
    mediumFlag = '/img/samples/flag_yellow.gif'
    lowFlag = '/img/samples/flag_green.gif'
    isModalOpen = false;
    emptid;
    @track unenrollComment = '';
    @track isModalOpenUnEnroll = false;
    @track recordId;
    @track isMandtory;
    caseInformationBoolean = true;
    learningPathId;
    learningPathStatus;
    learningPathUnenrollPopup = false;
    isLearningPathMandtory;
    // Learning Path -----------------------------------------------------------------------//
    @track pathData = [];
    @track pathDataDummy = [];
    @track learningPathTrainingData = [];
    learningPathTrainingColumn = column;
    empProfile = '';
    draftValues = [];
    @track statusPickValues = [];
    searchData = [];
    displayLearningPath = false;
    displayTrainings = false;
    @track trainingLink = '';
    @track showUnenrollButton = true; // Boolean variable to control button visibility
    isShowFields = false
    trainingIndexOnUnenroll;
    learningPathIndexOnUnenroll;

    
    connectedCallback() {
        this.getStatusPicklistValues();
        this.getEmployeeDataVal();
    }

    getStatusPicklistValues() {
        statusPicklistValues()
            .then(result => {
                this.statusPickValues = result;
                console.log('------' + JSON.stringify(this.statusPickValues));
            })
            .catch(error => {
                console.log('-error--------' + JSON.stringify(error));
            })
    }

    getEmployeeDataVal() {
        getEmployeeData({userId: this.userId}).then(data=> {
            if (data) {
                if (data.length > 0) {
                    this.empId = data[0].Id;
                    this.empProfile = data[0].JobProfile;
                    this.getLearningPath(this.empId,this.empProfile);
                    if (this.empProfile == undefined || this.empProfile == '') {
                        this.showMessage = true;
                        this.learningPathMsg = `You don't have any Learning Path`
                        this.isLoading = false;
                    }
                } else {
                    this.learningPathMsg = `No Employee found for your user`
                    this.isLoading = false;
                }
            }
        })
    }

    /**************************Get Learning Path **************************************/
    getLearningPath(empId,empProfile) {
        console.log('empId le',empId);
        console.log('empProfile le',empProfile);
        getPath({empId: empId, jobProfile: empProfile}).then(result=> {
            this.wiredDataLearningPath = result;
            console.log('result l',JSON.stringify(result))
            if (result) {
                if (result.length > 0) {
                    this.pathData = JSON.parse(JSON.stringify(result))
                    this.pathDataDummy = JSON.parse(JSON.stringify(result))
                    this.showMessage = false;
                    this.pathData.forEach(eachData=> {
                        eachData.eLDs.forEach(eachLD=> {
                            eachData.learningPathTraining.forEach(eachP=> {
                                if(eachLD.Get_Training__c == eachP.TrainingName) {
                                    eachLD.TrainingPriority = eachP.Priority
                                }
                                this.isShowFields = true
                            })
                        })
                    })
                    this.pathDataDummy.forEach(eachData=> {
                        eachData.eLDs.forEach(eachLD=> {
                            eachData.learningPathTraining.forEach(eachP=> {
                                if(eachLD.Get_Training__c == eachP.TrainingName) {
                                    eachLD.TrainingPriority = eachP.Priority
                                }
                                this.isShowFields = true
                            })
                        })
                    })
                    console.log("Learning Path: " + JSON.stringify(this.pathData));
                }
                else {
                    this.learningPathMsg = `You don't have any Learning Path`;
                    this.showMessage = true;
                }
                this.isLoading = false;
            } if (result.error) {
                console.log('error', result.error);
                this.isLoading = false;
            }
        })
        
    }

    /**************************Handling Search based on Name and Type************************ */
    displayLearningPathTrainings(event) {
        this.isModalOpen = true;
        getEnrolledLearningPathTrainings({ learningPathId: event.target.dataset.id, employeeId: this.empId })
            .then(res => {
                this.learningPathTrainingData = res;
                console.log("Learning Path Training: " + JSON.stringify(res));
            })
            .catch(error => {
                this.displayMessage('Error Occured', 'error', reduceErrors(error).toString())
            });
    }

    async handleSave(event) {
        const updatedFields = event.detail.draftValues;
        await updateAccounts({ data: updatedFields })
            .then(result => {
                console.log(JSON.stringify("Apex update result: " + result));
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Account(s) updated',
                        variant: 'success'
                    })
                );
                refreshApex(this.wiredRecords).then(() => {
                    this.draftValues = [];
                });
            }).catch(error => {
                console.log('Error is ' + JSON.stringify(error));
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error updating or refreshing records',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }

    closeModal() {
        this.isModalOpen = false;
    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }
    // END - Learning Path ------------------------------------------------------------------//

    get caseInformation() {
        return this.caseInformationBoolean ? 'slds-section slds-is-open' : 'slds-section';
    }

    clickCaseInformation() {
        this.caseInformationBoolean = !this.caseInformationBoolean;
    }

    /********************************** Get My Training data ********************************/
    @wire(getMyTraining, { empId: '$empId' })
    myTrainings(result) {
        this.wiredData = result;
        if (result.data) {
            if (result.data.length > 0) {
                this.trainingData = JSON.parse(JSON.stringify(result.data));
                this.trainingDataDummy = result.data;
                this.searchData = result.data
                this.showMessage = false;
                this.isShowFields = true
                console.log("myTrainings data: " , JSON.stringify(this.trainingData));
                this.trainingData.forEach(eachData=> {
                    if(eachData.isHigh) {
                        eachData.Priority = 'High'
                    } else if(eachData.isLow) {
                        eachData.Priority = 'Low'
                    } else if(eachData.isMedium) {
                        eachData.Priority = 'Medium'
                    }
                    this.isShowFields = true
                })
            }
            else {
                this.msg = `You don't have any upcoming or overdue trainings. Please enroll for trainings`;
                this.showMessage = true;
            }
            this.isLoading = false;
        }
        if (result.error) {
            console.log('error', JSON.stringify(result.error));
            this.isLoading = false;
        }
    }

    trainingStatus;

    //************* Un-Enroll Training Process ****************************//
    // Open unenroll comment popup
    handleUnenroll(event) {
        this.trainingIndexOnUnenroll = event.target.dataset.index
        let index = event.target.dataset.index;
        let trainingLData = JSON.parse(JSON.stringify(this.trainingData));
        this.isMandtory = event.target.dataset.mandatory;
        //this.isModalOpenUnEnroll = true;
        this.recordId = event.target.dataset.id;
        this.trainingStatus = event.target.dataset.status
        if (this.trainingStatus === 'New') {
            this.isModalOpenUnEnroll = true;
            trainingLData[index].buttonDisable = true;
            trainingLData[index].unEnrolled = true;
            this.trainingData  = trainingLData;
            this.trainingDataDummy = trainingLData;
            this.searchData = trainingLData;
        } else {
            trainingLData[index].buttonDisable = true;
            this.trainingData  = trainingLData;
            this.trainingDataDummy = trainingLData;
            this.searchData = trainingLData;
            this.displayMessage('Training can not be unenrolled', 'error', 'Training is in progress. Please contact your admin.');
        }
    }

    // Get uneroll comment
    handleUnenrollComment(event) {
        this.unenrollComment = event.detail.value;
    }

    // Save uneroll comment in record
    saveComment(event) {
        if (this.unenrollComment == undefined || this.unenrollComment == '') {
            this.displayMessage('Error Occured', 'error', trainingUnenrollComment)
            this.isLoading = false;
        } else {

            unEnrollTraining({ recId: this.recordId, comment: this.unenrollComment, isUnenroll: true })
                .then(result => {
                    console.log("-----msg : " + JSON.stringify(result));
                    console.log("-----msg 1: " + result);
                    let trainingDataTemp = JSON.parse(JSON.stringify(this.trainingData))
                    trainingDataTemp[this.trainingIndexOnUnenroll].unEnrolled = true
                    trainingDataTemp[this.trainingIndexOnUnenroll].buttonDisable = true
                    this.trainingDataDummy = trainingDataTemp
                    this.trainingData = trainingDataTemp
                    this.searchData = trainingDataTemp
                    refreshApex(this.wiredData);
                })
                .catch(error => {
                    console.log(error);
                })
            this.isModalOpenUnEnroll = false;
            this.unenrollComment = '';

            if (this.isMandtory == 'true') {
                this.displayMessage('Sent for Approval!', 'success', trainingUnenrollApproval)
            }

            if (this.isMandtory == 'false') {
                this.displayMessage('Training Unenrolled!', 'success', trainingUnenrolled)
            }
        }
    }
    //************* End - Un-Enroll Training Process ****************************//

    //************* Un-Enroll Learning Path ****************************//
    // Open unenroll comment popup
    handleUnenrollLearningPath(event) {
        this.learningPathIndexOnUnenroll = event.target.dataset.index;
        let index = event.target.dataset.index;
        let learningPathData = JSON.parse(JSON.stringify(this.pathData));
        this.pathData = learningPathData;
        this.isLearningPathMandtory = event.target.dataset.required;
        this.learningPathId = event.target.dataset.id;
        this.learningPathStatus = event.target.dataset.status;
        console.log('this.learningPathStatus -- ' + this.learningPathStatus);
        if (this.learningPathStatus === 'Not Started') {
            this.learningPathUnenrollPopup = true;
            learningPathData[index].isUnEnrolled = true;
            this.pathData = learningPathData;
            this.pathDataDummy = learningPathData;
            this.searchData = learningPathData;
        } else {
            learningPathData[index].isUnEnrolled = true;
            this.pathData = learningPathData;
            this.pathDataDummy = learningPathData;
            this.searchData = learningPathData;
            this.displayMessage('Learning Path can not be unenrolled', 'error', 'Learning Path is in progress. Please contact your admin.');
        } 
    }

    // Get uneroll comment
    handleUnenrollComment(event) {
        this.unenrollComment = event.detail.value;
    }
    // Save uneroll comment in record
    unenrollLearingPath(event) {
        console.log('unenrollLearingPath -- ' + this.learningPathId + ' -- ' + this.unenrollComment);
        if (this.unenrollComment == undefined || this.unenrollComment == '') {
            this.displayMessage('Error Occured', 'error', trainingUnenrollComment)
            this.isLoading = false;
        } else {
            unEnrollLearningPath({ recId: this.learningPathId, comment: this.unenrollComment, employeeId: this.empId })
                .then(result => {
                    let learningPathDataTemp = JSON.parse(JSON.stringify(this.pathData));
                    learningPathDataTemp[this.learningPathIndexOnUnenroll].isUnEnrolled = true
                    this.pathData = learningPathDataTemp;
                    this.pathDataDummy = learningPathDataTemp;
                    this.searchData = learningPathDataTemp;
                    refreshApex(this.wiredDataLearningPath);
                })
                .catch(error => {
                    console.log(error);
                })
            this.learningPathUnenrollPopup = false;
            this.unenrollComment = '';

            if (this.isLearningPathMandtory == 'true') {
                this.displayMessage('Sent for Approval!', 'success', 'Required Learning Path sent for unenroll approval.')
            }

            if (this.isLearningPathMandtory == 'false') {
                this.displayMessage('Unenrolled!', 'success', 'Learning Path Unenrolled successfully!')
            }
        }
    }
    //************* End - Un-Enroll Learning Path ****************************//
    handleStatusUpdate(e) {

        this.isLoading = true;
        let recId = e.target.dataset.id;
        let status = e.target.dataset.status;
        let empRecord = { Id: recId, Status__c: status };

        updateStatus({ payLoad: JSON.stringify(empRecord) })
            .then(res => {
                this.displayMessage('Status Updated', 'success', 'You have succesfully updated the status')
                refreshApex(this.wiredData);
                this.isLoading = false
            })
            .catch(error => {
                this.displayMessage('Error Occured', 'error', reduceErrors(error).toString())
                this.isLoading = false;

            })

    }
    /******************************* Display Toast Message *********************** */
    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }

    openModal(e) {
        this.isModalOpen = true;
        this.emptid = e.target.dataset.id;
    }
    closeModal() {
        this.isModalOpen = false;
        this.isModalOpenUnEnroll = false;
        this.learningPathUnenrollPopup = false;
    }
    handleSearch(event) {
        console.log('handleSearch ' + JSON.stringify(event.detail));
        if (event.detail.type == 'Trainings') {
            this.pathData = [];
            this.trainingData = event.detail.filteredData;
        } else if (event.detail.type == 'Learning Paths') {
            this.trainingData = [];
            this.pathData = event.detail.filteredData;
        }
    }
    sendDataToDisplay(event) {
        console.log('sendDataToDisplay event handled ' + event.detail);
        if (event.detail == 'Trainings') {
            this.displayLearningPath = false;
            console.log('this.searchData-----> ' , JSON.stringify(this.trainingDataDummy))
            this.trainingData = this.trainingDataDummy;
            this.searchData = this.trainingDataDummy;
            this.displayTrainings = true;
        } else if (event.detail == 'Learning Paths') {
            this.displayTrainings = false;
            this.pathData = this.pathDataDummy;
            this.searchData = this.pathDataDummy;
            this.displayLearningPath = true;
        } else {
            this.displayTrainings = false;
            this.displayLearningPath = false;
            this.searchData = [];
            this.trainingData = [];
        }
    }
    displayAllData(event) {
        console.log('event.detail ' + JSON.stringify(event.detail));
        if (event.detail.tabName == "assignedTaining" && event.detail.enrolledType == "Trainings") {
            this.trainingData = event.detail.dataToDisplay;
        } else if (event.detail.tabName == "assignedTaining" && event.detail.enrolledType == "Learning Paths") {
            this.pathData = event.detail.dataToDisplay;
        }
    }
}