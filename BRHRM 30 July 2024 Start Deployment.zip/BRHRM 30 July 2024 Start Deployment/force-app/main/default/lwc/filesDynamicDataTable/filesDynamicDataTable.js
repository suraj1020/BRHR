import { LightningElement, api, wire,track } from 'lwc';
import getFilesAndAttachments from '@salesforce/apex/FileAttachmentController.getFilesAndAttachments';
import { NavigationMixin } from 'lightning/navigation';

const columns = [
    { label: 'Title', fieldName: 'fileUrl', type: 'url', typeAttributes: { label: { fieldName: 'title' }, target: '_blank' } },
    { label: 'File Type', fieldName: 'fileType' }
];

export default class FileAttachmentTable extends NavigationMixin(LightningElement) {
    @api recordId;
    @api filter= '';
    data = [];
    columns = columns;

    connectedCallback() {
        console.log('-recordId->'+ this.recordId);
        this.getFiles();
    }

    @api 
    getFiles(){
        console.log('Enter 23');
        console.log('hiii',this.filter);
        getFilesAndAttachments({recordId: this.recordId, filter: this.filter})
        .then(result=>{
            if(result){
                this.data = result;
            }
        });
    }

}