import { LightningElement, wire, api, track } from "lwc";
import { getRecord } from "lightning/uiRecordApi";
const CaseFields = ['Case.Subject','Case.Reason_For_Change__c','Case.New_Location_Address__c','Case.Old_Location_Address__c','Case.What_duties_the_employee_able_to_perform__c','Case.Effective_Date__c','Case.CaseNumber','Case.Attestation__c' ,'Case.Tuition_Reimbursement_Type__c', 'Case.HRIS_System_Type__c', 'Case.Benefit_Sub_Categories__c', 'Case.Problem_Opportunity_Statement__c', 'Case.Objectives__c', 'Case.Training_Subject_Topic__c', 'Case.Virtual_or_In_Person__c', 'Case.Number_of_Employee_receiving_training__c', 'Case.Propose_Date_of_Training__c', 'Case.Frequency__c', 'Case.Request_Information_for__c', 'Case.Other_Types__c', 'Case.Other_Data_Columns__c', 'Case.Request_type__c', 'Case.Request_Data_Columns__c', 'Case.Nature_of_Grievance__c', 'Case.Account_of_Event_s__c', 'Case.Emergency_Contact_Name__c', 'Case.Emergency_Contact_Email__c', 'Case.Emergency_Contact_Phone__c', 'Case.When_did_you_become_aware__c', 'Case.Accommodati_on_Type__c', 'Case.P_C_Type__c','Case.Conflict_Type__c', 'Case.How_long_is_the_conflict_expect_to_last__c', 'Case.Does_this_Conflict_involved_BakerRIpley__c', 'Case.is_this_the_first_time_you_are_reporting__c', 'Case.Compliance_Type__c', 'Case.Provider_Phone__c', 'Case.Anticipated_return_to_work_date__c', 'Case.First_full_day_back_to_work__c', 'Case.Employee_returned_to_work__c', 'Case.Pavement__c', 'Case.Date_of_fatality__c', 'Case.Incident_result_in_loss_of_life__c', 'Case.Date_reported_to_employer__c', 'Case.Description_of_the_incident__c', 'Case.Accident__c', 'Case.Seat_Belt_Used__c', 'Case.Air_Bag_Deployed__c', 'Case.Other_Conditions__c', 'Case.Conditions__c', 'Case.Other_Pavement__c', 'Case.Other_Weather__c', 'Case.VIN_Number__c', 'Case.Weather__c', 'Case.Year__c', 'Case.Vehicle_Details__c', 'Case.Make__c', 'Case.License_Plate_Number__c', 'Case.Vehicle_Type__c', 'Case.Model__c', 'Case.IT_Incident_Type__c', 'Case.Status', 'Case.ContactId', 'Case.ContactEmail', 'Case.Case_Complete_Voilation__c', 'Case.Origin', 'Case.Case_Submitted__c', 'Case.Case_Number__c', 'Case.Incident_Typ_e__c', 'Case.Type_of_Abuse_Exploitation__c', 'Case.Sign_of_Abuse_Neglect__c', 'Case.Result_of_Abuse__c', 'Case.Type_of_concern__c', 'Case.Type_of_Illness__c', 'Case.Provider_Address__c', 'Case.Provider_Email__c', 'Case.Provider_Name__c', 'Case.Date_returned_to_work__c', 'Case.Work_Status__c', 'Case.Type_of_Medical_Treatment_Provided__c', 'Case.Did_incident_result_in_absence_from_work__c', 'Case.Medical_Treatment_Provided__c', 'Case.Ambulance_Called__c', 'Case.X911_Called__c', 'Case.Multiple_Body_Parts__c', 'Case.Trunk__c', 'Case.Lower_Extremities__c', 'Case.Upper_Extremities__c', 'Case.Neck__c', 'Case.Type_Of_Injury__c', 'Case.Cause_of_injury__c', 'Case.Incident_Category__c', 'Case.Police__c', 'Case.Fire__c', 'Case.Ambulance__c', 'Case.Type_of_Security_Issue__c', 'Case.Emergency_Services_called__c', 'Case.Type_of_Property_Damage__c', 'Case.Facility_incident_Type__c', 'Case.Report_Number__c', 'Case.Badge_Number__c', 'Case.Officer_Name__c', 'Case.Police_Report_filed__c', 'Case.Steps_Taken__c', 'Case.Sensitive_Data__c', 'Case.Affected_System_Device_Type__c', 'Case.Incident_Type__c', 'Case.Head_Start_Campus_Name__c', 'Case.Community_Center_Name__c', 'Case.Adminstrative_Office_Name__c', 'Case.Senior_Centre_Name__c', 'Case.Workforce_Career_Office_Name__c', 'Case.Non_BakerRipley_Location_Name__c', 'Case.Charter_School_Name__c', 'Case.What_Part_of_the_employee_workday__c', 'Case.Event_Incident_Location__c', 'Case.Incident_Date_Time__c', 'Case.Detailed_Description_of_Request__c', 'Case.Training_Requested_For__c', 'Case.LMS_Case_Type__c', 'Case.Problem_Opportunity_Statement__c', 'Case.Desired_Outcome_s__c', 'Case.Proposed_Project_Due_Date__c', 'Case.Department__c', 'Case.Project_Sponsor__c', 'Case.Project_Name__c', 'Case.Training_Development_Type__c', 'Case.Reason_for_Recruitment__c', 'Case.X1099_Contractor__c', 'Case.Third_Party_Staffing__c', 'Case.Reason_for_Recruitment__c', 'Case.Recruiting_Case_Type__c', 'Case.Date_Needed__c', 'Case.Business_Purpose__c', 'Case.Data_Report_Type__c', 'Case.Access_Type__c', 'Case.HRIS_Case_Type__c', 'Case.Non_BakerRipley_Location_Name__c', 'Case.Location_of_Event_Leading_to_Grievance__c', 'Case.Date_Time_of_Event_Leading_to_Grievance__c', 'Case.Grievance_Category__c', 'Case.Referred_Candidate_Position__c', 'Case.Which_Department_s_Policy_Procedure__c', 'Case.Inquiry_Type__c', 'Case.Offboarding_Type__c', 'Case.Performance_Type__c', 'Case.Departmentt__c', 'Case.Employee_Management_Type__c', 'Case.Retirement_Benefits__c', 'Case.Candidates_Name__c', 'Case.Employee_Referral__c', 'Case.Course_Part_of_Degree_Plan__c', 'Case.Tuition_Fee__c', 'Case.Type_of_Degree__c', 'Case.Date_of_First_Class__c', 'Case.Course_Outcome__c', 'Case.Institution_s_Phone__c', 'Case.Institution_s_Zip_code__c', 'Case.Institution_s_State__c', 'Case.Institution_s_City__c', 'Case.Institution_s_Address__c', 'Case.Date_of_First_Class__c', 'Case.Course_Title__c', 'Case.Semester__c', 'Case.Name_of_School_Institution__c', 'Case.Compensation_Type__c', 'Case.Medical_Benefits__c', 'Case.Health_Spending_Account__c', 'Case.Insurances__c', 'Case.Medical_Benefits__c', 'Case.Limitation_Type__c', 'Case.Able_to_Perform_Essential_Job_Functions__c', 'Case.Benefit_Type__c', 'Case.End_Date__c', 'Case.Start_Date__c', 'Case.Case_Type__c', 'Case.Sub_Type__c'];
// 'Case.EmployeeName__c','Case.Entitlement_Name__c','Case .Description','Case.Comments','Case.ContactMobile','Case.SuppliedName','Case.SuppliedCompany','Case.SuppliedEmail','Case.ClosedDate','Case.CreatedDate','Case.ContactEmail','Case.ContactMobile',
export default class CaseSectionPage extends LightningElement {
  @api recordId;
  @track caseRecord;
  @track error;

  // -------------------------------------- Default false variable -------------------------------------------------//
  //Field dependancy variables    
  //Case Flow Screen 1----People and Culture--- P&C Case Information
  medicalBenefit = false;
  healthSpendingAccount = false;
  insurance = false;
  limitationTypeTemporary = false;
  benefitsDependendentField = false;
  subBenefitsDependendentField = false;
  accommodationsDependentFields = false;
  limitationTypeTemporary = false;
  compensationType = false;
  tuitionReimbursement = false;
  referralInformation = false;
  retirementBenefits = false;
  employeeManagement = false;
  employeePerformance = false;
  offboarding = false;
  generalInquiries = false;
  policy = false;
  grievances = false;
  bakerRipley = false;
  informationSystem = false;
  access = false;
  ePars = false;
  dataReports = false;
  timeAll = false;
  paidTimeOff = false;
  recruitment = false;
  trainingDevelopment = false;
  learningManagement = false;
  trainingRequest = false;
  //detailedDescription = false;
  propertyDamage = false;
  securityIssue = false;
  ambulance = false;
  fire = false;
  police = false;
  injury = false;
  medicalTreatment = false;
  didInjury = false;
  illness = false;
  incidentCat = false;
  nearMiss = false;
  incidentCat
  policeLabel = 'Police';
  ambulanceLabel = 'Ambulance';
  fireLabel = 'Fire';
  //Case Flow Screen ---- Case Record Type - Agency Incident Reporting
  administrativeOffice = false;
  charterSchool = false;
  communityCenter = false;
  seniorCenter = false;
  workforceCarrerOffice = false;
  nonBakerRipleylocation = false;
  headStartCampus = false;
  incidentType = false;
  stolenDevice = false;
  policeReportFiled = false;
  facilityIncident = false;
  emergencyService = false;
  caseType = false;
  whatDuties = false;

  // Section show/hide variable
  //Case Flow Screen 1----People and Culture--- P&C Case Information
  pncCaseInformationSection = false;
  schoolAttendSection = false;
  courseDetailsSection = false;
  showAccomodation = false;
  rewardCompensation = false;

  //Case Flow Screen ---- Case Record Type - Agency Incident Reporting
  incidentDetailsSection = false;
  abuseDetailSection = false;
  itDetailSection = false;
  facilityDetailSection = false;
  isVehicleDamageType = false;
  isVehicleAccident = false;
  employeeDetailDetailSection = false;
  showDateOfFatality = false;
  showIncidentAbsenceFromWork = false;
  showYesAbsenceFromWork = false;
  showAnticipatedReturnWork = false;
  showFirstDayBckAtWork = false;
  isMedicalTreatnmentProvided = false;
  complainceDetailScreen = false;
  showDFPS = false;
  refInf = false;
  attestationCheck = false;
  // ----------------------------------------//End - Default false variable -------------------------------------------//

  // Section expand variable  
  pncCaseInformationSectionBoolean = true;
  schoolAttendSectionBoolean = true;
  courseDetailsBoolean = true;
  incidentDetailsBoolean = true;
  incidentAbuseBoolean = true;
  incidentItBoolean = true;
  facilityItBoolean = true;
  policeReportBoolean = true;
  vehickeAccidentBoolean = true;
  bodyPartEffactedSectionBoolean = true;
  medicalTreatmentBoolean = true;
  caseInformationBoolean = true;
  contactInformationBoolean = true;
  webInformationBoolean = true;
  descriptionInformationBoolean = true;
  vehicleDamageBoolean = true;
  employeeDetailBoolean = true;
  injuryDetailBoolean = true;
  providerDetailBoolean = true;
  complainceDetailBoolean = true;
  tutRef = false;
  reimbursement = false;
  rembursmentDetail = true;
  showReimInfo = false;
  grievanceDetail = true;
  showRequectCaseType = false;
  showReportingReq = false;
  locationCangeRequest = false;
  complainceData = {}


  //----------------------------------- Section expand functions---------------------------------------//

  get descriptionInformation() {
    return this.descriptionInformationBoolean ? 'slds-section' : 'slds-section slds-is-open';
  }

  createComplainceObject() {
    let response = {}
    response.complainceType = ''
    response.whendidyoubecomeaware = ''
    response.isthisthefirsttimeyouarereporting = ''
    response.doesthisConflictinvolvedBakerRIpley = ''
    response.conflictType = ''
    response.howlongistheconflictexpecttolast = ''
    return response;
  }

  clickdescriptionInformation() {
    this.descriptionInformationBoolean = !this.descriptionInformationBoolean;
  }
  //------------------------------

  get webInformation() {
    return this.webInformationBoolean ? 'slds-section' : 'slds-section slds-is-open';
  }

  clickWebInformation() {
    this.webInformationBoolean = !this.webInformationBoolean;
  }
  //------------------------------

  get caseInformation() {
    return this.caseInformationBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickCaseInformation() {
    this.caseInformationBoolean = !this.caseInformationBoolean;
  }
  //------------------------------

  get contactInformation() {
    return this.contactInformationBoolean ? 'slds-section' : 'slds-section slds-is-open';
  }

  clickContactInformation() {
    this.contactInformationBoolean = !this.contactInformationBoolean;
  }
  //------------------------------

  //Case Flow Screen 1----People and Culture--- P&C Case Information
  get pncCaseInformation() {
    return this.pncCaseInformationSectionBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickpncCaseInformation() {
    this.pncCaseInformationSectionBoolean = !this.pncCaseInformationSectionBoolean;
  }

  //----------------------------
  get schoolAttend() {
    return this.schoolAttendSectionBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickschoolAttend() {
    this.schoolAttendSectionBoolean = !this.schoolAttendSectionBoolean;
  }

  //----------------------------
  get medicalTreatmentSection() {
    return this.medicalTreatmentBoolean ? 'slds-section' : 'slds-section slds-is-open';
  }

  clickMedicalTreatmentSection() {
    this.medicalTreatmentBoolean = !this.medicalTreatmentBoolean;
  }

  //----------------------------
  get courseDetails() {
    return this.courseDetailsBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickscourseDetails() {
    this.courseDetailsBoolean = !this.courseDetailsBoolean;
  }

  //Case Flow Screen ---- Case Record Type - Agency Incident Reporting
  get incidentDetails() {
    return this.incidentDetailsBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickincidentDetails() {
    this.incidentDetailsBoolean = !this.incidentDetailsBoolean;
  }

  get abuseDetails() {
    return this.incidentAbuseBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickAbuseDetails() {
    this.incidentAbuseBoolean = !this.incidentAbuseBoolean;
  }

  get itDetails() {
    return this.incidentItBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickItDetails() {
    this.incidentItBoolean = !this.incidentAbuseBoolean;
  }
  //----------------------------

  get policeReport() {
    return this.bodyPartEffactedSectionBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickpoliceReport() {
    this.bodyPartEffactedSectionBoolean = !this.bodyPartEffactedSectionBoolean;
  }

  get facilityDetails() {
    return this.facilityItBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickFacilityDetails() {
    this.facilityItBoolean = !this.facilityItBoolean;
  }

  get vehicleAccident() {
    return this.vehickeAccidentBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickVehicleReport() {
    this.vehickeAccidentBoolean = !this.vehickeAccidentBoolean;
  }

  get vehicleDamage() {
    return this.vehicleDamageBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickVehicleDamage() {
    this.vehicleDamageBoolean = !this.vehicleDamageBoolean;
  }

  get employeeDetails() {
    return this.employeeDetailBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickEmployeeDetails() {
    this.employeeDetailBoolean = !this.employeeDetailBoolean;
  }

  get injuryDeatils() {
    return this.injuryDetailBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickInjuryDetails() {
    this.injuryDetailBoolean = !this.injuryDetailBoolean;
  }

  get providerInf() {
    return this.providerDetailBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickProviderInformation() {
    this.providerDetailBoolean = !this.providerDetailBoolean;
  }

  get showComplainceDetail() {
    return this.complainceDetailBoolean ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickComlainceDetail() {
    this.complainceDetailBoolean = !this.complainceDetailBoolean;
  }

  get reimbursementDetail() {
    return this.rembursmentDetail ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickReimbursment() {
    this.rembursmentDetail = !this.rembursmentDetail;
  }

  get grievanceSection() {
    return this.grievanceDetail ? 'slds-section slds-is-open' : 'slds-section';
  }

  clickGrievance() {
    this.grievanceDetail = !this.grievanceDetail;
  }



  //----------------------------

  get bodyPartEffacted() {
    return this.policeReportBoolean ? 'slds-section' : 'slds-section slds-is-open';
  }

  clickbodyPartEffacted() {
    this.policeReportBoolean = !this.policeReportBoolean;
  }

  //-----------------------------------//End - Section expand functions---------------------------------------//  
  
  @wire(getRecord, { recordId: "$recordId", fields: CaseFields })
  caseRecordData({ error, data }) {
    if (data) {
      this.caseRecord = data;
      this.error = undefined;
      console.log('this.caseRecord ', JSON.stringify(this.caseRecord))
      console.log('this.caseRecord recordType -- ' + this.caseRecord.recordTypeInfo.name);
      if (this.caseRecord.recordTypeInfo.name == 'Incident Related Case') {
        this.incidentDetailsSection = true;
      }
      if (this.caseRecord.recordTypeInfo.name == 'Compliance Related Case') {
        this.complainceDetailScreen = true;
      }
      if (this.caseRecord.recordTypeInfo.name == 'People and Culture Related Case') {
        this.pncCaseInformationSection = true;
      }
      for (let field in this.caseRecord.fields) {
        if (Object.prototype.hasOwnProperty.call(this.caseRecord.fields, field)) {
          if (this.caseRecord.fields[field].value) {
            this.complainceData = this.createComplainceObject()
            this.complainceData.complainceType = this.caseRecord.fields.Compliance_Type__c.value
            this.complainceData.whendidyoubecomeaware = this.caseRecord.fields.When_did_you_become_aware__c.value
            this.complainceData.isthisthefirsttimeyouarereporting = this.caseRecord.fields.is_this_the_first_time_you_are_reporting__c.value
            this.complainceData.doesthisConflictinvolvedBakerRIpley = this.caseRecord.fields.Does_this_Conflict_involved_BakerRIpley__c.value
            this.complainceData.conflictType = this.caseRecord.fields.Conflict_Type__c.value
            this.complainceData.howlongistheconflictexpecttolast = this.caseRecord.fields.How_long_is_the_conflict_expect_to_last__c.value
            //--------------- Case Flow Screen ---- Case Record Type - Agency Incident Reporting ----------------------//
            if (field == 'Incident_Typ_e__c' && (this.caseRecord.fields[field].value == 'Abuse/Exploitation & Neglect')) {
              this.abuseDetailSection = true;
            }

            if (field == 'Tuition_Reimbursement_Type__c') {
              this.showReimInfo = true;
            }

            if (field == 'Case_Submitted__c' && (this.caseRecord.fields[field].value == 'Yes')) {
              this.showDFPS = true;
            }

            if (field == 'Incident_Typ_e__c' && (this.caseRecord.fields[field].value == 'IT Incident')) {
              this.itDetailSection = true;
            }

            if (field == 'Incident_Typ_e__c' && (this.caseRecord.fields[field].value == 'Facility Incident')) {
              this.facilityDetailSection = true;
            }

            if (field == 'Incident_Typ_e__c' && this.caseRecord.fields[field].value == 'Employee related Incident') {
              this.employeeDetailDetailSection = true;
            }

            if (field == 'Event_Incident_Location__c' && this.caseRecord.fields[field].value == 'Administrative Office') {
              this.administrativeOffice = true;
            }

            if (field == 'Event_Incident_Location__c' && this.caseRecord.fields[field].value == 'Charter School') {
              this.charterSchool = true;
            }

            if (field == 'Event_Incident_Location__c' && this.caseRecord.fields[field].value == 'Community Center') {
              this.communityCenter = true;
            }

            if (field == 'Event_Incident_Location__c' && this.caseRecord.fields[field].value == 'Head Start Campus') {
              this.headStartCampus = true;
            }

            if (field == 'Event_Incident_Location__c' && this.caseRecord.fields[field].value == 'Senior Center') {
              this.seniorCenter = true;
            }

            if (field == 'Event_Incident_Location__c' && this.caseRecord.fields[field].value == 'Workforce Office') {
              this.workforceCarrerOffice = true;
            }

            if (field == 'Event_Incident_Location__c' && this.caseRecord.fields[field].value == 'Non-BakerRipley location') {
              this.nonBakerRipleylocation = true;
            }

            if (field == 'Case_Type__c' && this.caseRecord.fields[field].value == 'IT Issue') {
              this.incidentType = true;
            }

            if (field == 'IT_Incident_Type__c' && this.caseRecord.fields[field].value == 'Lost/Stolen Devices') {
              this.stolenDevice = true;
            }

            if (field == 'Police_Report_filed__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.policeReportFiled = true;
            }

            if (field == 'Facility_incident_Type__c' && this.caseRecord.fields[field].value == 'Property Damage') {
              this.propertyDamage = true;
              this.stolenDevice = true;
            }

            if (field == 'Facility_incident_Type__c' && this.caseRecord.fields[field].value == 'Security issue') {
              this.securityIssue = true;
              this.stolenDevice = true;
            }

            if (field == 'Emergency_Services_called__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.emergencyService = true;
            }

            if (field == 'Emergency_Services_called__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.emergencyService = true;
            }

            if (field == 'Type_of_Property_Damage__c' && this.caseRecord.fields[field].value == 'Vehicle') {
              this.isVehicleDamageType = true;
            }

            if (field == 'Incident_result_in_loss_of_life__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.showDateOfFatality = true;
              this.showYesAbsenceFromWork = false;
            }

            if (field == 'Incident_result_in_loss_of_life__c' && this.caseRecord.fields[field].value == 'No') {
              this.showIncidentAbsenceFromWork = true;
              this.whatDuties = true;
            }

            if (field == 'Employee_returned_to_work__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.showFirstDayBckAtWork = true;    
              this.whatDuties = true;          
            }

            if (field == 'Employee_returned_to_work__c' && this.caseRecord.fields[field].value == 'No') {
              this.showAnticipatedReturnWork = true;
            }

            if (field == 'Accident__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.isVehicleAccident = true;
            }

            if (field == 'Police__c' && this.caseRecord.fields[field].value) {
              this.police = true;
            }

            if (field == 'Fire__c' && this.caseRecord.fields[field].value) {
              this.fire = true;
            }

            if (field == 'Ambulance__c' && this.caseRecord.fields[field].value) {
              this.ambulance = true;
            }

            if (field == 'Incident_Category__c' && this.caseRecord.fields[field].value == 'Injury') {
              this.injury = true;
              this.incidentCat = true;
            }

            if (field == 'Incident_Category__c' && this.caseRecord.fields[field].value == 'Illness') {
              this.illness = true;
              this.incidentCat = true;
            }

            if (field == 'Incident_Category__c' && this.caseRecord.fields[field].value == 'Near Miss') {
              this.nearMiss = true;
            }

            if (field == 'Medical_Treatment_Provided__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.isMedicalTreatnmentProvided = true;
            }

            if (field == 'Did_incident_result_in_absence_from_work__c' && this.caseRecord.fields[field].value == 'Yes') {
              this.showYesAbsenceFromWork = true;
            }
            if (field == 'Did_incident_result_in_absence_from_work__c' && this.caseRecord.fields[field].value == 'No') {
              this.whatDuties = true;
            }
            if(this.showYesAbsenceFromWork && this.showAnticipatedReturnWork){
              console.log(':: Check');
              this.whatDuties = false;
            }



            //---------- End - Case Flow Screen ---- Case Record Type - Agency Incident Reporting ---------------------//  

            //--------------- Case Flow Screen ---- Case Record Type - People and Culture ----------------------//

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'Accommodation') {
              this.showAccomodation = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'Benefits') {
              this.benefitsDependendentField = true;
            }
            if (field == 'Benefit_Type__c' && (this.caseRecord.fields[field].value == 'Critical Illness Insurance' || this.caseRecord.fields[field].value == 'Dental Insurance' || this.caseRecord.fields[field].value == 'Disability Insurance' || this.caseRecord.fields[field].value == 'Flexible Spending Account' || this.caseRecord.fields[field].value == 'Medical Insurance')) {
              this.subBenefitsDependendentField = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'Compensation') {
              this.rewardCompensation = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'Employee Management') {
              this.employeeManagement = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'P&C General Inquires') {
              this.generalInquiries = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'Grievances') {
              this.grievances = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'HR Information System') {
              this.informationSystem = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'Recruitment') {
              this.recruitment = true;
            }

            if (field == 'P_C_Type__c' && this.caseRecord.fields[field].value == 'Training and Development') {
              this.trainingDevelopment = true;
            }

            if (field == 'Benefit_Type__c' && this.caseRecord.fields[field].value == 'Critical Illness Insurance' && this.caseRecord.fields[field].value == 'Dental Insurance' && this.caseRecord.fields[field].value == 'Disability Insurance' && this.caseRecord.fields[field].value == 'Flexible Spending Account' && this.caseRecord.fields[field].value == 'Medical Insurance') {
              this.medicalBenefit = true;
            }


            if (field == 'Compensation_Type__c' && this.caseRecord.fields[field].value == 'Tuition Reimbursement') {
              this.tuitionReimbursement = true;
              this.schoolAttend = true;
              this.courseDetailsSection = true;
            }

            if (field == 'Compensation_Type__c' && this.caseRecord.fields[field].value == 'Referral Information') {
              this.referralInformation = true;
            }

            if (field == 'Compensation_Type__c' && this.caseRecord.fields[field].value == 'Retirement Benefits') {
              this.retirementBenefits = true;
            }

            if (field == 'Employee_Management_Type__c' && this.caseRecord.fields[field].value == 'Employee Performance') {
              this.employeePerformance = true;
            }

            if (field == 'Employee_Management_Type__c' && this.caseRecord.fields[field].value == 'Offboarding') {
              this.offboarding = true;
            }

            if (field == 'Inquiry_Type__c' && this.caseRecord.fields[field].value == 'Policy') {
              this.policy = true;
            }

            if (field == 'Inquiry_Type__c' && this.caseRecord.fields[field].value == 'Referral Information') {
              this.refInf = true;
            }

            if (field == 'Inquiry_Type__c' && this.caseRecord.fields[field].value == 'Tuition Reimbursement') {
              this.tutRef = true;
            }
            if (field == 'Tuition_Reimbursement_Type__c' && this.caseRecord.fields[field].value == 'Reimbursement Request') {
              this.tutRef = true;
              this.reimbursement =  true;
            }
            if (field == 'Attestation__c' && this.caseRecord.fields[field].value == true) {
              this.attestationCheck = true;
            }

            if (field == 'Location_of_Event_Leading_to_Grievance__c' && this.caseRecord.fields[field].value == 'Non-BakerRipley location') {
              this.bakerRipley = true;
            }

            if (field == 'HRIS_System_Type__c' && this.caseRecord.fields[field].value == 'UKG') {
              this.showRequectCaseType = true;
            }

            if (field == 'HRIS_Case_Type__c' && this.caseRecord.fields[field].value == 'Access') {
              this.access = true;
            }

            if (field == 'HRIS_Case_Type__c' && this.caseRecord.fields[field].value == 'Data & Reports') {
              this.dataReports = true;
            }
            if (field == 'HRIS_Case_Type__c' && this.caseRecord.fields[field].value == 'Location Change Request') {
              this.locationCangeRequest = true;            
            }
            console.log('this.locationCangeRequest: '+this.locationCangeRequest);

            if (field == 'Limitation_Type__c' && this.caseRecord.fields[field].value == 'Temporary') {
              this.limitationTypeTemporary = true;
            }

            if (field == 'Data_Report_Type__c' && this.caseRecord.fields[field].value == 'Reporting Request') {
              this.showReportingReq = true;
            }

            if (field == 'Training_Development_Type__c' && this.caseRecord.fields[field].value == 'Learning Management System(LMS)') {
              this.learningManagement = true;
            }

            if (field == 'Training_Development_Type__c' && this.caseRecord.fields[field].value == 'Training Request') {
              this.trainingRequest = true;
            }
            //---------------//End - Case Flow Screen ---- Case Record Type - People and Culture ----------------------//                     
          }
        }
      }

    } else if (error) {
      console.log('OUTPUT : ', this.recordId);
      console.log('error-- ' + JSON.stringify(error));
      this.error = error;
      this.record = undefined;
    }
  }
}