import { LightningElement, api, track } from 'lwc';
export default class EnrolledCompletedTrainingUI extends LightningElement {


    @api recordsData = null;
    @api selectedType = '';
    @track displayChilds = false;
    displayUI = false;

    connectedCallback() {
        console.log('enrolledCompletedTrainingUI  ' + JSON.stringify(this.recordsData));
        console.log('enrolledCompletedTrainingUI  ' + JSON.stringify(this.selectedType));
        if (this.recordsData != null && Array.isArray(this.recordsData) && this.recordsData.length > 0) {
            this.displayUI = true;
        } else {
            this.displayUI = false;
        }
        if (this.selectedType == 'Learning Paths' || this.selectedType == 'Completed Learning paths') {
            this.displayChilds = true;
        } else {
            this.displayChilds = false;
        }
        console.log('enrolledCompletedTrainingUI ' + this.displayChilds);
    }
}