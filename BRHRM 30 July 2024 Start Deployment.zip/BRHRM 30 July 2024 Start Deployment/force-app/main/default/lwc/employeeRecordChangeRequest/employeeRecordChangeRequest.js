import { LightningElement,track,wire } from 'lwc';
import getEmployee from '@salesforce/apex/EmployeeRecordChangeRequestCtrl.getEmployee';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import uploadFiles from '@salesforce/apex/FileUploadMultiController.uploadFiles';
const MAX_FILE_SIZE = 2097152;

export default class EmployeeRecordChangeRequest extends LightningElement {
oldValue;
@track mapData;
@track filesData = [];
@wire(getEmployee,{})
employee({error,data}) {
    if (data) {
        this.mapData = data;
        console.log(this.mapData);
    } else if (error) {
        window.console.log(error);
    }
}
handleFieldNameChange(e){
    console.log(e.target.value);
    this.oldValue='';
    let fName = e.target.value.toLowerCase();
    for (let key in this.mapData) {
        console.log(key);
        console.log(fName);
        if(fName != undefined && key == fName){
            this.oldValue = this.mapData[key];
            console.log(this.oldValue);
            break;
        }
    }  
}

handleSubmit(event){
    event.preventDefault();
    const fields = event.detail.fields;
    for (let key in this.mapData) {
        if(key == 'id'){
            
            fields.Employee__c = this.mapData[key];
            break;
        }
    }
    this.template.querySelector('lightning-record-edit-form').submit(fields);
    }

displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }

handleSuccess(event) {
        console.log('onsuccess event recordEditForm', event.detail.id);
        this.displayMessage('Change Request Created!!','success','Change Request is succesfully submited.');
        if(this.filesData == [] || this.filesData.length == 0) {
        }else{
            uploadFiles({
                recordId : event.detail.id,
                filedata : JSON.stringify(this.filesData)
            })
        }
        this.dispatchEvent(new CustomEvent('close'));
    }

    handleFileUploaded(event) {
        console.log('Test');
        console.log(event.target.files.length);
        if (event.target.files.length > 0) {

            for(var i=0; i< event.target.files.length; i++){
                if (event.target.files[i].size > MAX_FILE_SIZE) {
                    this.showToast('Error!', 'error', 'File size exceeded the upload size limit.');
                    return;
                }
                let file = event.target.files[i];
                let reader = new FileReader();
                reader.onload = e => {
                    var fileContents = reader.result.split(',')[1]
                    this.filesData.push({'fileName':file.name, 'fileContent':fileContents});
                };
                reader.readAsDataURL(file);
            }
        }
    }



}