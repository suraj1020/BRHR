import { LightningElement, wire, track } from 'lwc';
import uId from '@salesforce/user/Id';
import getEmployeeData from '@salesforce/apex/TrainingController.getEmployeeData';
import getCompletedTrainings from '@salesforce/apex/TrainingController.getCompletedTrainings';
import getPath from '@salesforce/apex/LearningPathController.getCompletedLearningPath';
import { refreshApex } from '@salesforce/apex';
import { NavigationMixin } from 'lightning/navigation';
import getEnrolledLearningPathTrainings from '@salesforce/apex/LearningPathController.getEnrolledLearningPathTrainings';

const column = [
    { label: 'Training Name', fieldName: 'TrainingName' },
    { label: 'Training Type', fieldName: 'TrainingType' },
    { label: 'Priority', fieldName: 'Priority' },
    { label: 'Status', fieldName: 'Status' },
    {
        label: "Start DateTime",
        fieldName: "startDateTime",
        type: "date",
        typeAttributes: {
            year: "numeric",
            month: "long",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        }
    },
    {
        label: "End DateTime",
        fieldName: "endDateTime",
        type: "date",
        typeAttributes: {
            year: "numeric",
            month: "long",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit"
        }
    },
];

export default class CompletedTrainingsCmp extends NavigationMixin(LightningElement) {

    @track wiredData = [];
    @track myTrainingsData = [];
    userId = uId;
    emptid = ''
    empId = '';
    empProfile = '';
    isLoading = true;
    showMessage = false;
    learningPathMsg = 'You do not have any completed Learning Paths.';
    msg = 'You do not have any Completed Trainings.';
    highFlag = '/img/samples/flag_red.gif'
    mediumFlag = '/img/samples/flag_yellow.gif'
    lowFlag = '/img/samples/flag_green.gif'
    isModalOpen = false;
    learningPathModal = false;
    @track learningPathWiredData = [];
    @track pathData = [];
    pathDataDummy = [];
    myTrainingsDataDummy = [];
    @track learningPathTrainingData = [];
    learningPathTrainingColumn = column;
    searchData = [];
    displayCompletedTraining = false;
    displayCompletedLearningPath = false;


    /******************************* Get Employee Data ************************************/
    /*@wire(getEmployeeData, { userId: '$userId' })
    getEmployee({ error, data }) {
        if (data) {
            if (data.length > 0) {
                this.empId = data[0].Id;
               
            }else
            {
                this.msg = `No Employee found for your user`
                this.isLoading = false;
            }
        }
        if (error) {
            console.log('error', error);
 
        }
    }*/

    @wire(getEmployeeData, { userId: '$userId' })
    getEmployee({ error, data }) {
        if (data) {
            if (data.length > 0) {
                this.empId = data[0].Id;
                this.empProfile = data[0].JobProfile;
                console.log('this.empId -- ' + this.empId + ' -- ' + this.empProfile);
                if (this.empProfile == undefined || this.empProfile == '') {
                    this.showMessage = true;
                    this.learningPathMsg = `You don't have any Learning Path`
                    this.isLoading = false;
                }
            } else {
                this.learningPathMsg = `No Employee found for your user`
                this.isLoading = false;
            }
        }
        if (error) {
            console.log('error', error);

        }
    }

    /**************************Get Completed Trainings **************************************/
    @wire(getCompletedTrainings, { empId: '$empId' })
    lPath(result) {
        console.log('getCompletedTrainings -- ' + JSON.stringify(result));
        this.wiredData = result;
        if (result.data) {
            if (result.data.length > 0) {
                this.myTrainingsData = result.data;
                this.myTrainingsDataDummy = result.data;
                this.searchData = result.data
                this.showMessage = false;
                console.log('this.myTrainingsData ------ ', JSON.stringify(this.myTrainingsData));
            }
            else {
                this.showMessage = true;
            }
            this.isLoading = false;
        } if (result.error) {
            console.log('error', result.error);
            this.isLoading = false;
        }
    }

    /**************************Get Learning Path **************************************/
    @wire(getPath, { empId: '$empId', jobProfile: '$empProfile' })
    learningPath(result) {
        this.learningPathWiredData = result;
        if (result.data) {
            if (result.data.length > 0) {
                this.pathData = JSON.parse(JSON.stringify(result.data));
                this.pathDataDummy = JSON.parse(JSON.stringify(result.data));
                this.showMessage = false;
                // this.pathData.forEach(eachData=> {
                //     eachData.eLDs.forEach(eachLD=> {
                //         eachData.learningPathTraining.forEach(eachP=> {
                //             if(eachLD.Get_Training__c == eachP.TrainingName) {
                //                 eachLD.TrainingPriority = eachP.Priority
                //             }
                //             this.isShowFields = true
                //         })
                //     })
                // })
                // this.pathDataDummy.forEach(eachData=> {
                //     eachData.eLDs.forEach(eachLD=> {
                //         eachData.learningPathTraining.forEach(eachP=> {
                //             if(eachLD.Get_Training__c == eachP.TrainingName) {
                //                 eachLD.TrainingPriority = eachP.Priority
                //             }
                //             this.isShowFields = true
                //         })
                //     })
                // })
                console.log('Complete Learning Path ------ ' + JSON.stringify(this.pathData));
            }
            else {
                this.learningPathMsg = `You don't have any Learning Path`;
                this.showMessage = true;
            }
            this.isLoading = false;
        } if (result.error) {
            console.log('error', result.error);
            this.isLoading = false;
        }
    }

    displayLearningPathTrainings(event) {
        this.learningPathModal = true;
        getEnrolledLearningPathTrainings({ learningPathId: event.target.dataset.id, employeeId: this.empId })
            .then(res => {
                this.learningPathTrainingData = res;
            })
            .catch(error => {
                this.displayMessage('Error Occured', 'error', reduceErrors(error).toString())
            });
    }

    learningPathCloseModal() {
        this.learningPathModal = false;
    }

    handleRefresh() {
        this.isLoading = true;
        refreshApex(this.wiredData);
        this.isLoading = false;
    }

    openModal(e) {
        this.isModalOpen = true;
        this.emptid = e.target.dataset.id;
        this.emplearningpath = e.target.dataset.emplearningpath;
        console.log('this.emptid -- ' + this.emptid + ' -- ' + this.emplearningpath);
    }
    closeModal() {
        this.isModalOpen = false;

    }
    openSurveyPage(event) {
        let surveyId = event.target.dataset.id;
        console.log(' surveyId -- ' + surveyId);
        let pageURL = '/surveys?recordId=' + surveyId;
        console.log('pageURL -- ' + pageURL);
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: pageURL
            }
        })
    }

    handleSearch(event) {
        console.log('handleSearch ' + JSON.stringify(event.detail));
        if (event.detail.type == 'Completed Learning paths') {
            this.myTrainingsData = [];
            this.pathData = event.detail.filteredData;
        } else if (event.detail.type == 'Completed Trainings') {
            this.pathData = [];
            this.myTrainingsData = event.detail.filteredData;
        }
    }

    sendDataToDisplay(event) {
        console.log('sendDataToDisplay event handled ' + event.detail);
        if (event.detail == 'Completed Trainings') {
            console.log('1');
            this.displayCompletedLearningPath = false;
            this.myTrainingsData = this.myTrainingsDataDummy;
            this.searchData = this.myTrainingsDataDummy;
            console.log('Complete Learning Path to send------ ' + JSON.stringify(this.searchData));
            this.displayCompletedTraining = true;
        } else if (event.detail == 'Completed Learning paths') {
            console.log('2');
            this.displayCompletedTraining = false;
            this.pathData = this.pathDataDummy;
            this.searchData = this.pathDataDummy;
            this.displayCompletedLearningPath = true;
        } else {
            console.log('3');
            this.displayCompletedTraining = false;
            this.displayCompletedLearningPath = false;
            this.searchData = [];
            this.myTrainingsData = [];
        }
    }

    displayAllData(event) {
        console.log('event.detail ' + JSON.stringify(event.detail));
        if (event.detail.tabName == "completedTaining" && event.detail.enrolledType == "Completed Trainings") {
            this.myTrainingsData = event.detail.dataToDisplay;
        } else if (event.detail.tabName == "completedTaining" && event.detail.enrolledType == "Completed Learning paths") {
            this.pathData = event.detail.dataToDisplay;
        }
    }

}