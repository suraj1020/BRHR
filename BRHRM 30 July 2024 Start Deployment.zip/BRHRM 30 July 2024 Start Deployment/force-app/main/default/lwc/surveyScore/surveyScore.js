import { LightningElement, api, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

import { NavigationMixin } from 'lightning/navigation';
import homePage from '@salesforce/label/c.CommunitySiteHomeURL';
import getScore from '@salesforce/apex/SurveyScoreController.getScore';

const columns = [
    { label: 'Category', fieldName: 'category' },
    { label: 'Total Score', fieldName: 'TotalScore' },
    { label: 'Survey Score', fieldName: 'SurveyScore' },
    { label: 'Prefer not to answer', fieldName: 'notAnswered' },
];
export default class SurveyScore extends NavigationMixin (LightningElement) {
@api recordId;
data = [];
columns = columns;

connectedCallback() {
    getScore({surveyTKId:this.recordId})
            .then(res=>
            {  console.log(this.recordId, 'Survey Score Card -->', JSON.stringify(res));
                this.data = res; 
            })
            .catch(error=>
            {
              console.log('Error --> ',JSON.stringify(error));
              this.displayMessage('Error Occured','error',error.body.message)
            });
    
}

      displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
        }
  /*navigateNext() {
    //alert("In Survey --- Score Component..");
    //top.location.href = homePage;
    window.parent.location.href = homePage;
    //this.navigateToWebPage();
  }*/

  navigateToWebPage() {
    // Navigate to a URL
    this[NavigationMixin.Navigate](
      {
        type: "standard__webPage",
        attributes: {
          url: homePage,
        },
      },
      true, // Replaces the current page in your browser history with the URL
    );
  }
}