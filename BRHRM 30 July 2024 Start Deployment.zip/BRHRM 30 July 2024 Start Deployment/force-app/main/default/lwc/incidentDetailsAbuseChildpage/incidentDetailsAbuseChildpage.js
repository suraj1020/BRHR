import { LightningElement, track, api, wire } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import SignOfAbuse_Field from '@salesforce/schema/Case.Sign_of_Abuse_Neglect__c';
import TypeOfAbuse_Field from '@salesforce/schema/Case.Type_of_Abuse_Exploitation__c';
import ResultFromAbuse_Field from '@salesforce/schema/Case.Result_of_Abuse__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
export default class IncidentDetailsAbuseChildpage extends LightningElement {

    agentPolicyURL = window.location.origin+'/employeeservicesample/s/libraries?tabset-bac31=9f1eb';
    trainingMaterialURL = window.location.origin+'/employeeservicesample/s/libraries?tabset-bac31=36c78';
    @api caseObj = {};
    //@track caseObjData = {};
    @track caseIncidentRecordTypeId;
    @track signOfAbuseoptions = [];
    @track typeOfAbuseoptions = [];
    @track resultFromAbuseOptions = [];
    @track yesNoOptions = [
        { label: 'Yes', value: 'Yes' },
        { label: 'No', value: 'No' }
    ];
    showDpsField;
    isLoaded = true;
    @api recordTypeName;
    @api currentPage;
    @track signAbuseOptions = [];
    @track resultAbuseOptions = [];

    @wire(getObjectInfo, { objectApiName: Case_Object })
    objectInfo({ data, error }) {
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                // console.log(rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Incident Related Case') {
                    this.caseIncidentRecordTypeId = rtis[element].recordTypeId;
                }
            });
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: SignOfAbuse_Field })
    signOfAbusePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.signOfAbuseoptions = [...this.signOfAbuseoptions, { value: val.value, label: val.label }];
            });
            console.log('this.signOfAbuseoptions--> ' + JSON.stringify(this.signOfAbuseoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfAbuse_Field })
    typeOfAbusePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfAbuseoptions = [...this.typeOfAbuseoptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfAbuseoptions--> ' + JSON.stringify(this.typeOfAbuseoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: ResultFromAbuse_Field })
    resultFromAbusePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.resultFromAbuseOptions = [...this.resultFromAbuseOptions, { value: val.value, label: val.label }];
            });
            console.log('this.resultFromAbuseOptions--> ' + JSON.stringify(this.resultFromAbuseOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    connectedCallback() {
        let obj = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj;
        if (this.caseObj.hasOwnProperty('Case_Submitted__c')) {
            if (this.caseObj.Case_Submitted__c == 'Yes') {
                this.showDpsField = true;
            } else {
                this.showDpsField = false;
            }
        }

        if (this.caseObj.hasOwnProperty('Sign_of_Abuse_Neglect__c')) {
            if(Array.isArray(this.caseObj.Sign_of_Abuse_Neglect__c)) {
                this.signAbuseOptions = [...this.signAbuseOptions, ...this.caseObj.Sign_of_Abuse_Neglect__c]
            }else {
                this.signAbuseOptions = [...this.signAbuseOptions, ...this.caseObj.Sign_of_Abuse_Neglect__c.split(';')]
            }
        }

        if (this.caseObj.hasOwnProperty('Result_of_Abuse__c')) {
            if(Array.isArray(this.caseObj.Result_of_Abuse__c)) {
                this.resultAbuseOptions = [...this.resultAbuseOptions, ...this.caseObj.Result_of_Abuse__c]
            }else {
                this.resultAbuseOptions = [...this.resultAbuseOptions, ...this.caseObj.Result_of_Abuse__c.split(';')]
            }
        }
    }

    handleChange(event) {
        if (event.target.name == 'Case_Submitted__c') {
            if (event.target.value == 'Yes') {
                this.showDpsField = true;
            } else {
                this.showDpsField = false;
                this.caseObj.Case_Number__c = '';
            }
        }
        this.caseObj[event.target.name] = event.target.value;
        console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));
    }

    @api
    handleNext() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDLValid = [...this.template.querySelectorAll("lightning-dual-listbox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if (allValid && allCBValid && allDLValid) {
            this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.caseObj }));
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }
    }

    displayMessage(title, variant, msg) {
        const toastEvent = new ShowToastEvent({
            title: title,
            message: msg,
            variant: variant,
        });
        this.dispatchEvent(toastEvent);
    }

    @api handlePrevious() {
        this.dispatchEvent(new CustomEvent('previousclick', { detail: this.caseObj }));
    }

    @api
    handleSaveAndExit() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDLValid = [...this.template.querySelectorAll("lightning-dual-listbox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid && allCBValid && allDLValid) {
            this.isLoaded = false;
            this.caseObj.Status = 'Draft';
            this.caseObj.CurrentPage__c = this.currentPage;
            createCaseOnSubmit({
                caseObj: this.caseObj,
                fileData: [],
                incidentUserList: [],
                recordTypeName: this.recordTypeName,
                injuryData: [],
                damageData: [],
                courseInformation: []
            })
                .then(result => {
                    if (result) {
                        this.isLoaded = true;
                        console.log('--92--> ' + result);
                        this.displayMessage("Success", "success", "Case saved as draft.");
                        this.dispatchEvent(new CustomEvent('saveexit'));
                    } else {
                        this.isLoaded = true;
                    }
                }).catch(error => {
                    this.displayMessage("Error", "error", reduceErrors(error).toString());
                    this.isLoaded = true;
                })
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }

    }

}