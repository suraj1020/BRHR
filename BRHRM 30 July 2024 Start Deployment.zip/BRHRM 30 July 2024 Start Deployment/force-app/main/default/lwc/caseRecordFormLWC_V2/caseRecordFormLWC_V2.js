import { LightningElement,api,wire,track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import Subject_FIELD from '@salesforce/schema/Case.Subject';
import Origin_FIELD from '@salesforce/schema/Case.Origin';
import Reason_FIELD from '@salesforce/schema/Case.Reason';
import Sub_Type_FIELD from '@salesforce/schema/Case.Sub_Type__c';
import Type_FIELD from '@salesforce/schema/Case.Type';
import Incident_Type_FIELD from '@salesforce/schema/Case.Event_Incident_Location__c';
import Type_Of_Injury_FIELD from '@salesforce/schema/Case.Type_Of_Injury__c';
import { getPicklistValuesByRecordType,getObjectInfo } from 'lightning/uiObjectInfoApi';
import CASE_OBJECT from '@salesforce/schema/Case';
import uploadFiles from '@salesforce/apex/FileUploadMultiController.uploadFiles';
const MAX_FILE_SIZE = 2097152;

export default class CaseRecordFormLwc extends NavigationMixin(LightningElement) {
    @track firstRadioButton = true;
    @track isView = true;
    @track isRadioButtonVisible = true;
    @track isSaveButtonVisible = false;
    @track isPicklistVisible = false;
    @track doubleButtonVisible = false;
    @track singleButtonVisible = true;
    @track isPicklistFieldsVisible = true;
    recordId = '';
    @track filesData = [];
    @track areDetailsVisible = false;
   
    @api recordTypeId;
    @api objectApiName = 'Case';
    @track type_options = [];
    @track sub_type_options;
    @track Incident_Type_options;
    @track Type_Of_Injury_options;
    @track value;
    fields = [Type_FIELD, Sub_Type_FIELD, Incident_Type_FIELD,Type_Of_Injury_FIELD];
    
    @wire(getObjectInfo, { objectApiName: CASE_OBJECT })
    objectInfo({data,error}){
if(data){
  
    const rtis = data.recordTypeInfos;
 
    Object.keys(rtis).forEach(element => {
        console.log(rtis[element]);
        if(rtis[element].available && !rtis[element].master){
            this.type_options.push({ label: rtis[element].name, value: rtis[element].recordTypeId  });   
        }     
    });
  
this.value = this.type_options[0].value;
this.recordTypeId =this.type_options[0].value;

} else if(error){
    let message = 'Unknown error';
    if (Array.isArray(error.body)) {
        message = error.body.map(e => e.message).join(', ');
    } else if (typeof error.body.message === 'string') {
        message = error.body.message;
    }
    this.dispatchEvent(
        new ShowToastEvent({
            title: 'Error loading Case',
            message,
            variant: 'error',
        }),
    );
}
    }

    handleChange(event){
        this.recordTypeId = event.detail.value;
    }

    nextClickButton(event){
       if(event.target.name === 'first'){
        this.isRadioButtonVisible = false;
        this.isPicklistVisible = true;
        this.singleButtonVisible = false;
        this.doubleButtonVisible = true;
        this.areDetailsVisible=true; 
       } else if(event.target.name === 'start'){
this.firstRadioButton = false;
       }
       else if(event.target.name == 'second') {
        this.template.querySelectorAll('lightning-input-field').forEach(element => {
            element.reportValidity();
        });

        let nameCmp = this.template.querySelector(".disable-class2");
       
if(!nameCmp.value){
    return;
}

     
        this.isSaveButtonVisible = true;
        this.doubleButtonVisible = false;
        this.template.querySelectorAll('.disable-class').forEach(item=>{
            item.classList.add('slds-assistive-text');
 
        });
        
       }
       
       
    }
    backClickButton(event){
      
        if(event.target.name === 'first'){
            this.isRadioButtonVisible = true;
            this.isPicklistVisible = false;
            this.singleButtonVisible = true;
            this.doubleButtonVisible = false;
        } 
        else if(event.target.name === 'start'){
            this.firstRadioButton = true;
                   }
                   else if(event.target.name === 'second'){
            this.template.querySelectorAll('.disable-class').forEach(item=>{
                item.classList.remove('slds-assistive-text');
     
            }); 
            this.isSaveButtonVisible = false;
            this.doubleButtonVisible = true;
        }
        

    }
    handleSubmit(){

    }

    handleSuccess(event){
       
        const toastEvent = new ShowToastEvent({
            title: 'Toast message',
            message: 'Case Record has been created',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(toastEvent);
        this.recordId = event.detail.id;
        if(this.filesData == [] || this.filesData.length == 0) {
         //   this.showToast('Error', 'error', 'Please select files first'); return;
        }else{
            uploadFiles({
                recordId : this.recordId,
                filedata : JSON.stringify(this.filesData)
            })
        }

        
    
    this[NavigationMixin.Navigate]({
        type: 'standard__recordPage',
        attributes: {
            recordId: event.detail.id,
            objectApiName: 'Case',
            actionName: 'view'
        }
    });
        
    }

    handleLoad(event) {
        this.areDetailsVisible=false; 
     }

     errorHandler(event){
        alert('Error');
        let message = 'Unknown error';
        if (Array.isArray(error.body)) {
            message = error.body.map(e => e.message).join(', ');
        } else if (typeof error.body.message === 'string') {
            message = error.body.message;
        }
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Error loading Case',
                message,
                variant: 'error',
            }),
        );
     }

     validateFields() {
        this.template.querySelectorAll('lightning-input-field').forEach(element => {
            element.reportValidity();
        });
    }
 
    handleFileUploaded(event) {
        if (event.target.files.length > 0) {
            for(var i=0; i< event.target.files.length; i++){
                if (event.target.files[i].size > MAX_FILE_SIZE) {
                    this.showToast('Error!', 'error', 'File size exceeded the upload size limit.');
                    return;
                }
                let file = event.target.files[i];
                let reader = new FileReader();
                reader.onload = e => {
                    var fileContents = reader.result.split(',')[1]
                    this.filesData.push({'fileName':file.name, 'fileContent':fileContents});
                };
                reader.readAsDataURL(file);
            }
        }
    }
 
    uploadFiles() {
       
    }
 
    removeReceiptImage(event) {
        var index = event.currentTarget.dataset.id;
        this.filesData.splice(index, 1);
    }
 
    showToast(title, variant, message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                variant: variant,
                message: message,
            })
        );
    }

    value = 'In Progress';

    get options() {
        return [
            { label: 'HR Case', value: 'HR Case' }
        ];
    }
   
}