import { LightningElement,track, api, wire } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import IncidentResult_Field from '@salesforce/schema/Case.Incident_result_in_loss_of_life__c';
import IncidentCategory_Field from '@salesforce/schema/Case.Incident_Category__c';
import TypeOfConcern_Field from '@salesforce/schema/Case.Type_of_concern__c';
import TypeOfIllness_Field from '@salesforce/schema/Case.Type_of_Illness__c';
import TypeOfMedicalTreatment_Field from '@salesforce/schema/Case.Type_of_Medical_Treatment_Provided__c';

export default class IncidentDetailsChildPage extends LightningElement {
    @api caseObj = {};
    @track caseObjData = {};
    @track incidentresultOptions = [];
    @track incidentcategoryOptions = [];
    @track caseIncidentRecordTypeId;
    @track fatalityDate = false;
    @track typeOfConcernOptions = [];
    @track typeOfConcern = false;
    @track illnessCategory = false;
    @track typeOfIllnessOptions = [];
    @track medicalTreatmentOptions =[];
    @track medicalTreat = false;
    
    @wire(getObjectInfo, {objectApiName: Case_Object})
     objectInfo({data, error}){
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                // console.log(rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Incident Related Case') {
                    this.caseIncidentRecordTypeId = rtis[element].recordTypeId;
                }
            });
        }
     }

     @wire(getPicklistValues,{recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: IncidentResult_Field})
    incidentResultpickValues({ data, error }) {
        if (data) {
            console.log('data-->'+ JSON.stringify(data));
            data.values.forEach(val => {
                this.incidentresultOptions = [...this.incidentresultOptions, { value: val.value, label: val.label }];
            });
            console.log('this.incidentresultOptions--> '+ JSON.stringify(this.incidentresultOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues,{recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: IncidentCategory_Field})
    incidentCategorypickValues({ data, error }) {
        if (data) {
            console.log('data-->'+ JSON.stringify(data));
            data.values.forEach(val => {
                this.incidentcategoryOptions = [...this.incidentcategoryOptions, { value: val.value, label: val.label }];
            });
            console.log('this.incidentcategoryOptions--> '+ JSON.stringify(this.incidentcategoryOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues,{recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfConcern_Field})
    typeofConcernpickValues({ data, error }) {
        if (data) {
            console.log('data-->'+ JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfConcernOptions = [...this.typeOfConcernOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfConcernOptions--> '+ JSON.stringify(this.typeOfConcernOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues,{recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfIllness_Field})
    typeofIllnesspickValues({ data, error }) {
        if (data) {
            console.log('data-->'+ JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfIllnessOptions = [...this.typeOfIllnessOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfIllnessOptions--> '+ JSON.stringify(this.typeOfIllnessOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues,{recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfMedicalTreatment_Field})
    typeofIllnesspickValues({ data, error }) {
        if (data) {
            console.log('data-->'+ JSON.stringify(data));
            data.values.forEach(val => {
                this.medicalTreatmentOptions = [...this.medicalTreatmentOptions, { value: val.value, label: val.label }];
            });
            console.log('this.medicalTreatmentOptions--> '+ JSON.stringify(this.medicalTreatmentOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    
    
    connectedCallback(){
        console.log('Enter Callback--> '+ JSON.stringify(this.caseObj));
    }

    handleChange(event){
        this.caseObjData[event.target.name] = event.target.value;
        console.log('this.caseObj--> '+ JSON.stringify(this.caseObjData));

        if(event.target.name == 'Incident_result_in_loss_of_life__c'){
            if(event.target.value == 'Yes'){
                this.fatalityDate = true;
            }
            else{
                this.fatalityDate = false;
            }
        }
        else if(event.target.name == 'Incident_Category__c'){
            if(event.target.value == 'Near Miss'){
                this.typeOfConcern = true;
            }
            else{
                this.typeOfConcern = false;
            }

            if(event.target.value == 'Illness'){
                this.illnessCategory = true;
            }
            else{
                this.illnessCategory = false;
            }
        }
        else if(event.target.name == 'Medical_Treatment_Provided__c'){
            if(event.target.value == 'Yes'){
                this.medicalTreat = true;
            }
            else{
                this.medicalTreat = false;
            }
        }
    }

    @api
    handleNext(){
        this.dispatchEvent(new CustomEvent('updatedataa',{detail: this.caseObjData}));  
    }
}