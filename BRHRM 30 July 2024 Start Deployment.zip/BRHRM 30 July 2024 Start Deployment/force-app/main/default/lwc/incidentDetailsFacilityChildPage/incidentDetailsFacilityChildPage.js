import { LightningElement, track, api, wire } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import DAMAGE_Object from '@salesforce/schema/Damage__c';
import TypeOfBuildingDamage_Field from '@salesforce/schema/Damage__c.Type_of_Building_Damage__c';
import FacilityType_Field from '@salesforce/schema/Case.Facility_incident_Type__c';
import TypeOfPropDamage_Field from '@salesforce/schema/Case.Type_of_Property_Damage__c';
import SecurityIssueCate_Field from '@salesforce/schema/Case.Type_of_Security_Issue__c';
import TypeOfBuildingDam_Field from '@salesforce/schema/Case.Type_of_Building_Damage__c';
import VehicleDetails_Field from '@salesforce/schema/Case.Vehicle_Details__c';
import VehicleType_Field from '@salesforce/schema/Case.Vehicle_Type__c';
import Weather_Field from '@salesforce/schema/Case.Weather__c';
import Pavement_Field from '@salesforce/schema/Case.Pavement__c';
import Condition_Field from '@salesforce/schema/Case.Conditions__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
import { loadStyle } from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/Colors'
const actions = [
    { label: 'View', name: 'view' },
    { label: 'Edit', name: 'edit' },
];
export default class IncidentDetailsFacilityChildPage extends LightningElement {

    @api caseObj = {};
    @track typeOfDamageBuildingList = [];
    @track caseIncidentRecordTypeId;
    @track facilityTypeoptions = [];
    @track typeOfPropDamageOptions = [];
    @track securityIssueCateOptions = [];
    @track typeOfbuildingDamageOptions = [];
    @track VehicleDetailsOptions = [];
    @track vehicleTypeOptions = [];
    @track weatherOptions = [];
    @track pavementOptions = [];
    @track conditionOptions = [];
    @track damageList = [];
    showDataTable = false;
    isCssLoaded = false;
    damageCheck = true;
    @api damageInformation = [];

    @track pavementCheck = false;
    @track conditionCheck = false;
    @track otherWeatherCheck = false;
    @track facilityTypeSecu = false;
    @track facilityTypeProp = false;
    @track incidentTypeSelect = false;
    @track properTypeBuilding = false;
    @track properTypeVehicle = false;
    @track vehicleAccident = false;
    @track emergencyServiceCalled = false;
    @track yesNoOptions = [
        { label: 'Yes', value: 'Yes' },
        { label: 'No', value: 'No' }
    ];
    showField;
    isLoaded = true;
    @api recordTypeName;
    @api currentPage;
    showDamageSection;
    openDamageModal = false;
    @track damageObj = {};
    weatherValue;
    pavementValue;
    conditionValue;
    otherWeatherValue;
    otherPavementValue;
    otherConditionValue;

    @track columnsList = [{
        label: "Damage Type", fieldName: "Type_of_Building_Damage__c", cellAttributes: {
            class: { fieldName: 'accountColor' }, alignment: 'center'
        }
    },
    {
        label: "Damage Description", fieldName: "Description_of_Damage__c", cellAttributes: {
            class: { fieldName: 'amountColor' },
            iconName: { fieldName: 'iconName' }, iconPosition: 'right', alignment: 'center'
        }
    },
    {
        label: "Action Taken", fieldName: "Action_Taken__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    {
        label: 'Action',
        type: 'button-icon',
        typeAttributes: {
            iconName: 'action:delete',
            title: 'Delete',
            variant: 'border-filled',
            rowActions: actions,
            alternativeText: 'Delete'
        },
        cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    }
    ];

    connectedCallback() {
        let obj = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj;

        if(this.caseObj.Other_Weather__c){
            this.otherWeatherCheck = true;
        }
        if(this.caseObj.Other_Pavement__c){
            this.pavementCheck = true;
        }
        if(this.caseObj.Other_Conditions__c){
            this.conditionCheck = true;
        }

        let dmg = JSON.parse(JSON.stringify(this.damageInformation));
        this.damageList = dmg;
        let counter = 1;
        this.damageList.forEach(el => {
            el.rowId = counter;
            counter++;
        })

        if (this.damageList.length > 0) {
            this.showDataTable = true
        } else {
            this.showDataTable = false;
        }
        if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
            if (this.caseObj.Police_Report_filed__c == 'Yes') {
                this.showField = true;
            } else {
                this.showField = false;
            }
        }

        if (this.caseObj.hasOwnProperty('Facility_incident_Type__c')) {
            if (obj.Facility_incident_Type__c == 'Security issue') {
                this.facilityTypeProp = false;
                this.facilityTypeSecu = true;
                this.incidentTypeSelect = true;
                this.properTypeBuilding = false;
                this.properTypeVehicle = false;
                this.vehicleAccident = false;             

            } else if (obj.Facility_incident_Type__c == 'Property Damage') {
                this.facilityTypeProp = true;
                this.facilityTypeSecu = false;
                this.incidentTypeSelect = true                
            }
        }


        if (this.caseObj.hasOwnProperty('Type_of_Property_Damage__c')) {
            if (this.caseObj.Type_of_Property_Damage__c == 'Building') {
                this.properTypeBuilding = true;
                this.properTypeVehicle = false;
                this.vehicleAccident = false;
                this.showDamageSection = true;                
            }
            else if (this.caseObj.Type_of_Property_Damage__c == 'Vehicle') {
                this.properTypeBuilding = false;
                this.properTypeVehicle = true;
                this.showDamageSection = false;
            }
            else {
                this.properTypeBuilding = false;
                this.properTypeVehicle = false;
            }
        }

        if (this.caseObj.hasOwnProperty('Accident__c')) {
            if (this.caseObj.Accident__c == 'Yes') {
                this.vehicleAccident = true;
            }
            else {
                this.vehicleAccident = false;
            }
        } else {
            this.vehicleAccident = false;
        }

        if (this.caseObj.hasOwnProperty('Emergency_Services_called__c')) {
            if (this.caseObj.Emergency_Services_called__c == 'Yes') {
                this.emergencyServiceCalled = true;
            }
            else {
                this.emergencyServiceCalled = false;
            }
        } else {
            this.emergencyServiceCalled = false;
        }
        console.log('this.caseObj faciliity connected' , JSON.stringify(this.caseObj))
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(() => {
            console.log("Loaded Successfully")
        }).catch(error => {
            console.error("Error in loading the colors")
        })
    }

    @wire(getObjectInfo, { objectApiName: DAMAGE_Object })
    objectInfoDamage;

    @wire(getPicklistValues, { recordTypeId: "$objectInfoDamage.data.defaultRecordTypeId", fieldApiName: TypeOfBuildingDamage_Field })
    relationtoBakerRipleyPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfDamageBuildingList = [...this.typeOfDamageBuildingList, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfDamageBuildingList--> ' + JSON.stringify(this.typeOfDamageBuildingList));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    @wire(getObjectInfo, { objectApiName: Case_Object })
    objectInfo({ data, error }) {
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                // console.log(rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Incident Related Case') {
                    this.caseIncidentRecordTypeId = rtis[element].recordTypeId;
                }
            });
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: FacilityType_Field })
    facilityTypePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.facilityTypeoptions = [...this.facilityTypeoptions, { value: val.value, label: val.label }];
            });
            console.log('this.facilityTypeoptions--> ' + JSON.stringify(this.facilityTypeoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfPropDamage_Field })
    typeOfPropDamagePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfPropDamageOptions = [...this.typeOfPropDamageOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfPropDamageOptions--> ' + JSON.stringify(this.typeOfPropDamageOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: SecurityIssueCate_Field })
    securityIssueCatePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.securityIssueCateOptions = [...this.securityIssueCateOptions, { value: val.value, label: val.label }];
            });
            console.log('this.securityIssueCateOptions--> ' + JSON.stringify(this.securityIssueCateOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfBuildingDam_Field })
    typeOfBuildingDamPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfbuildingDamageOptions = [...this.typeOfbuildingDamageOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfbuildingDamageOptions--> ' + JSON.stringify(this.typeOfbuildingDamageOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: VehicleDetails_Field })
    vehicleDetailsPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.VehicleDetailsOptions = [...this.VehicleDetailsOptions, { value: val.value, label: val.label }];
            });
            console.log('this.VehicleDetailsOptions--> ' + JSON.stringify(this.VehicleDetailsOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: VehicleType_Field })
    vehicleTypePickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.vehicleTypeOptions = [...this.vehicleTypeOptions, { value: val.value, label: val.label }];
            });
            console.log('this.vehicleTypeOptions--> ' + JSON.stringify(this.vehicleTypeOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: Weather_Field })
    weatherPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.weatherOptions = [...this.weatherOptions, { value: val.value, label: val.label }];
            });
            console.log('this.weatherOptions--> ' + JSON.stringify(this.weatherOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: Pavement_Field })
    pavementPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.pavementOptions = [...this.pavementOptions, { value: val.value, label: val.label }];
            });
            console.log('this.pavementOptions--> ' + JSON.stringify(this.pavementOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: Condition_Field })
    conditionPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.conditionOptions = [...this.conditionOptions, { value: val.value, label: val.label }];
            });
            console.log('this.conditionOptions--> ' + JSON.stringify(this.conditionOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    handleChange(event) {
        console.log('event.target.type', event.target.type);

        if (event.target.name == 'Type_of_Building_Damage__c' || event.target.name == 'Description_of_Damage__c' || event.target.name == 'Action_Taken__c') {
            this.damageObj[event.target.name] = event.target.value;
            console.log('this.damageObj--> ' + JSON.stringify(this.damageObj));
        } else {
            if (event.target.type == 'checkbox') {
                this.caseObj[event.target.name] = event.target.checked;
                console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));
            } else {
                this.caseObj[event.target.name] = event.target.value;
                console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));
            }
        }

        if(event.target.name == 'Weather__c') {
            this.weatherValue = event.target.value
        } else if(event.target.name == 'Pavement__c') {
            this.pavementValue = event.target.value
        } else if(event.target.name == 'Conditions__c') {
            this.conditionValue = event.target.value
        } else if(event.target.name == 'Other_Weather__c') {
            this.otherWeatherValue = event.target.value
        } else if(event.target.name == 'Other_Pavement__c') {
            this.otherPavementValue = event.target.value
        } else if(event.target.name == 'Other_Conditions__c') {
            this.otherConditionValue = event.target.value
        }

        if (event.target.name == 'Police_Report_filed__c') {
            if (event.target.value == 'Yes') {
                this.showField = true;
            } else {
                this.showField = false;
                this.caseObj.Date_reported_to_employer__c = '';
                if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                    delete this.caseObj.Report_Number__c;
                }
                if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                    delete this.caseObj.Officer_Name__c;
                }
                if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                    delete this.caseObj.Badge_Number__c;
                }

            }
        }


        if (this.caseObj.Facility_incident_Type__c == 'Property Damage') {
            this.incidentTypeSelect = true;
            this.facilityTypeProp = true;
            this.facilityTypeSecu = false;
        }
        else if (this.caseObj.Facility_incident_Type__c == 'Security issue') {
            this.incidentTypeSelect = true;
            this.facilityTypeProp = false;
            this.facilityTypeSecu = true;
            this.properTypeBuilding = false;
            this.properTypeVehicle = false;
            this.vehicleAccident = false;
            this.showDamageSection = false;
            this.damageList = [];
            this.showDataTable = false;

            this.caseObj.Vehicle_Details__c = null;
            this.caseObj.Vehicle_Type__c = null;
            this.caseObj.VIN_Number__c = null;
            this.caseObj.Make__c = null;
            this.caseObj.Model__c = null;
            this.caseObj.Year__c = null;
            this.caseObj.License_Plate_Number__c = null;
            this.caseObj.Weather__c = null;
            this.caseObj.Conditions__c = null;
            this.caseObj.Pavement__c = null;
            if (this.caseObj.hasOwnProperty('Type_of_Property_Damage__c')) {
                delete this.caseObj.Type_of_Property_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Accident__c')) {
                delete this.caseObj.Accident__c;
            }
        }

        if (this.caseObj.Type_of_Property_Damage__c == 'Building') {
            console.log('In');
            this.properTypeBuilding = true;
            this.properTypeVehicle = false;
            this.vehicleAccident = false;
            this.showDamageSection = true;
            if (this.caseObj.hasOwnProperty('Accident__c')) {
                delete this.caseObj.Accident__c;
            }
            if (this.caseObj.hasOwnProperty('Air_Bag_Deployed__c')) {
                delete this.caseObj.Air_Bag_Deployed__c;
            }
            if (this.caseObj.hasOwnProperty('Seat_Belt_Used__c')) {
                delete this.caseObj.Seat_Belt_Used__c;
            }
            if (this.caseObj.hasOwnProperty('Weather__c')) {
                delete this.caseObj.Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Weather__c')) {
                delete this.caseObj.Other_Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Pavement__c')) {
                delete this.caseObj.Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Pavement__c')) {
                delete this.caseObj.Other_Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Conditions__c')) {
                delete this.caseObj.Conditions__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Conditions__c')) {
                delete this.caseObj.Other_Conditions__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Details__c')) {
                delete this.caseObj.Vehicle_Details__c;
            }
            if (this.caseObj.hasOwnProperty('Make__c')) {
                delete this.caseObj.Make__c;
            }
            if (this.caseObj.hasOwnProperty('License_Plate_Number__c')) {
                delete this.caseObj.License_Plate_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Type__c')) {
                delete this.caseObj.Vehicle_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Model__c')) {
                delete this.caseObj.Model__c;
            }
            if (this.caseObj.hasOwnProperty('VIN_Number__c')) {
                delete this.caseObj.VIN_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Year__c')) {
                delete this.caseObj.Year__c;
            }
        }
        else if (this.caseObj.Type_of_Property_Damage__c == 'Vehicle') {
            this.properTypeBuilding = false;
            this.properTypeVehicle = true;
            this.showDamageSection = false;
            this.damageList = [];
            this.showDataTable = false;
        }
        else {
            console.log('in herre----> else-->')
            this.properTypeBuilding = false;
            this.properTypeVehicle = false;
            this.caseObj.Weather__c = null;
            this.caseObj.Conditions__c = null;
            this.caseObj.Pavement__c = null;
        }

        if (this.caseObj.Accident__c == 'Yes') {
            this.vehicleAccident = true;
        }
        else {
            this.vehicleAccident = false;
            this.caseObj.Weather__c = null;
            this.caseObj.Conditions__c = null;
            this.caseObj.Pavement__c = null;
            if (this.caseObj.hasOwnProperty('Air_Bag_Deployed__c')) {
                delete this.caseObj.Air_Bag_Deployed__c;
            }
            if (this.caseObj.hasOwnProperty('Seat_Belt_Used__c')) {
                delete this.caseObj.Seat_Belt_Used__c;
            }
        }

        if (this.caseObj.Emergency_Services_called__c == 'Yes') {
            this.emergencyServiceCalled = true;
        }
        else {
            this.emergencyServiceCalled = false;
            if (this.caseObj.hasOwnProperty('Police__c')) {
                delete this.caseObj.Police__c;
            }
            if (this.caseObj.hasOwnProperty('Fire__c')) {
                delete this.caseObj.Fire__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance__c')) {
                delete this.caseObj.Ambulance__c;
            }
        }

        if(this.caseObj.Weather__c == 'Other'){
            this.otherWeatherCheck = true;
        }else{
            this.otherWeatherCheck = false;
            this.caseObj.Weather__c = null;
        }

        if(this.caseObj.Conditions__c == 'Other'){
            this.conditionCheck = true;
        }else{
            this.conditionCheck = false;
            this.caseObj.Conditions__c = null;
        }

        if(this.caseObj.Pavement__c == 'Other'){
            this.pavementCheck = true;
        }else{
            this.pavementCheck = false;
            this.caseObj.Pavement__c = null;
        }

        console.log('vehicleAccident',this.vehicleAccident);
    }

    isNullOrUndefined(value) {
        return value === undefined || value === null;
    }

    @api
    handleNext() {
        console.log('weather in next-----> ' , this.caseObj.Weather__c)
        if(!this.isNullOrUndefined(this.weatherValue)) {
            this.caseObj.Weather__c = this.weatherValue 
        }
        if(!this.isNullOrUndefined(this.pavementValue)) {
            this.caseObj.Pavement__c = this.pavementValue 
        }
        if(!this.isNullOrUndefined(this.conditionValue)) {
            this.caseObj.Conditions__c = this.conditionValue 
        }
        if(!this.isNullOrUndefined(this.otherWeatherValue)) {
            this.caseObj.Other_Weather__c = this.otherWeatherValue 
        }
        if(!this.isNullOrUndefined(this.otherPavementValue)) {
            this.caseObj.Other_Pavement__c = this.otherPavementValue 
        }
        if(!this.isNullOrUndefined(this.otherConditionValue)) {
            this.caseObj.Other_Conditions__c = this.otherConditionValue 
        }
        let isValid = true;
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if (this.caseObj.Emergency_Services_called__c == 'Yes') {
            if (!this.caseObj.hasOwnProperty('Police__c') && !this.caseObj.hasOwnProperty('Fire__c') && !this.caseObj.hasOwnProperty('Ambulance__c')) {
            //if ((this.caseObj.Police__c && this.caseObj.Police__c != 'undefined') || (this.caseObj.Fire__c && this.caseObj.Fire__c != 'undefined') || (this.caseObj.Ambulance__c && this.caseObj.Ambulance__c != 'undefined')) {
                isValid = false;
            }
        }

        if(this.caseObj.Facility_incident_Type__c == 'Property Damage' && this.caseObj.Type_of_Property_Damage__c == 'Building' && this.damageList.length == 0){
            this.demageCheck = false;
        }else{
            this.demageCheck = true;
        }

        if (allValid && allCBValid && isValid && this.demageCheck) {
            console.log('@on next save this.caseoBj-----> data----> ' , JSON.stringify(this.caseObj))
            this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.caseObj }));
            this.dispatchEvent(new CustomEvent('updatedamagedata', { detail: this.damageList }));
        } else {
            if(!this.demageCheck){
                this.displayMessage("Add Damage!", "error", "Please add at least one damage record to proceed");                
            }else{
                this.displayMessage("Please check your entries.", "error", "Please fill required fields");
            }
        }
    }

    @api handlePrevious() {
        console.log('@previous this.caseoBj-----> data----> ' , JSON.stringify(this.caseObj))
        this.dispatchEvent(new CustomEvent('previousclick', { detail: this.caseObj }));
        this.dispatchEvent(new CustomEvent('updatedamagedata', { detail: this.damageList }));
    }

    displayMessage(title, variant, msg) {
        const toastEvent = new ShowToastEvent({
            title: title,
            message: msg,
            variant: variant,
        });
        this.dispatchEvent(toastEvent);
    }

    @api
    handleSaveAndExit() {
        if(!this.isNullOrUndefined(this.weatherValue)) {
            this.caseObj.Weather__c = this.weatherValue 
        }
        if(!this.isNullOrUndefined(this.pavementValue)) {
            this.caseObj.Pavement__c = this.pavementValue 
        }
        if(!this.isNullOrUndefined(this.conditionValue)) {
            this.caseObj.Conditions__c = this.conditionValue 
        }
        if(!this.isNullOrUndefined(this.otherWeatherValue)) {
            this.caseObj.Other_Weather__c = this.otherWeatherValue 
        }
        if(!this.isNullOrUndefined(this.otherPavementValue)) {
            this.caseObj.Other_Pavement__c = this.otherPavementValue 
        }
        if(!this.isNullOrUndefined(this.otherConditionValue)) {
            this.caseObj.Other_Conditions__c = this.otherConditionValue 
        }
        let isValid = true;
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if (this.caseObj.Emergency_Services_called__c == 'Yes') {
            if (!this.caseObj.hasOwnProperty('Police__c') && !this.caseObj.hasOwnProperty('Fire__c') && !this.caseObj.hasOwnProperty('Ambulance__c')) {
                isValid = false;
            }
        }
        if(this.caseObj.Facility_incident_Type__c == 'Property Damage' && this.caseObj.Type_of_Property_Damage__c == 'Building' && this.damageList.length == 0){
            this.damageCheck = false;
        }else{
            this.damageCheck = true;
        }
        if (allValid && allCBValid && isValid && this.damageCheck) {
            this.isLoaded = false;
            this.caseObj.Status = 'Draft';
            this.caseObj.CurrentPage__c = this.currentPage;
            let damageData = JSON.parse(JSON.stringify(this.damageList));
            damageData.forEach(Obj => {
                if (Obj.hasOwnProperty('rowId')) {
                    delete Obj.rowId;
                }
                console.log('obj->' + JSON.stringify(Obj));
            });
            console.log('damageData->' + JSON.stringify(damageData));
            createCaseOnSubmit({
                caseObj: this.caseObj,
                fileData: [],
                incidentUserList: [],
                recordTypeName: this.recordTypeName,
                injuryData: [],
                damageData: damageData,
                courseInformation: []
            })
                .then(result => {
                    console.log('result', result);
                    if (result) {
                        this.isLoaded = true;
                        console.log('--92--> ' + result);
                        this.displayMessage("Success", "success", "Case saved as draft.");
                        this.dispatchEvent(new CustomEvent('saveexit'));
                    } else {
                        this.isLoaded = true;
                    }
                }).catch(error => {
                    this.displayMessage("Error", "error", reduceErrors(error).toString());
                    this.isLoaded = true;
                })
        } else {
            if(!this.demageCheck){
                this.displayMessage("Add Damage!", "error", "Please add at least one damage record to proceed");                
            }else{
                this.displayMessage("Please check your entries.", "error", "Please fill required fields");
            }        
            }

    }

    handleDamageProperties() {
        this.openDamageModal = true;
    }

    handleCancel() {
        this.openDamageModal = false;
    }

    handleSave() {
        let allValid = true;
        allValid = [...this.template.querySelectorAll('.isValid')].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if (allValid) {
            let obj = JSON.parse(JSON.stringify(this.damageObj));
            this.damageList = [...this.damageList, obj];
            console.log('number:::', this.damageList.length);
            if (this.damageList.length > 0) {
                let counter = 1;
                this.damageList.forEach(el => {
                    el.rowId = counter;
                    counter++;
                })
                this.showDataTable = true;
            }
            console.log('this.damageList', JSON.stringify(this.damageList));
            this.openDamageModal = false;
            this.damageObj = {};
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }
    }

    handleRowAction(event) {
        this.damageList = this.damageList?.filter(data => data.rowId !== event.detail.row.rowId);
        const row = event.detail.row.rowId;
        if (this.damageList.length < 1) {
            this.showDataTable = false;
        }
        console.log('selected row:: ' + row);
        console.log('this.damageList', JSON.stringify(this.damageList));
    }
}