import { LightningElement } from 'lwc';

export default class CreateEmployeeChangeRequest extends LightningElement
{
    isModalOpen = false;

    openModal() {
        this.isModalOpen = true;
        console.log('inside',this.isModalOpen);
    }
    closeModal() {
        this.isModalOpen = false;
    }
}