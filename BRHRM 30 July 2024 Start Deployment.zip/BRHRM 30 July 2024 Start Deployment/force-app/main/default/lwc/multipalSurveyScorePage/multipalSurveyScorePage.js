import { LightningElement, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import surveyList from '@salesforce/apex/multiSurveyScoreController.surveyList';
import getScore from '@salesforce/apex/SurveyScoreController.getScore';

//Score Card Table
const scoreCardColumns = [
    { label: 'Category', fieldName: 'category' },
    { label: 'Total Score', fieldName: 'TotalScore' },
    { label: 'Survey Score', fieldName: 'SurveyScore' },
    { label: 'Prefer not to answer', fieldName: 'notAnswered' },
];

//Survey Table
const columns = [
    { label: 'Survey Taker Number', fieldName: 'Name' },
    { label: 'Total Score', fieldName: 'Total_Score__c' },
    { label: 'Prefer not to answer', fieldName: 'Survey_not_answered__c' },
    { label: 'Preview', fieldName: 'id', type: 'button-icon', typeAttributes: { iconName: 'utility:preview', name: 'Preview',},cellAttributes: { alignment: 'left' },}
    ];
export default class MultipalSurveyScorePage extends LightningElement {
    //Survey score card variables
    scoreCardData = [];
    scoreCardColumns = scoreCardColumns;
    @track isModalOpen = false;

    //Survey table variables 
    data = [];
    columns = columns;
    connectedCallback() {
        surveyList()
                .then(res=>
                {  console.log('Previous survey -->',  JSON.stringify(res));
                    this.data = res; 
                })
                .catch(error=>
                {
                    this.displayMessage('Error Occured','error',error.body.message)

                });
    
    }

    handleRowAction( event ) {
        this.isModalOpen = true;
        console.log('selectedRows ..'+event.detail.row.Id);

            getScore({surveyTKId: event.detail.row.Id})
            .then(res=>
            {  console.log('Score card --> ', JSON.stringify(res));
                this.scoreCardData = res; 
            })
            .catch(error=>
            {
                console.log('Previous survey -->',  JSON.stringify(res));
                this.displayMessage('Error Occured','error', error.body.message)
            });
    }

    displayMessage(title, type, message) {
            this.dispatchEvent(new ShowToastEvent({
                title: title,
                message: message,
                variant: type,
                mode: 'dismissable'
            }));
        }

    closeModal() {
        this.isModalOpen = false;
    }

}