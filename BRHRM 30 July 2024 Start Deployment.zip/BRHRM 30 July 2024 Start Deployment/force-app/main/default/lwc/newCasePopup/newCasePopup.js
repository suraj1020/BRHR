import { LightningElement, track, api } from 'lwc';

export default class ModalPopupLWC extends LightningElement {
    @api content;
    @api showModal = false;

    handleButtonClick(){
        this.showModal = true;
    }

    hideModalBox() {  
        this.showModal = false;

        const pEvent = new CustomEvent('close',{
            detail:{
                showModal: false
            }
        });
        this.dispatchEvent(pEvent);
    }
}