import { LightningElement,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createGoal from '@salesforce/apex/AddGoalController.createGoal';
export default class AddGoal extends LightningElement {   
    @api goalType;
    name;
    type;
    @api kpiWeightage;
    @api kpiRecordId;
    @api prfid;
    weightage;
    additionalgoals;
    selectedStartDate;
    selectedEndDate;
    measureofsuccess;
    managerComment;
    get typeOptions() {
        return [
            { label: 'Formal Goal', value: 'Formal Goal' },
            { label: 'Additional Goal', value: 'Additional Goal' },
        ];
    }

    @api goalModalOpen;
    handleValueSelectedOnEmployee(event) {
        const selectedId = event.detail.id ? event.detail.id : event.target.value;
        this.trainingId = selectedId;
    }
    
    handleSubmit(){        
        var prf = {};
        prf.Name = this.name;
        prf.KPIs__c = this.kpiRecordId;
        console.log(' -- this.type'+this.type);
        prf.Type__c = this.type;
        prf.Weightage__c = this.weightage;
        prf.Description__c =this.additionalgoals;
        prf.Start_Date__c = this.selectedStartDate;
        prf.End_Date__c = this.selectedEndDate;
        prf.Success_Measurement__c = this.measureofsuccess;
        prf.Manager_Comment__c = this.managerComment;
        prf.Status__c = 'Not Started';
        console.log(typeof this.name+' -- '+typeof this.selectedStartDate+' -- '+this.selectedEndDate+' -- '+typeof this.weightage);
        const totalWeightage = parseInt(this.kpiWeightage) + parseInt(this.weightage, 10);  
        console.log('goal details -- '+totalWeightage+' -- '+ this.kpiWeightage+' -- '+this.weightage +this.name+' -- '+this.selectedStartDate+' -- '+this.selectedEndDate+' -- '+this.weightage);


        if (this.name === undefined || this.selectedStartDate === undefined || this.selectedEndDate === undefined || this.weightage === undefined || this.selectedStartDate === null || this.selectedEndDate === null || this.measureofsuccess == undefined || this.additionalgoals == undefined) {
            this.displayMessage('Error!','error','Required fields missing.');
        }else if(this.weightage !== undefined && totalWeightage > 100){
            console.log('totalWeightage -- '+totalWeightage+ ' -- '+this.weightage);
            this.displayMessage('Error!','error','All goal weightage of a KPI or Competency should not be greater then 100%.');
        }else if(this.selectedStartDate > this.selectedEndDate) {
            this.displayMessage('Error!','error','Start Date can not be after end date.');
        }else{
             this.goalModalOpen = false;
             console.log('Create goal called'+this.goalType);
            createGoal({prf:JSON.stringify(prf), performanceReviewId: this.prfid, goalType: this.goalType})
            .then(result => {
                    console.log(result);
                     console.log('Create goal ........');
                    if(result == 'Success'){
                        console.log('Create goal created successfully');
                        this.displayMessage('Success!!','success','Goal is created.'); 
                    this.dispatchEvent(new CustomEvent('showmodaloff', {
                        detail: this.goalModalOpen
                    }));
                    }
                    else {
                        console.log('Create goal Error');
                        this.displayMessage('Error!!','error',result);                
                    }
                }
            )
            .catch(error => {});
        }
    }

    displayMessage(title, type, message) {
            this.dispatchEvent(new ShowToastEvent({
                title: title,
                message: message,
                variant: type,
                mode: 'dismissable'
            }));
        }

    handleName(event) {
        this.name = event.target.value;
    }
    handleWeightage(event){
        this.weightage = event.target.value;
    }
    handleAdditionalgoals(event) {
        this.additionalgoals = event.target.value;
    }
    handleType(event){
        this.type = event.detail.value;
    }
    handleMeasureOfSuccess(event){
        this.measureofsuccess = event.target.value;
    }
    handleManagerComments(event){
        this.managerComment = event.target.value;
    }
    handleStartDateChange(event) {
        this.selectedStartDate = event.target.value;
    }
    handleEndDateChange(event) {
        this.selectedEndDate = event.target.value;
    }
    closeModal() {
        this.goalModalOpen = false;

        this.dispatchEvent(new CustomEvent('showmodaloff', {
            detail: this.goalModalOpen
        }));
    }
    handleCancelClick(){
        this.goalModalOpen = false;

        this.dispatchEvent(new CustomEvent('showmodaloff', {
            detail: this.goalModalOpen
        }));
    }
}