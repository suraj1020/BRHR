import { LightningElement,api } from 'lwc';
import createSurvey from '@salesforce/apex/TrainingController.createSurvey';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class FeedBackFormEnrollmentTraining extends LightningElement {
    expectationsrating;
    instructorrating;
    knowledgerating;
    interactiverating;
    oraganizedrating;
    qualityrating;
    feedbackComment;
    @api emptid;
    @api emplearningpath;
    rating(event) {
        if (event.target.name === "Expectations") {
            this.expectationsrating = event.target.value;
        }
        if (event.target.name === "Instructor") {
            this.instructorrating = event.target.value;
        }
        if (event.target.name === "Knowledge") {
            this.knowledgerating = event.target.value;
        }
        if (event.target.name === "Interactive") {
            this.interactiverating = event.target.value;
        }
        if (event.target.name === "Oraganized") {
            this.oraganizedrating = event.target.value;
        }
        if (event.target.name === "Quality") {
            this.qualityrating = event.target.value;
        }
    }
    handleCommentChange(event){
        this.feedbackComment = event.target.value;
    }
    getvalues(){
        /*if(this.trainingrating == undefined || this.feedbackComment ==undefined){
            this.displayMessage('Value Missing','error','Plese select the rating and add your comments.')
        }
        else{*/
            createSurvey({
                            expectationsrating:this.expectationsrating,
                            qualityrating:this.qualityrating,
                            oraganizedrating:this.oraganizedrating,
                            interactiverating:this.interactiverating,
                            knowledgerating:this.knowledgerating,
                            instructorrating:this.instructorrating,
                            comment: this.feedbackComment,
                            empTId :this.emptid,
                            emplearningpath :this.emplearningpath})
            .then(res=>
                {  console.log(res);
                    if(res=='Success'){
                    this.displayMessage('Feedback Created!!','success','Feedback is succesfully submited.')
                    this.dispatchEvent(new CustomEvent('close'));}
                    else{
                        this.displayMessage('Error Occured','error',res)
                    }
                })
                .catch(error=>
                    {
                        this.displayMessage('Error Occured','error',reduceErrors(error).toString())

                    });
    
            //}

        
    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }
}