import { LightningElement, api,track } from 'lwc';
import userId from "@salesforce/user/Id";
import managerCommentCheck from '@salesforce/apex/PerformanceImprovementPlanController.managerCommentCheck';
import savePIPComment from '@salesforce/apex/PerformanceImprovementPlanController.savePIPComment';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class PerformanceImprovementPlanView extends LightningElement {
    @api recordId; 
    pip;
    employeeName;
    dDate;
    Reasonfortheplan;
    Performanceexpectationsaftertheplan;
    Specificactionstoimprove;
    Metricsusedtomeasureimprovement;
    Nextreviewdates;
    Consequencesifthegoalisorisnotachieved;
    Signatureofmanagerandemployee;
    @track ManagerComment;
    showManagerComment = false; 
    editMode = false; 

    connectedCallback() {
        console.log(this.recordId);
        managerCommentCheck({ pIPId: this.recordId })
            .then((result) => {
                this.pip = result;
                this.employeeName = this.pip.Employee_Name__r.Name;
                this.dDate = this.pip.Date__c;
                this.Reasonfortheplan = this.pip.Reason_for_the_plan__c;
                this.Performanceexpectationsaftertheplan = this.pip.Performance_expectations_after_the_plan__c;
                this.Specificactionstoimprove = this.pip.Specific_actions_to_improve__c;
                this.Metricsusedtomeasureimprovement = this.pip.Metrics_used_to_measure_improvement__c;
                this.Nextreviewdates = this.pip.Next_review_dates__c;
                this.Consequencesifthegoalisorisnotachieved = this.pip.Consequences_if_the_goal_is_or_is_not_ac__c;
                this.Signatureofmanagerandemployee = this.pip.Signature_of_manager_and_employee__c;
                this.ManagerComment = this.pip.Manager_s_Comment__c.replace(/<\/?p>/g, '');
                if(this.pip.Employee_Name__r.User.ManagerId == userId){
                    this.showManagerComment = true;
                }
                console.log(this.showManagerComment);
            })
            .catch((error) => {
                console.error(error);
            });
    }

    saveComment(){
        console.log(this.ManagerComment);
        savePIPComment({ pIPId: this.recordId,comment : this.ManagerComment })
            .then((result) => {
                if(result == 'SUCCESS'){
                    this.editMode = false;
                    const evt = new ShowToastEvent({
                    title: 'Success!!',
                    message: 'PIP updated sucessfully.',
                    variant: 'success',
                    mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                }
                else{
                    const evt = new ShowToastEvent({
                    title: 'Error',
                    message: result,
                    variant: 'error',
                    mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                }
            })
            .catch((error) => {
                console.error(error);
            });
    }

    handleCommentChange(event){
        this.ManagerComment = event.target.value;
    }

    editComment(){
        this.editMode = true;
    }
}