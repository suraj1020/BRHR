import { LightningElement, track, api, wire } from 'lwc';
import { loadStyle } from 'lightning/platformResourceLoader';
import COLORS from '@salesforce/resourceUrl/Colors';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createInjury from '@salesforce/apex/AdditionalyInjuryController.createInjuryRecord';
import deleteInjuryRecord from '@salesforce/apex/AdditionalyInjuryController.deleteInjuryRecord';
import getInjuryRecord from '@salesforce/apex/AdditionalyInjuryController.getInjuryRecord';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import IncidentResult_Field from '@salesforce/schema/Case.Incident_result_in_loss_of_life__c';
import FIRST_DAY_AT_WORK from '@salesforce/schema/Case.What_duties_the_employee_able_to_perform__c';
import EMPLOYEE_PAY_STATUS from '@salesforce/schema/Case.Employee_s_pay_status__c';
import INJURED_PEOPLE_RETURN_TO_WORK from '@salesforce/schema/Case.Employee_returned_to_work__c';
import INCIDENT_ABSENT_WORK from '@salesforce/schema/Case.Did_incident_result_in_absence_from_work__c';
import IncidentCategory_Field from '@salesforce/schema/Case.Incident_Category__c';
import TypeOfConcern_Field from '@salesforce/schema/Case.Type_of_concern__c';
import TypeOfIllness_Field from '@salesforce/schema/Case.Type_of_Illness__c';
import TypeOfMedicalTreatment_Field from '@salesforce/schema/Case.Type_of_Medical_Treatment_Provided__c';
import DeclinedMedicalTreatment_Field from '@salesforce/schema/Case.Was_Medical_Treatment_Declined__c';
import WasfirstAidProvided_Field from '@salesforce/schema/Case.Was_first_Aid_Provided__c';
import TypeOfInjury_Field from '@salesforce/schema/Case.Type_Of_Injury__c';
import CauseOfInjury_Field from '@salesforce/schema/Case.Cause_of_injury__c';
import Injury_OBJECT from "@salesforce/schema/Injury__c";
import Injured_Body_Area from '@salesforce/schema/Injury__c.Injured_Body_Area__c';
import Injured_Body_Part from '@salesforce/schema/Injury__c.Injured_Body_Part__c';
import Injured_Body_Location from '@salesforce/schema/Injury__c.Injured_Body_Location__c';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
export default class IncidentDetailsEmployeeChildPage extends LightningElement {
    showLocation = true;
    @api caseObj = {};
    //@track caseObjData = {};
    @track incidentresultOptions = [];
    @track employeePayStatus = [];
    @track firstDayAtWorks = [];
    @track incidentWorkOptions = [];
    @track injuredPeopleWork = [];
    @track incidentcategoryOptions = [];
    @track caseIncidentRecordTypeId;
    @track fatalityDate = false;
    @track typeOfConcernOptions = [];
    @track typeOfConcern = false;
    @track illnessCategory = false;
    @track typeOfIllnessOptions = [];
    @track medicalTreatmentOptions = [];
    @track medicalDeclineOptions = [];
    @track firstAidOptions = [];
    @track typeOfInjuryOptions = [];
    @track CauseOfInjuryOptions = [];
    @track medicalTreat = false;
    @track injuryCategory = false;
    isLoaded = true;
    @track injuredBodyPartData;
    @track injuredBodyLocationData;
    showYesIncidentResultFields = false;
    isShowF = false;
    showIncidentRelatedFields = false;
    injuryCheck = true;
    emailRegex = "/^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/";
    //-----------Additionali injury -----------------------------//
    @track columnsList = [{
        label: "Body Area", fieldName: "Injured_Body_Area__c", cellAttributes: {
            class: { fieldName: 'accountColor' }, alignment: 'center',
        }
    },
    {
        label: "Body Part", fieldName: "Injured_Body_Part__c", cellAttributes: {
            class: { fieldName: 'amountColor' },
            iconName: { fieldName: 'iconName' }, iconPosition: 'right', alignment: 'center'
        }
    },
    {
        label: "Body Location", fieldName: "Injured_Body_Location__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    {
        label: 'Action',
        type: 'button-icon',
        typeAttributes: {
            iconName: 'action:delete',
            title: 'Delete',
            variant: 'border-filled',
            alternativeText: 'Delete'
        }, cellAttributes: { alignment: 'center' }
    }
    ];
    additionalyInjuryModal = false;
    @track showDataTable = false;
    injuredBodyAreaValue = '';
    injuredBodyPartValue = '';
    injuredBodyLocatonValue = '';
    @track injuredBodyAreaPicklist = [];
    @track injuredBodyPartPicklist = [];
    @track injuredBodyLocationPicklist = [];
    injuryNameValue = '';
    @api injuryRecordList = [];
    @track injuryWiredData = [];
    isCssLoaded = false;
    showInjuredBodyPart;
    showInjuredBodyLocation;
    isTrue = false;
    showemployeeReturnedFields = false;
    showPayAmount = false;
    @api recordTypeName;
    @api currentPage;
    isShowMedicalDeclined = false

    additionInjuryModalPopup(event) {
        this.additionalyInjuryModal = true;
    }
    closeModal(event) {
        this.additionalyInjuryModal = false;
        this.injuredBodyAreaValue = '';
        this.injuredBodyPartValue = '';
        this.injuredBodyLocatonValue = '';
    }

    // @wire(getInjuryRecord, {})
    // injuryRecords({ data, error }) {
    //     this.injuryWiredData = data;
    //     if (data) {
    //         console.log('injury records -->' + JSON.stringify(data));
    //         this.injuryRecordList = data;
    //         if (data.length > 0) {
    //             this.showDataTable = true;
    //             console.log('No of injury ---' + data.length);
    //         }
    //     } else {
    //         console.log(' injury fetch record error --> ' + JSON.stringify(error));
    //     }
    // }

    // fetchInjuryRecords() {
    //     this.isLoaded = false;
    //     getInjuryRecord({})
    //         .then(result => {
    //             console.log(result);
    //             if (result) {
    //                 this.injuryRecordList = result;
    //                 if (this.injuryRecordList.length > 0) {
    //                     this.showDataTable = true;
    //                 }
    //                 console.log('injury records -->' + JSON.stringify(this.injuryRecordList));
    //                 this.isLoaded = true;
    //             } else {
    //                 this.isLoaded = true;
    //             }
    //         }
    //         )
    //         .catch(error => {
    //             this.isLoaded = true;
    //         });
    // }

    @wire(getObjectInfo, { objectApiName: Injury_OBJECT })
    objectInfoData;

    @wire(getPicklistValues, { recordTypeId: "$objectInfoData.data.defaultRecordTypeId", fieldApiName: Injured_Body_Area })
    injuredBodyArea({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.injuredBodyAreaPicklist = [...this.injuredBodyAreaPicklist, { value: val.value, label: val.label }];
            });
            console.log('this.injuredBodyAreaPicklist--> ' + JSON.stringify(this.injuredBodyAreaPicklist));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: "$objectInfoData.data.defaultRecordTypeId", fieldApiName: Injured_Body_Part })
    injuredBodyPart({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            this.injuredBodyPartData = data;
            // data.values.forEach(val => {
            //     this.injuredBodyPartPicklist = [...this.injuredBodyPartPicklist, { value: val.value, label: val.label }];
            // });
            // console.log('this.injuredBodyPartPicklist--> ' + JSON.stringify(this.injuredBodyPartPicklist));
            // console.log('this.injuredBodyPartPicklistOriginal--> ' + JSON.stringify(this.injuredBodyPartPicklistOriginal));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: "$objectInfoData.data.defaultRecordTypeId", fieldApiName: Injured_Body_Location })
    injuredBodyALocation({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            this.injuredBodyLocationData = data;
            // data.values.forEach(val => {
            //     this.injuredBodyLocationPicklist = [...this.injuredBodyLocationPicklist, { value: val.value, label: val.label }];
            // });
            // console.log('this.injuredBodyLocationPicklist--> ' + JSON.stringify(this.injuredBodyLocationPicklist));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }
    handleInjuredBodyArea(event) {
        this.injuredBodyAreaValue = event.target.value;
        if (event.target.value == 'UNCLASSIFIED') {
            this.showLocation = false;
        }else {
            this.showLocation = true;
        }
        this.injuredBodyPartPicklist = [];
        this.injuredBodyLocationPicklist = [];
        this.showInjuredBodyPart = true;
        let key = this.injuredBodyPartData.controllerValues[event.target.value];
        let injBodyPartData = [];
        injBodyPartData = this.injuredBodyPartData.values.filter(opt => opt.validFor.includes(key));
        console.log('injBodyPartData', JSON.stringify(injBodyPartData));
        if (injBodyPartData.length > 0) {
            injBodyPartData.forEach(val => {
                this.injuredBodyPartPicklist = [...this.injuredBodyPartPicklist, { value: val.value, label: val.label }];
            });
        }

        this.showInjuredBodyLocation = true;
        let key1 = this.injuredBodyLocationData.controllerValues[event.target.value];
        let injBodyLocationData = [];
        injBodyLocationData = this.injuredBodyLocationData.values.filter(opt => opt.validFor.includes(key1));
        console.log('injBodyLocationData', JSON.stringify(injBodyLocationData));
        if (injBodyLocationData.length > 0) {
            injBodyLocationData.forEach(val => {
                this.injuredBodyLocationPicklist = [...this.injuredBodyLocationPicklist, { value: val.value, label: val.label }];
            });
        }


    }
    handleInjuredBodyPart(event) {
        this.injuredBodyPartValue = event.target.value;
        console.log('this.injuredBodyPartValue -- ' + this.injuredBodyPartValue);
    }
    handleInjuredBodyLocation(event) {
        this.injuredBodyLocatonValue = event.target.value;
    }
    handleInjuryName(event) {
        this.injuryNameValue = event.target.value;
    }

    createInjuryRecord(event) {
        if (this.injuredBodyAreaValue != 'UNCLASSIFIED') {
            if (this.injuredBodyAreaValue != '' && this.injuredBodyPartValue != '' && this.injuredBodyLocatonValue != '') {
                this.additionalyInjuryModal = false;
                let injuryRecord = {};
                console.log(' injury --> ' + this.injuredBodyAreaValue.toLowerCase() + ' -- ' + this.injuredBodyPartValue + ' -- ' + this.injuredBodyLocatonValue + ' -- ' + this.injuryNameValue);
                let string = this.injuredBodyAreaValue
                injuryRecord.Injured_Body_Area__c = string[0].toUpperCase() + string.slice(1)
                injuryRecord.Injured_Body_Part__c = this.injuredBodyPartValue;
                injuryRecord.Injured_Body_Location__c = this.injuredBodyLocatonValue;
                injuryRecord.Name = this.injuryNameValue;
                if (this.injuryRecordList.length > 0) {
                    console.log('In')
                    this.injuryRecordList = [...this.injuryRecordList, injuryRecord];
                } else {
                    console.log('Out')
                    this.injuryRecordList = [...new Array(injuryRecord)];
                }
                this.showDataTable = true;
                let counter = 1;
                this.injuryRecordList.forEach(el => {
                    el.Injured_Body_Area__c = el.Injured_Body_Area__c[0].toUpperCase() + el.Injured_Body_Area__c.slice(1)
                    el.rowIndex = counter;
                    counter++;
                })
                this.injuredBodyAreaValue = '';
                this.injuredBodyPartValue = '';
                this.injuredBodyLocatonValue = '';
                this.showInjuredBodyPart = false;
                this.showInjuredBodyLocation = false;
                console.log('this.injuryRecordList after creating', JSON.stringify(this.injuryRecordList));
            } else {
                this.displayMessage("Please check your entries.", "error", "Please fill required fields");
            }
        }else {
            if (this.injuredBodyAreaValue != '' && this.injuredBodyPartValue != '') {
                this.additionalyInjuryModal = false;
                let injuryRecord = {};
                console.log(' injury --> ' + this.injuredBodyAreaValue + ' -- ' + this.injuredBodyPartValue + ' -- ' + this.injuredBodyLocatonValue + ' -- ' + this.injuryNameValue);
                let string = this.injuredBodyAreaValue
                injuryRecord.Injured_Body_Area__c = string[0].toUpperCase() + string.slice(1)
                injuryRecord.Injured_Body_Part__c = this.injuredBodyPartValue;
                injuryRecord.Injured_Body_Location__c = this.injuredBodyLocatonValue;
                injuryRecord.Name = this.injuryNameValue;
                if (this.injuryRecordList.length > 0) {
                    console.log('In')
                    this.injuryRecordList = [...this.injuryRecordList, injuryRecord];
                } else {
                    console.log('Out')
                    this.injuryRecordList = [...new Array(injuryRecord)];
                }
                this.showDataTable = true;
                let counter = 1;
                this.injuryRecordList.forEach(el => {
                    el.Injured_Body_Area__c = el.Injured_Body_Area__c[0].toUpperCase() + el.Injured_Body_Area__c.slice(1)
                    el.rowIndex = counter;
                    counter++;
                })
                this.injuredBodyAreaValue = '';
                this.injuredBodyPartValue = '';
                this.injuredBodyLocatonValue = '';
                this.showInjuredBodyPart = false;
                this.showInjuredBodyLocation = false;
                console.log('this.injuryRecordList after creating', JSON.stringify(this.injuryRecordList));
            }
        }
    }

    deleteInjuryRecord(event) {
        const selectedRows = event.detail.row;
        console.log('selectedRows -- ' + JSON.stringify(selectedRows));
        if (this.injuryRecordList.length > 0) {
            this.injuryRecordList = this.injuryRecordList.filter(el => el.rowIndex != selectedRows.rowIndex);
            if (this.injuryRecordList.length == 0) {
                this.injuryRecordList = [];
                this.showDataTable = false;
            } else {
                console.log('this.injuryRecordList after deleting', JSON.stringify(this.injuryRecordList));
            }
        } else {
            this.injuryRecordList = [];
            this.showDataTable = false;
        }
    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }
    //END-----------Additionali injury -----------------------------//


    @wire(getObjectInfo, { objectApiName: Case_Object })
    objectInfo({ data, error }) {
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                // console.log(rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Incident Related Case') {
                    this.caseIncidentRecordTypeId = rtis[element].recordTypeId;
                }
            });
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: EMPLOYEE_PAY_STATUS })
    employePayStatus({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.employeePayStatus = [...this.employeePayStatus, { value: val.value, label: val.label }];
            });
            console.log('this.employeePayStatus--> ' + JSON.stringify(this.employeePayStatus));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: FIRST_DAY_AT_WORK })
    firstDayAtWork({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.firstDayAtWorks = [...this.firstDayAtWorks, { value: val.value, label: val.label }];
            });
            console.log('this.firstDayAtWorks--> ' + JSON.stringify(this.firstDayAtWorks));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: INJURED_PEOPLE_RETURN_TO_WORK })
    injuredPeopleReturnToWork({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.injuredPeopleWork = [...this.injuredPeopleWork, { value: val.value, label: val.label }];
            });
            console.log('this.injuredPeopleWork--> ' + JSON.stringify(this.injuredPeopleWork));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: IncidentResult_Field })
    incidentResultpickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.incidentresultOptions = [...this.incidentresultOptions, { value: val.value, label: val.label }];
            });
            console.log('this.incidentresultOptions--> ' + JSON.stringify(this.incidentresultOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: INCIDENT_ABSENT_WORK })
    incidentWorkpickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.incidentWorkOptions = [...this.incidentWorkOptions, { value: val.value, label: val.label }];
            });
            console.log('this.incidentWorkOptions--> ' + JSON.stringify(this.incidentWorkOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: IncidentCategory_Field })
    incidentCategorypickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.incidentcategoryOptions = [...this.incidentcategoryOptions, { value: val.value, label: val.label }];
            });
            console.log('this.incidentcategoryOptions--> ' + JSON.stringify(this.incidentcategoryOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfConcern_Field })
    typeofConcernpickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfConcernOptions = [...this.typeOfConcernOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfConcernOptions--> ' + JSON.stringify(this.typeOfConcernOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfIllness_Field })
    typeofIllnesspickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfIllnessOptions = [...this.typeOfIllnessOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfIllnessOptions--> ' + JSON.stringify(this.typeOfIllnessOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfMedicalTreatment_Field })
    typeofMedicalTreatpickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.medicalTreatmentOptions = [...this.medicalTreatmentOptions, { value: val.value, label: val.label }];
            });
            console.log('this.medicalTreatmentOptions--> ' + JSON.stringify(this.medicalTreatmentOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: DeclinedMedicalTreatment_Field })
    declinedMedicalTreatpickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.medicalDeclineOptions = [...this.medicalDeclineOptions, { value: val.value, label: val.label }];
            });
            console.log('this.medicalDeclineOptions--> ' + JSON.stringify(this.medicalDeclineOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: WasfirstAidProvided_Field })
    firstAidTreatpickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.firstAidOptions = [...this.firstAidOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }
    

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: TypeOfInjury_Field })
    typeofInjurypickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfInjuryOptions = [...this.typeOfInjuryOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfInjuryOptions--> ' + JSON.stringify(this.typeOfInjuryOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: CauseOfInjury_Field })
    CauseofInjurypickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.CauseOfInjuryOptions = [...this.CauseOfInjuryOptions, { value: val.value, label: val.label }];
            });
            console.log('this.CauseOfInjuryOptions--> ' + JSON.stringify(this.CauseOfInjuryOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }




    connectedCallback() {
        //this.fetchInjuryRecords();
        console.log('Enter Callback--> ' + JSON.stringify(this.caseObj));
        let obj = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj;
        if(this.caseObj.Medical_Treatment_Provided__c == 'No') {
            this.isShowMedicalDeclined = true
        }
        let obj1 = JSON.parse(JSON.stringify(this.injuryRecordList));
        this.injuryRecordList = obj1;

        if (this.injuryRecordList.length > 0) {
            let counter = 1;
            this.injuryRecordList.forEach(el => {
                el.rowIndex = counter;
                counter++;
            })
            this.showDataTable = true;
        }

        if (this.caseObj.hasOwnProperty('Employee_s_pay_status__c')) {
            this.showPayAmount = true;
        } else {
            this.showPayAmount = false;
        }
        if (this.caseObj.hasOwnProperty('Incident_result_in_loss_of_life__c')) {
            this.isTrue = true;
            if (this.caseObj.Incident_result_in_loss_of_life__c == 'Yes') {
                this.fatalityDate = true;
                this.showIncidentRelatedFields = false;
                this.isShowF = false;
            } else {
                this.fatalityDate = false;
            }
        } else {
            this.fatalityDate = false;
        }

        if (this.caseObj.hasOwnProperty('Did_incident_result_in_absence_from_work__c')) {
            this.showIncidentRelatedFields = true;
            if (this.caseObj.Did_incident_result_in_absence_from_work__c == 'Yes') {
                this.showYesIncidentResultFields = true;
            }
            else {
                this.showYesIncidentResultFields = false;
                this.isShowF = false;
            }
        } else {
            this.showYesIncidentResultFields = false;
            this.isShowF = false;
        }

        if (this.caseObj.hasOwnProperty('Employee_returned_to_work__c')) {
            this.isShowF = true;
            if (this.caseObj.Employee_returned_to_work__c == 'Yes') {
                this.showemployeeReturnedFields = true;
            }
            else {
                this.showemployeeReturnedFields = false;
            }
        } else {
            this.showemployeeReturnedFields = false;
        }

        if (this.caseObj.hasOwnProperty('Incident_Category__c')) {
            if (this.caseObj.Incident_Category__c == 'Near Miss') {
                this.typeOfConcern = true;
            } else {
                this.typeOfConcern = false;
            }

            if (this.caseObj.Incident_Category__c == 'Illness') {
                this.illnessCategory = true;
            } else {
                this.illnessCategory = false;
            }

            if (this.caseObj.Incident_Category__c == 'Injury') {
                this.injuryCategory = true;
            } else {
                this.injuryCategory = false;
            }
        } else {
            this.typeOfConcern = false;
            this.illnessCategory = false;
            this.injuryCategory = false;
        }

        if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
            if (this.caseObj.Medical_Treatment_Provided__c == 'Yes') {
                this.medicalTreat = true;
            } else {
                this.medicalTreat = false;
            }
        } else {
            this.medicalTreat = false;
        }

        console.log('this.injuryCategory', this.injuryCategory)
        console.log('this.caseObj.X911_Called__c ', this.caseObj.X911_Called__c)
        console.log('this.caseObj.Ambulance_Called__c ', this.caseObj.Ambulance_Called__c)
        console.log('this.caseObj.Medical_Treatment_Provided__c ', this.caseObj.Medical_Treatment_Provided__c)


        if (this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(() => {
            console.log("Loaded Successfully")
        }).catch(error => {
            console.error("Error in loading the colors")
        })
    }

    handleChange(event) {
        this.caseObj[event.target.name] = event.target.value;
        console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));

        if (event.target.name == 'Employee_s_pay_status__c') {
            this.showPayAmount = true;
        }

        if (event.target.name == 'Employee_returned_to_work__c') {
            this.isShowF = true;
            if (event.target.value == 'Yes') {
                this.showemployeeReturnedFields = true;
                if (this.caseObj.hasOwnProperty('Anticipated_return_to_work_date__c')) {
                    delete this.caseObj.Anticipated_return_to_work_date__c;
                }
            }
            else {
                this.showemployeeReturnedFields = false;
                if (this.caseObj.hasOwnProperty('First_full_day_back_to_work__c')) {
                    delete this.caseObj.First_full_day_back_to_work__c;
                }
                if (this.caseObj.hasOwnProperty('Pay_amount_hourly_hide__c')) {
                    delete this.caseObj.Pay_amount_hourly_hide__c;
                }
                if (this.caseObj.hasOwnProperty('Employee_s_pay_status__c')) {
                    delete this.caseObj.Employee_s_pay_status__c;
                }
                if (this.caseObj.hasOwnProperty('What_duties_the_employee_able_to_perform__c')) {
                    delete this.caseObj.What_duties_the_employee_able_to_perform__c;
                }
            }
        }

        if (event.target.name == 'Did_incident_result_in_absence_from_work__c') {
            this.showIncidentRelatedFields = true;
            if (event.target.value == 'Yes') {
                this.showYesIncidentResultFields = true;
            }
            else {
                this.showYesIncidentResultFields = false;
                this.isShowF = false;
                if (this.caseObj.hasOwnProperty('Date_returned_to_work__c')) {
                    delete this.caseObj.Date_returned_to_work__c;
                }
                if (this.caseObj.hasOwnProperty('Employee_returned_to_work__c')) {
                    delete this.caseObj.Employee_returned_to_work__c;
                }
                if (this.caseObj.hasOwnProperty('First_full_day_back_to_work__c')) {
                    delete this.caseObj.First_full_day_back_to_work__c;
                }
                if (this.caseObj.hasOwnProperty('Anticipated_return_to_work_date__c')) {
                    delete this.caseObj.Anticipated_return_to_work_date__c;
                }
                if (this.caseObj.hasOwnProperty('Pay_amount_hourly_hide__c')) {
                    delete this.caseObj.Pay_amount_hourly_hide__c;
                }
                if (this.caseObj.hasOwnProperty('Employee_s_pay_status__c')) {
                    delete this.caseObj.Employee_s_pay_status__c;
                }
                if (this.caseObj.hasOwnProperty('What_duties_the_employee_able_to_perform__c')) {
                    delete this.caseObj.What_duties_the_employee_able_to_perform__c;
                }
            }
        }

        if (event.target.name == 'Incident_result_in_loss_of_life__c') {
            this.isTrue = true;
            if (event.target.value == 'Yes') {
                this.fatalityDate = true;
                this.showIncidentRelatedFields = false;
                this.isShowF = false;
                if (this.caseObj.hasOwnProperty('Did_incident_result_in_absence_from_work__c')) {
                    delete this.caseObj.Did_incident_result_in_absence_from_work__c;
                }
                if (this.caseObj.hasOwnProperty('Date_returned_to_work__c')) {
                    delete this.caseObj.Date_returned_to_work__c;
                }
                if (this.caseObj.hasOwnProperty('Employee_returned_to_work__c')) {
                    delete this.caseObj.Employee_returned_to_work__c;
                }
                if (this.caseObj.hasOwnProperty('First_full_day_back_to_work__c')) {
                    delete this.caseObj.First_full_day_back_to_work__c;
                }
                if (this.caseObj.hasOwnProperty('Anticipated_return_to_work_date__c')) {
                    delete this.caseObj.Anticipated_return_to_work_date__c;
                }
                if (this.caseObj.hasOwnProperty('Pay_amount_hourly_hide__c')) {
                    delete this.caseObj.Pay_amount_hourly_hide__c;
                }
                if (this.caseObj.hasOwnProperty('Employee_s_pay_status__c')) {
                    delete this.caseObj.Employee_s_pay_status__c;
                }
                if (this.caseObj.hasOwnProperty('What_duties_the_employee_able_to_perform__c')) {
                    delete this.caseObj.What_duties_the_employee_able_to_perform__c;
                }
            }
            else {
                this.fatalityDate = false;
                if (this.caseObj.hasOwnProperty('Date_of_fatality__c')) {
                    delete this.caseObj.Date_of_fatality__c;
                }
            }
        }
        else if (event.target.name == 'Incident_Category__c') {
            if (event.target.value == 'Near Miss') {
                this.medicalTreat = false;
                this.typeOfConcern = true;
                this.injuryRecordList = [];
                this.showDataTable = false;
                if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
                    delete this.caseObj.Medical_Treatment_Provided__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Name__c')) {
                    delete this.caseObj.Provider_Name__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Phone__c')) {
                    delete this.caseObj.Provider_Phone__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Email__c')) {
                    delete this.caseObj.Provider_Email__c;
                }
                if (this.caseObj.hasOwnProperty('Type_of_Medical_Treatment_Provided__c')) {
                    delete this.caseObj.Type_of_Medical_Treatment_Provided__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Address__c')) {
                    delete this.caseObj.Provider_Address__c;
                }
            }
            else {
                this.typeOfConcern = false;
                if (this.caseObj.hasOwnProperty('Type_of_concern__c')) {
                    delete this.caseObj.Type_of_concern__c;
                }
            }

            if (event.target.value == 'Illness') {
                this.medicalTreat = false;
                this.illnessCategory = true;
                this.injuryRecordList = [];
                this.showDataTable = false;
                if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
                    delete this.caseObj.Medical_Treatment_Provided__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Name__c')) {
                    delete this.caseObj.Provider_Name__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Phone__c')) {
                    delete this.caseObj.Provider_Phone__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Email__c')) {
                    delete this.caseObj.Provider_Email__c;
                }
                if (this.caseObj.hasOwnProperty('Type_of_Medical_Treatment_Provided__c')) {
                    delete this.caseObj.Type_of_Medical_Treatment_Provided__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Address__c')) {
                    delete this.caseObj.Provider_Address__c;
                }
            }
            else {
                this.illnessCategory = false;
                if (this.caseObj.hasOwnProperty('Type_of_Illness__c')) {
                    delete this.caseObj.Type_of_Illness__c;
                }
                if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
                    this.medicalTreat = false;
                    delete this.caseObj.Medical_Treatment_Provided__c;
                }
            }

            if (event.target.value == 'Injury') {
                this.injuryCategory = true;
            }
            else {
                this.injuryCategory = false;
                if (this.caseObj.hasOwnProperty('Cause_of_injury__c')) {
                    delete this.caseObj.Cause_of_injury__c;
                }
                if (this.caseObj.hasOwnProperty('Type_Of_Injury__c')) {
                    delete this.caseObj.Type_Of_Injury__c;
                }
                if (this.caseObj.hasOwnProperty('X911_Called__c')) {
                    delete this.caseObj.X911_Called__c;
                }
                if (this.caseObj.hasOwnProperty('Ambulance_Called__c')) {
                    delete this.caseObj.Ambulance_Called__c;
                }
                if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
                    delete this.caseObj.Medical_Treatment_Provided__c;
                    this.medicalTreat = false;
                }
            }
        }
        else if (event.target.name == 'Medical_Treatment_Provided__c') {
            if (event.target.value == 'Yes') {
                this.medicalTreat = true;
                this.isShowMedicalDeclined = false
            }
            else {
                this.medicalTreat = false;
                this.isShowMedicalDeclined = true
                if (this.caseObj.hasOwnProperty('Provider_Name__c')) {
                    delete this.caseObj.Provider_Name__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Phone__c')) {
                    delete this.caseObj.Provider_Phone__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Email__c')) {
                    delete this.caseObj.Provider_Email__c;
                }
                if (this.caseObj.hasOwnProperty('Type_of_Medical_Treatment_Provided__c')) {
                    delete this.caseObj.Type_of_Medical_Treatment_Provided__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Address__c')) {
                    delete this.caseObj.Provider_Address__c;
                }
            }
        }
        else if (event.target.name == 'Was_Medical_Treatment_Declined__c') {
            if (event.target.value == 'Yes') {
                this.medicalTreatDenied = true;
            }
            else {
                this.medicalTreatDenied = false;
                if (this.caseObj.hasOwnProperty('Provider_Name__c')) {
                    delete this.caseObj.Provider_Name__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Phone__c')) {
                    delete this.caseObj.Provider_Phone__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Email__c')) {
                    delete this.caseObj.Provider_Email__c;
                }
                if (this.caseObj.hasOwnProperty('Type_of_Medical_Treatment_Provided__c')) {
                    delete this.caseObj.Type_of_Medical_Treatment_Provided__c;
                }
                if (this.caseObj.hasOwnProperty('Provider_Address__c')) {
                    delete this.caseObj.Provider_Address__c;
                }
            }
        }
    }

    @api
    handleNext() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDLValid = [...this.template.querySelectorAll("lightning-textarea")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        
        if(this.caseObj.Incident_Category__c == 'Injury' && this.injuryRecordList.length == 0){
            this.injuryCheck = false;
        }else{
            this.injuryCheck = true;
        }

        console.log('check--- '+typeof this.injuryRecordList+' : '+this.injuryCheck+' : '+this.caseObj.Incident_Category__c+ ' : '+this.injuryRecordList.length);
        if(this.caseObj.Medical_Treatment_Provided__c == 'Yes') {
            if(this.validateEmail(this.caseObj.Provider_Email__c)) {
                if (allValid && allCBValid && allDLValid && this.injuryCheck) {
                    this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.caseObj }));
                    this.dispatchEvent(new CustomEvent('updateinjurydata', { detail: this.injuryRecordList }));
                } else {
                    if(!this.injuryCheck){
                        this.displayMessage("Add Injury!", "error", "Please add at least one injury record to proceed");                
                    }else{
                        this.displayMessage("Please check your entries.", "error", "Please fill required fields");
                    }
                }
            } else {
                this.displayMessage("Add Email!", "error", "Please add email in correct format. ex: abc@example.com")
            }
        } else {
            if (allValid && allCBValid && allDLValid && this.injuryCheck) {
                this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.caseObj }));
                this.dispatchEvent(new CustomEvent('updateinjurydata', { detail: this.injuryRecordList }));
            } else {
                if(!this.injuryCheck){
                    this.displayMessage("Add Injury!", "error", "Please add at least one injury record to proceed");                
                }else{
                    this.displayMessage("Please check your entries.", "error", "Please fill required fields");
                }
            }
        }
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    @api handlePrevious() {
        this.dispatchEvent(new CustomEvent('previousclick', { detail: this.caseObj }));
        this.dispatchEvent(new CustomEvent('updateinjurydata', { detail: this.injuryRecordList }));
    }

    @api
    handleSaveAndExit() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDLValid = [...this.template.querySelectorAll("lightning-textarea")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if(this.caseObj.Incident_Category__c == 'Injury' && this.injuryRecordList.length == 0){
            this.injuryCheck = false;
        }else{
            this.injuryCheck = true;
        }

        if(this.validateEmail(this.caseObj.Provider_Email__c)) {
            if (allValid && allCBValid && allDLValid && this.injuryCheck) {
                this.isLoaded = false;
                this.caseObj.Status = 'Draft';
                this.caseObj.CurrentPage__c = this.currentPage;
                let injuryDataList = JSON.parse(JSON.stringify(this.injuryRecordList));
                injuryDataList.forEach(Obj => {
                    if (Obj.hasOwnProperty('rowIndex')) {
                        delete Obj.rowIndex;
                    }
                    console.log('obj->' + JSON.stringify(Obj));
                });
                createCaseOnSubmit({
                    caseObj: this.caseObj,
                    fileData: [],
                    incidentUserList: [],
                    recordTypeName: this.recordTypeName,
                    injuryData: injuryDataList,
                    damageData: [],
                    courseInformation: []
                })
                    .then(result => {
                        if (result) {
                            this.isLoaded = true;
                            console.log('--92--> ' + result);
                            this.displayMessage("Success", "success", "Case saved as draft.");
                            this.dispatchEvent(new CustomEvent('saveexit'));
                        } else {
                            this.isLoaded = true;
                        }
                    }).catch(error => {
                        this.displayMessage("Error", "error", reduceErrors(error).toString());
                        this.isLoaded = true;
                    })
            } else {
                if(!this.injuryCheck){
                    this.displayMessage("Add Injury!", "error", "Please add at least one injury record to proceed");                
                }else{
                    this.displayMessage("Please check your entries.", "error", "Please fill required fields");
                }
            }
        } else {
            this.displayMessage("Add Email!", "error", "Please add email in correct format. ex: abc@example.com")
        }
    }
}