import { LightningElement,api } from 'lwc';
export default class AdditionalGoalsPRF extends LightningElement {
    @api employeeReadOnly;
    @api showManagerComments;
    @api managerReadOnly;
}