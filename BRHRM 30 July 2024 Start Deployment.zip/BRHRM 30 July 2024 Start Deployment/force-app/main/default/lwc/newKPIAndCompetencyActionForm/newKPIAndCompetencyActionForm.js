import { LightningElement, track, api, wire } from 'lwc'
import { ShowToastEvent } from "lightning/platformShowToastEvent"
import { getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import { getObjectInfo , getPicklistValues } from 'lightning/uiObjectInfoApi'
import KPI_OBJECT from '@salesforce/schema/KPIs__c'
import insertKPICompetencyForm from '@salesforce/apex/NewKPIAndCompetencyActionFormController.insertKPICompetencyForm';
import updateKPICompetencyForm from '@salesforce/apex/NewKPIAndCompetencyActionFormController.updateKPICompetencyForm';

export default class NewKPIAndCompetencyActionForm extends LightningElement {
    isLoading = false
    @track kpiCompObject = {"SObjectType" : "KPIs__c"}
    @api kpiCompObjectEdit = {}
    @api isShowRecordTypeKPI = false
    @api isShowNewKPIModal = false
    @api isShowEditKPIModal = false
    kpiRecordTypeId
    competencyRecordTypeId
    popUpHeadingToShow = ''
    @track employeeRatingPicklist = []
    @track managerRatingPicklist = []
    editButtonName
    showField = false
    statusValue = 'Pending'
    @track tempVariable = []
    @api viewAsManager = false

    get options() {
        return [
            { label: 'KPI', value: 'KPI' },
            { label: 'Competency', value: 'Competency' },
        ];
    }

    get statusOptions() {
        return [
            { label: 'Pending', value: 'Pending' },
            { label: 'Approved', value: 'Approved' },
            { label: 'Rejected', value: 'Rejected' },
        ];
    }

    @wire(getObjectInfo, { objectApiName: KPI_OBJECT })
    getRecTypeIds({error,data}) {
       if(data) {
        let objArray  = data.recordTypeInfos
        for (let i in objArray) {
            if(objArray[i].name =="KPI") {
                this.kpiRecordTypeId = objArray[i].recordTypeId
                console.log("----this.kpiRecordTypeId :" + this.kpiRecordTypeId)
            }

            if(objArray[i].name == "Competency") {
                this.competencyRecordTypeId = objArray[i].recordTypeId
                console.log("----this.competencyRecordTypeId :" + this.competencyRecordTypeId)
            }
        }
        } else if(error) {
            console.log("error : " + JSON.stringify(error))
        }
    }

    @wire(getPicklistValuesByRecordType, { objectApiName: KPI_OBJECT, recordTypeId:  '$kpiRecordTypeId'})
    kpiPicklistValues({error, data}) {
    	if(data) {
            this.employeeRatingPicklist = []
            this.managerRatingPicklist = []

            console.log("--------data in KPI"  + JSON.stringify(data))
            let employeeRatingValue = data.picklistFieldValues.Employee_Rating__c.values
            for (let i = 0; i < employeeRatingValue.length; i++) {
                this.employeeRatingPicklist.push({
                    label: employeeRatingValue[i].label,
                    value: employeeRatingValue[i].value
                })
            }

            let managerRatingValue = data.picklistFieldValues.Manager_Rating__c.values
            for (let i = 0; i < managerRatingValue.length; i++) {
                this.managerRatingPicklist.push({
                    label: managerRatingValue[i].label,
                    value: managerRatingValue[i].value
                })
            }
            this.showField = true
        } else if(error) {
        	console.log("----Error : " + JSON.stringify(error))
        }
    }

    @wire(getPicklistValuesByRecordType, { objectApiName: KPI_OBJECT, recordTypeId:  '$competencyRecordTypeId'})
    competencyPicklistValues({error, data}) {
    	if(data) {
            this.employeeRatingPicklist = []
            this.managerRatingPicklist = []

            console.log("--------data in Competency"  + JSON.stringify(data))
            let employeeRatingValue = data.picklistFieldValues.Employee_Rating__c.values
            for (let i = 0; i < employeeRatingValue.length; i++) {
                this.employeeRatingPicklist.push({
                    label: employeeRatingValue[i].label,
                    value: employeeRatingValue[i].value
                })
            }

            let managerRatingValue = data.picklistFieldValues.Manager_Rating__c.values
            for (let i = 0; i < managerRatingValue.length; i++) {
                this.managerRatingPicklist.push({
                    label: managerRatingValue[i].label,
                    value: managerRatingValue[i].value
                })
            }

            this.showField = true
        } else if(error) {
        	console.log("----Error : " + JSON.stringify(error))
        }
    }

    connectedCallback() {
        if(this.isShowEditKPIModal) {
            console.log('------kpiCompObjectEdit------> > > ' , JSON.stringify(this.kpiCompObjectEdit))
            this.tempVariable = JSON.parse(JSON.stringify(this.kpiCompObjectEdit))
            this.kpiCompObject = JSON.parse(JSON.stringify(this.tempVariable.kpiData))
            this.kpiCompObject.Name = this.tempVariable.key
        }
    }

    handleInputFocus(event) {
        // modify parent to properly highlight visually
        const classList = event.target.parentNode.classList;
        classList.add('lgc-highlight');
    }

    handleInputBlur(event) {
        // modify parent to properly remove highlight
        const classList = event.target.parentNode.classList;
        classList.remove('lgc-highlight');
    }

    handleChange(event) {
        if(event.target.name == 'SelectRecType') {
            if(event.target.value == 'KPI') {
                this.popUpHeadingToShow = 'KPI'
                this.kpiCompObject.RecordTypeId = this.kpiRecordTypeId;
            } else if(event.target.value == 'Competency') {
                this.popUpHeadingToShow = 'Competency'
                this.kpiCompObject.RecordTypeId = this.competencyRecordTypeId;
            }
        } else if(event.target.value != "KPI" && event.target.value != "Competency") {
            this.kpiCompObject[event.target.name] = event.target.value;
            this.tempVariable.kpiData[event.target.name] = event.target.value;
        }
    }

    handleNext() {
        this.isLoading = true
        if(this.kpiCompObject.RecordTypeId) {
            this.isShowRecordTypeKPI = false
            this.isShowNewKPIModal = true
            this.isLoading = false
        } else {
            const evt = new ShowToastEvent({
                title: "Please select a Record Type!!",
                message: "Select a record-type to proceed further.",
                variant: "error"
            })
            this.dispatchEvent(evt)
            this.isLoading = false
        }
    }

    handleSaveKPIs() {
        this.isLoading = true
        this.kpiCompObject.Performance_Review_Template__c = null
        if(this.kpiCompObject.Name) {
            insertKPICompetencyForm({ objKPIForm : this.kpiCompObject }).then(result=> {
                if(result.isSuccess) {
                    const evt = new ShowToastEvent({
                        title: result.message,
                        message: "Record created successfully and has been sent for approval!!",
                        variant: "success"
                    })
                    this.dispatchEvent(evt)
                    this.isLoading = false
                    this.isShowNewKPIModal = false
                    this.dispatchEvent(new CustomEvent('closepopup', {
                        detail : {
                            closePopUp : this.isShowNewKPIModal
                        }
                    }))
                } else {
                    const evt = new ShowToastEvent({
                        title: "OOPS!!! Something went wrong.",
                        message: result.message,
                        variant: "error"
                    })
                    this.dispatchEvent(evt)
                    this.isLoading = false
                }
            })
        } else {
            const evt = new ShowToastEvent({
                title: "Required Field Missing!!!",
                message: "Please fill all the reuqired fields and try again.",
                variant: "error"
            })
            this.dispatchEvent(evt)
            this.isLoading = false
        }
    }

    handleCancel() {
        this.isShowRecordTypeKPI = false
        this.dispatchEvent(new CustomEvent('closepopup', {
            detail : {
                closePopUp : this.isShowRecordTypeKPI
            }
        }));
    }

    handleUpdateKPIs(event) {
        this.isLoading = true
        this.editButtonName = event.target.title
        if(this.kpiCompObject.Name) {
            updateKPICompetencyForm({ objKPIForm : this.kpiCompObject, buttonName : this.editButtonName }).then(result=> {
                if(result.isSuccess) {
                    let msg;
                    if(this.editButtonName == 'UpdateApprove') {
                        msg = "Record updated successfully and has been sent for approval!!"
                    } else {
                        msg = "Record Updated Successfully!!"
                    }
                    const evt = new ShowToastEvent({
                        title: result.message,
                        message: msg,
                        variant: "success"
                    })
                    this.dispatchEvent(evt)
                    this.isLoading = false
                    this.isShowEditKPIModal = false
                    this.dispatchEvent(new CustomEvent('closepopup', {
                        detail : {
                            closePopUp : this.isShowEditKPIModal,
                            onEditData : this.tempVariable
                        }
                    }))
                } else {
                    const evt = new ShowToastEvent({
                        title: "OOPS!!! Something went wrong.",
                        message: result.message,
                        variant: "error"
                    })
                    this.dispatchEvent(evt)
                    this.isLoading = false
                }
            })
        } else {
            const evt = new ShowToastEvent({
                title: "Required Field Missing!!!",
                message: "Please fill all the reuqired fields and try again.",
                variant: "error"
            })
            this.dispatchEvent(evt)
            this.isLoading = false
        }
    }

    handleEditClose() {
        this.isShowEditKPIModal = false;
        this.dispatchEvent(new CustomEvent('closepopup', {
            detail : {
                closePopUp : this.isShowEditKPIModal,
            }
        }));
    }

    handleNewClose() {
        this.isShowNewKPIModal = false;
        this.dispatchEvent(new CustomEvent('closepopup', {
            detail : {
                closePopUp : this.isShowNewKPIModal
            }
        }));
    }
}