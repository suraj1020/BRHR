import { LightningElement, wire } from 'lwc';
import { getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
export default class CarDetails extends LightningElement {
   carValues;
   carColorValues;
   selectedCarValue = '';
   picklistValuesObj;
   selectedCarColorValue = '';
   // method to get Picklist values based on record type and dependant values too
   @wire(getPicklistValuesByRecordType, { objectApiName: 'Case', recordTypeId: '012DG000000EBlgYAG' })
   newPicklistValues({ error, data }) {
       if (data) {
           this.error = null;
           this.picklistValuesObj = data.picklistFieldValues;
           console.log('data returned' +        JSON.stringify(data.picklistFieldValues));
           let carValueslist = data.picklistFieldValues.Benefit_Type__c.values;
           let carValues = [];
           //Iterate the picklist values for the car name field
           for (let i = 0; i < carValueslist.length; i++) {
               carValues.push({
                   label: carValueslist[i].label,
                   value: carValueslist[i].value
               });
           }
           this.carValues = carValues;
           console.log('data car values' + JSON.stringify(this.carValues));
       }
       else if (error) {
           this.error = JSON.stringify(error);
           console.log(JSON.stringify(error));
       }
   }
   handleCarChange(event) {
       this.selectedCarValue = event.detail.value;
       if (this.selectedCarValue) {
           let data = this.picklistValuesObj; 
           let totalCarColorValues = data.Benefit_Sub_Categories__c;
           //Getting the index of the controlling value as the single value can be dependant on multiple controller value
           let controllerValueIndex = totalCarColorValues.controllerValues[this.selectedCarValue];
           let colorPicklistValues = data.Benefit_Sub_Categories__c.values;
           let carColorPicklists = [];
           //Iterate the picklist values for the car name field
           colorPicklistValues.forEach(key => {
               for (let i = 0; i < key.validFor.length; i++) {
                   if (controllerValueIndex == key.validFor[i]) {
                       carColorPicklists.push({
                           label: key.label,
                           value: key.value
                       });
                   }
               }
           })
           console.log(' data carColorPicklists' + JSON.stringify(carColorPicklists));
           if (carColorPicklists && carColorPicklists.length > 0) {
               this.carColorValues = carColorPicklists;
           }
       }
   }
   handleCarColorChange(event){
       this.selectedCarColorValue = event.detail.value;
   }
}