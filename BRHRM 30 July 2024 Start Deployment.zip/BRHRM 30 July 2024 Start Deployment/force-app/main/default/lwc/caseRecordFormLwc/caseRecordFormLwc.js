import { LightningElement, api, wire, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import Subject_FIELD from '@salesforce/schema/Case.Subject';
import Origin_FIELD from '@salesforce/schema/Case.Origin';
import Reason_FIELD from '@salesforce/schema/Case.Reason';
import Sub_Type_FIELD from '@salesforce/schema/Case.Sub_Type__c';
import Type_FIELD from '@salesforce/schema/Case.Type';
import Incident_Type_FIELD from '@salesforce/schema/Case.Event_Incident_Location__c';
import Type_Of_Injury_FIELD from '@salesforce/schema/Case.Type_Of_Injury__c';
// import INCIDENT_LOCATION_NAME from '@salesfroce/schema/Case.Incident_Location_Name__c';
import { getPicklistValuesByRecordType, getObjectInfo } from 'lightning/uiObjectInfoApi';
import CASE_OBJECT from '@salesforce/schema/Case';
import uploadFiles from '@salesforce/apex/FileUploadMultiController.uploadFiles';
import employeeDetail from '@salesforce/apex/FileUploadMultiController.employeeDetail';
const MAX_FILE_SIZE = 2097152;

export default class CaseRecordFormLwc extends NavigationMixin(LightningElement) {
    @track firstRadioButton = true;
    @track isView = true;
    @track isRadioButtonVisible = true;
    @track isSaveButtonVisible = false;
    @track isPicklistVisible = false;
    @track doubleButtonVisible = false;
    @track singleButtonVisible = true;
    @track isPicklistFieldsVisible = true;
    recordId = '';
    @track filesData = [];
    @track areDetailsVisible = false;
    retemployeeId;
    retemployeeEmail;
    @track progressStep = '1';
    @api recordTypeId;
    @api objectApiName = 'Case';
    @track type_options = [];
    @track sub_type_options;
    @track Incident_Type_options;
    @track Type_Of_Injury_options;
    @track value;

    /***********Boolean variables ******************************Added by Anuj*******/
    incidentType = false;
    NonBakerRipley = false;
    /**************************************************************************** */

    fields = [Type_FIELD, Sub_Type_FIELD, Incident_Type_FIELD, Type_Of_Injury_FIELD];
    requestedForVisible = false;
    connectedCallback() {
        employeeDetail({})
            .then((result) => {
                console.log('result :::>' + JSON.stringify(result));
                this.retemployeeId = result.id;
                this.retemployeeEmail = result.Email;
                console.log('result :::>' + this.retemployeeEmail);
            })
            .catch((error) => {
                console.error(error);
            });
    }
    @wire(getObjectInfo, { objectApiName: CASE_OBJECT })
    objectInfo({ data, error }) {
        if (data) {

            const rtis = data.recordTypeInfos;



            Object.keys(rtis).forEach(element => {
                console.log(rtis[element]);
                if (rtis[element].available && !rtis[element].master) {
                    this.type_options.push({ label: rtis[element].name, value: rtis[element].recordTypeId });
                }
            });

            this.value = this.type_options[0].value;
            this.recordTypeId = this.type_options[0].value;

        } else if (error) {
            let message = 'Unknown error';
            if (Array.isArray(error.body)) {
                message = error.body.map(e => e.message).join(', ');
            } else if (typeof error.body.message === 'string') {
                message = error.body.message;
            }
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error loading Case',
                    message,
                    variant: 'error',
                }),
            );
        }
    }

    handleChange(event) {
        const incidentLabel = this.type_options.find(option => option.value === event.detail.value);
        this.incidentType = incidentLabel.label === 'Incident' ? true : false
        this.recordTypeId = event.detail.value;

    }

    nextClickButton(event) {
        console.log(event.target.name);
        /**/
        if (event.target.name === 'first') {
            this.isRadioButtonVisible = false;
            this.isPicklistVisible = true;
            this.singleButtonVisible = false;
            this.doubleButtonVisible = true;
            this.areDetailsVisible = true;
            this.progressStep = '3';
        } else if (event.target.name === 'start') {
            this.firstRadioButton = false;
            this.progressStep = '2';
        }
        else if (event.target.name == 'second') {
            var type = this.template.querySelector('[data-id="type"]').value;
            if (type == 'Training Request') {
                this.requestedForVisible = true;
            }
            else this.requestedForVisible = false;
            this.template.querySelectorAll('lightning-input-field').forEach(element => {
                element.reportValidity();
                this.progressStep = '4';
            });

            let nameCmp = this.template.querySelector(".disable-class2");

            if (!nameCmp.value) {
                return;
            }


            this.isSaveButtonVisible = true;
            this.doubleButtonVisible = false;
            this.template.querySelectorAll('.disable-class').forEach(item => {
                item.classList.add('slds-assistive-text');

            });

        }


    }
    backClickButton(event) {

        if (event.target.name === 'first') {
            this.isRadioButtonVisible = true;
            this.isPicklistVisible = false;
            this.singleButtonVisible = true;
            this.doubleButtonVisible = false;
            this.progressStep = '2';
        }
        else if (event.target.name === 'start') {
            this.firstRadioButton = true;
            this.progressStep = '1';
        }
        else if (event.target.name === 'second') {
            this.template.querySelectorAll('.disable-class').forEach(item => {
                item.classList.remove('slds-assistive-text');
                this.progressStep = '3';
            });
            this.isSaveButtonVisible = false;
            this.doubleButtonVisible = true;
        }


    }
    handleSubmit() {
        event.preventDefault();
        const fields = event.detail.fields;
        console.log('fields::>' + JSON.stringify(fields));
        console.log('fields::>' + this.retemployeeEmail);
        console.log('fields::>' + JSON.stringify(fields.Employee__c));
        console.log('fields::>' + JSON.stringify(fields.Email__c));
        fields.Employee__c = this.retemployeeId;
        fields.SuppliedEmail = this.retemployeeEmail;
        this.template.querySelector('lightning-record-edit-form').submit(fields);

    }

    handleSuccess(event) {

        const toastEvent = new ShowToastEvent({
            title: 'Success!',
            message: 'Case created successfully!',
            variant: 'success',
            mode: 'dismissable'
        });
        this.dispatchEvent(toastEvent);
        this.recordId = event.detail.id;
        if (this.filesData == [] || this.filesData.length == 0) {
            //   this.showToast('Error', 'error', 'Please select files first'); return;
        } else {
            uploadFiles({
                recordId: this.recordId,
                filedata: JSON.stringify(this.filesData)
            })
        }



        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: event.detail.id,
                objectApiName: 'Case',
                actionName: 'view'
            }
        });

    }

    handleLoad(event) {
        this.areDetailsVisible = false;
    }

    errorHandler(event) {
        console.log('Error', error);

        // let message = 'Unknown error';
        // if (Array.isArray(error.body)) {
        //     message = error.body.map(e => e.message).join(', ');
        // } else if (typeof error.body.message === 'string') {
        //     message = error.body.message;
        // }
        // this.dispatchEvent(
        //     new ShowToastEvent({
        //         title: 'Error loading Case',
        //         message,
        //         variant: 'error',
        //     }),
        // );
    }

    validateFields() {
        this.template.querySelectorAll('lightning-input-field').forEach(element => {
            element.reportValidity();
        });
    }

    handleFileUploaded(event) {
        if (event.target.files.length > 0) {
            for (var i = 0; i < event.target.files.length; i++) {
                if (event.target.files[i].size > MAX_FILE_SIZE) {
                    this.showToast('Error!', 'error', 'File size exceeded the upload size limit.');
                    return;
                }
                let file = event.target.files[i];
                let reader = new FileReader();
                reader.onload = e => {
                    var fileContents = reader.result.split(',')[1]
                    this.filesData.push({ 'fileName': file.name, 'fileContent': fileContents });
                };
                reader.readAsDataURL(file);
            }
        }
    }

    uploadFiles() {

    }

    removeReceiptImage(event) {
        var index = event.currentTarget.dataset.id;
        this.filesData.splice(index, 1);
    }

    showToast(title, variant, message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                variant: variant,
                message: message,
            })
        );
    }

    value = 'In Progress';

    get options() {
        return [
            { label: 'HR Case', value: 'HR Case' }
        ];
    }

    handleLocationName(e) {

        if (e.target.value === 'Non-BakerRipley location') {
            this.NonBakerRipley = true;
        } else {
            this.NonBakerRipley = false
        }
    }
    // handleTypeChange(e)
    // {
    //     alert(e.target.value)
    // }


}