import { LightningElement, api, wire, track } from 'lwc';
import getMembers from '@salesforce/apex/IncidentController.getMembers';
import { loadStyle } from 'lightning/platformResourceLoader'
import COLORS from '@salesforce/resourceUrl/Colors'
import SAMPLEMC from "@salesforce/messageChannel/incident__c"
import {subscribe, MessageContext, APPLICATION_SCOPE, unsubscribe,publish} from 'lightning/messageService'

export default class ShowIncidentUsers extends LightningElement {

    @track columnsList = [{
        label: "Name", fieldName: "Name", cellAttributes: {
            class: { fieldName: 'accountColor' }, alignment: 'center'
        }
    },
    {
        label: "Role", fieldName: "Role", cellAttributes: {
            class: { fieldName: 'amountColor' },
            iconName: { fieldName: 'iconName' }, iconPosition: 'right', alignment: 'center'
        }
    },
    {
        label: "Description", fieldName: "Description", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    ];

    @wire(MessageContext)
    messageContext;
    receivedMessage;

    @api recordId
    isLoaded = true;
    @track membersList = [];
    showDataTable = false;
    isCssLoaded = false;
    subscription = null;

    connectedCallback() {
        this.isLoaded = false;
        this.subscribeMessage()
        this.getWiredData();
        if (this.isCssLoaded) return
        this.isCssLoaded = true
        loadStyle(this, COLORS).then(() => {
            console.log("Loaded Successfully")
        }).catch(error => {
            console.error("Error in loading the colors")
        })
    }

    subscribeMessage(){
        if (this.subscription) {
            return;
        }
        this.subscription = subscribe(this.messageContext, SAMPLEMC, (message) => {
            this.displayMessage(message);
        });
    }
 
    displayMessage(message){
        this.receivedMessage = message ? JSON.stringify(message, null, '\t') : 'no message payload';
        console.log('this.receivedMessage',this.receivedMessage);
        console.log('this.receivedMessage.isCreated',typeof this.receivedMessage);
        console.log('this.receivedMessage.isCreated',message.isCreated);

        if(this.receivedMessage != 'no message payload') {
            this.isLoaded = false;
            setTimeout(() => {
                this.getWiredData();
            }, 2000);
        }
     }


    getWiredData() {
        getMembers({
            caseId: this.recordId,
        })
            .then(result => {
                if (result) {
                    console.log('this.membersList',JSON.stringify(result));
                    this.membersList = JSON.parse(JSON.stringify(result));
                    console.log('this.membersList',JSON.stringify(this.membersList));
                    if (this.membersList.length > 0) {
                        this.showDataTable = true;
                    }
                    else {
                        this.showDataTable = false;
                    }
                    this.isLoaded = true;
                } else {
                    this.isLoaded = true;
                }
            }).catch(error => {
                
                this.isLoaded = true;
            })
    }
}