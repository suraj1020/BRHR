import { LightningElement, track, wire } from 'lwc';
import getAllTraining from '@salesforce/apex/TrainingController.getAllTrainings';
import createTrainingRecord from '@salesforce/apex/TrainingController.createEmployeeTraining';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
import uId from '@salesforce/user/Id';
import getEmployeeData from '@salesforce/apex/TrainingController.getEmployeeData';
import { reduceErrors } from 'c/lwcUtility';
import { publish, MessageContext } from 'lightning/messageService';

export default class TrainingEnrollTable extends LightningElement {

    @track trainingData = [];
    trainingDataDummy = [];
    @track showFilteredData = false;
    @track searchTerm = '';
    @track filteredData = [];
    value = '-- None --';
    userId = uId;
    empId = '';
    isLoading = true;
    @track wireData = [];
    showMessage = false;
    msg = '';
    empProfile = ''
    @track empTrainingRec = { Employee__c: '', Learning_and_Development__c: '', Status__c: 'New', Priority__c: '' }
    placeholder;
    fieldLabel;
    searchTermType;

    highFlag = '/img/samples/flag_red.gif'
    mediumFlag = '/img/samples/flag_yellow.gif'
    lowFlag = '/img/samples/flag_green.gif'

    get options() {
        return [
            { label: '-- None --', value: '' },
            { label: 'Name', value: 'Name' },
            { label: 'Type', value: 'Training_Type__c' }
        ];
    }
    
    @wire(MessageContext)
    messageContext;

    handleChange(event) {
        this.value = event.detail.value;
        if (this.value == '' || this.value == null) {
            this.fieldLabel = null;
            this.placeholder = null;
        }
        else {
            if (this.searchTermType != undefined) {
                this.findRecords(this.searchTermType);
            }
            this.fieldLabel = this.value == 'Name' ? 'Training Name' : 'Training Type';
            this.placeholder = this.value == 'Name' ? 'Please search with Training name' : 'Please search with Training type';
        }
    }

    /**************************Handling Search based on Name and Type************************ */
    handleSearchType(event) {
        this.findRecords(event.target.value);
    }

    findRecords(searchString) {
        this.showFilteredData = true;
        this.searchTermType = searchString.toLowerCase();

        // Filter the data based on the description
        if (this.value == 'Training_Type__c') {
            this.filteredData = this.trainingData.filter(item =>
                item.TrainingType.toLowerCase().includes(this.searchTermType)
            );
        }
        if (this.value == 'Name') {
            this.filteredData = this.trainingData.filter(item =>
                item.TrainingName.toLowerCase().includes(this.searchTermType)
            );
        }

        // Show/hide the message based on whether there are results
        this.showMessage = this.filteredData.length == 0;
    }

    /******************************* Get Employee Data ************************************/
    @wire(getEmployeeData, { userId: '$userId' })
    getEmployee({ error, data }) {
        console.log('getEmployee -- ');
        if (data) {
            if (data.length > 0) {
                console.log('data[0].Id -- ' + data[0].Id);
                this.empId = data[0].Id;
                this.empProfile = data[0].JobProfile;
                console.log('this.empId -- ' + this.empId,' this.empProfile --',this.empProfile);
                if (this.empProfile == undefined || this.empProfile == '') {
                    this.showMessage = true;
                    this.msg = 'Sorry for the inconvenience!! We don\'t have any training programs for you to enroll right now.';
                    this.isLoading = false
                }
            }
        }
        if (error) {
            console.log('error', error);
        }
    }

    /****************************** Get All Training Programs *******************************/
    @wire(getAllTraining, { empId: '$empId', jobProfile: '$empProfile' })
    getTraining(result) {

        //console.log('----this.trainingData--110--' + JSON.stringify(getTraining));
        this.wireData = result;
        console.log(this.empId+' -- '+this.empProfile+'----this.trainingData--112--' + JSON.stringify(this.wireData));
        if (result.data) {
            if (result.data.length > 0) {
                this.showFilteredData = false;
                this.trainingData = result.data;
                this.trainingDataDummy = result.data;
                console.log('----this.trainingData--117--' + JSON.stringify(result.data));
                this.showMessage = false;
            }
            else {
                this.msg = 'Sorry for the inconvenience!! We don\'t have any training programs for you to enroll right now.';
                this.showMessage = true;
            }
            this.isLoading = false
        }
        if (result.error) {
            console.log('error', result.error)
        }
    }

    /****************************** Enroll Employe for Training Program ************************/
    handleEnroll(event) {
        let index = event.target.dataset.index;
        let learningPathData = JSON.parse(JSON.stringify(this.trainingData));
        learningPathData[index].isEnrolled = true;
        this.trainingData = learningPathData;
        console.log('this.empId -- ' + this.empId);
        if (this.empId) {
            this.empTrainingRec['Learning_and_Development__c'] = event.target.dataset.id;
            this.empTrainingRec['Employee__c'] = this.empId;
            this.empTrainingRec['Description__c'] = learningPathData[index].Description;
             // Determine priority based on isHigh, isLow, isMedium
            if (learningPathData[index].isHigh) {
                this.empTrainingRec['Priority__c'] = 'High';
            } else if (learningPathData[index].isLow) {
                this.empTrainingRec['Priority__c'] = 'Low';
            } else if (learningPathData[index].isMedium) {
                this.empTrainingRec['Priority__c'] = 'Medium';
            } else {
                this.empTrainingRec['Priority__c'] = 'Unknown'; // Default value if no priority is set
            }

            this.createRecord();
        }
        else {
            this.displayMessage('Error Occured', 'error', 'Employee not found');
        }
    }

    createRecord() {
        this.isLoading = true;
        createTrainingRecord({ payload: JSON.stringify(this.empTrainingRec) })
            .then(res => {
                refreshApex(this.wireData);
                this.displayMessage('Enrolled Succesfully', 'success', 'You have enrolled to this training succesfully');
                this.isLoading = false;
                console.log('Enrolled Training Refresh called..');
                window.location.reload();


                //const payload = {refresh: true};
                //publish(this.messageContext, refreshItem, payload);

            })
            .catch(error => {
                //this.displayMessage('Error Occured', 'error', reduceErrors(error).toString())
                this.isLoading = false
            })
    }

    /******************************* Display Toast Message *********************** */
    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }


    handleSearch(event) {
        console.log('handleSearch ' + JSON.stringify(event.detail));
        this.trainingData = event.detail.filteredData;
    }

    displayAllData(event) {
        console.log('event.detail ' + JSON.stringify(event.detail));
        if (event.detail.tabName == "availableTraining" && event.detail.enrolledType == "") {
            this.trainingData = event.detail.dataToDisplay;
        }

    }

    /*sendDataToDisplay(event) {
        console.log('sendDataToDisplay event handled ' + event.detail);
        if (event.detail == 'Trianings') {
            this.displayLearningPath = false;
            this.trainingData = this.trainingDataDummy;
            this.searchData = this.trainingDataDummy;
            this.displayTrainings = true;
        } else if (event.detail == 'Learning Paths') {
            this.displayTrainings = false;
            this.pathData = this.pathDataDummy;
            this.searchData = this.pathDataDummy;
            this.displayLearningPath = true;
        } else {
            this.displayTrainings = false;
            this.displayLearningPath = false;
            this.searchData = [];
            this.trainingData = [];
        }
    }*/
}