import { LightningElement, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import { refreshApex } from '@salesforce/apex';
import BODY_FIELD from '@salesforce/schema/FeedItem.Body';
import createFeedItemRec from '@salesforce/apex/CustomCommentFeederController.createFeedItemRec';
import getFeedItemList from '@salesforce/apex/CustomCommentFeederController.getFeedItemList';
import getBadgeRecord from '@salesforce/apex/CustomCommentFeederController.getBadgeRecord';

export default class CustomCommentFeeder extends NavigationMixin(LightningElement) {

    @api recordId
    @track userId
    commnetBody = BODY_FIELD
    @track badgeRecord = {}
    @track comments = []
    @track error

    connectedCallback() {
        getBadgeRecord({ recordId : this.recordId }).then(response=> {
            this.userId =  response.RecipientId
            this.badgeRecord = response
            getFeedItemList({ status : response.Message, parentIds : response.RecipientId }).then(result=> {
                this.comments = result
            })
        })
    }

    recFeedItem = {
        Body: this.commnetBody,
        ParentId : this.userId,
        IsRichText: true
    };

    handleChange(event) {
        this.recFeedItem.Body = event.target.value;
    }

    handleSelect(event) {
        const userCommentId = event.detail;
        let userId = this.comments.data.find(
            (comment) => comment.Id === userCommentId
        ).CreatedBy.Id;
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: userId,
                objectApiName: 'User',
                actionName: 'view'
            }
        });
    }

    handlePostClick(event) {
        this.recFeedItem.ParentId = this.userId;
        console.log('Value--> ' + JSON.stringify(this.recFeedItem));
        createFeedItemRec({ 'feedItemRec': this.recFeedItem, recordId : this.recordId })
            .then((response) => {
                this.commnetBody = '';
                this.comments = response
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Comment Posted!',
                        variant: 'success'
                    })
                );
                refreshApex(this.comments);
            })
            .catch((error) => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error!',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }
}