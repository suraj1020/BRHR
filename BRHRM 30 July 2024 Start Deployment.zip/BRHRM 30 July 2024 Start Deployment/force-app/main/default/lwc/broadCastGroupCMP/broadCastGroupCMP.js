import { LightningElement,wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation'
import { getRecord } from 'lightning/uiRecordApi';
import Id from '@salesforce/user/Id'; 
import ProfileName from '@salesforce/schema/User.Profile.Name';

export default class BroadCastGroupCMP extends NavigationMixin(LightningElement) {

    userId = Id;
    userProfile;

    isShow = false;

    @wire(getRecord, { recordId: Id, fields: [ProfileName] })
    userDetails({ error, data }) {
        if (error) {
            this.error = error;
        } else if (data) {
            if (data.fields.Profile.value != null) {

                this.userProfile = data.fields.Profile.value.fields.Name.value;
                console.log('Profile Name      ',this.userProfile);
                
                this.isShow = this.userProfile == 'HR' || this.userProfile == 'System Administrator' ? true : false;
            }
          
        }
    }

    handleClick(){

        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'CollaborationGroup',
                actionName: 'list'
            },
            state: {       
                filterName: 'Recent' 
            }
        })

    }

}