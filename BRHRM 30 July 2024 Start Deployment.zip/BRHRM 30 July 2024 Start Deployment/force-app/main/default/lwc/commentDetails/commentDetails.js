import { LightningElement, api,track } from 'lwc';
import deleteSelectedRecord from '@salesforce/apex/PerformanceImprovementPlanController.deleteComment';
import getComments from '@salesforce/apex/PerformanceImprovementPlanController.getComments';
import getCommentsKpi from '@salesforce/apex/PerformanceImprovementPlanController.getCommentsKpi';
import getCommentsgoal from '@salesforce/apex/PerformanceImprovementPlanController.getCommentsgoal';
import updateComments from '@salesforce/apex/PerformanceImprovementPlanController.updateComments';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class CommentDetails extends LightningElement {
    @api caDetails;
    @track existingData = [];
    @api isModalOpenInitial;
    @api kpiId;
    @api goalId;
    @api typeName;
    @api loggedInUser;
    showDeleteButton = true;
    showEditButton = false
    @api viewAsManager = false
    @api nameCmp;

    connectedCallback() {
        this.loaddata();
        if(this.loggedInUser) {
            this.showDeleteButton = true
            this.showEditButton = true
        } else {
            this.showDeleteButton = false
            this.showEditButton = false
        }
        if(this.nameCmp == 'PRL') {
            if(this.viewAsManager) {
                this.showDeleteButton = false
                this.showEditButton = false
            } else {
                this.showDeleteButton = true
                this.showEditButton = true
                
            }
        }
    }
    loaddata() {
        if (this.caDetails) {
            getComments({ caId: this.caDetails.Id, typeName : this.typeName })
                .then(result => {
                    this.existingData = result;
                    this.existingData.forEach(each=> {
                        if(this.nameCmp == 'PRL') {
                            if(this.viewAsManager) {
                                let now = new Date();
                                const oneDay = 60 * 60 * 24 * 1000;
                                var compareDatesBoolean = (now - new Date(each.CreatedDate)) > oneDay;
                                if(compareDatesBoolean) {
                                    this.showEditButton = true
                                    each.showEditButton = true
                                    each.showDeleteButton = true
                                } else {
                                    this.showEditButton = false
                                    each.showEditButton = false
                                    each.showDeleteButton = false
                                }
                            } else {
                                this.showEditButton = true
                                each.showEditButton = true
                                each.showDeleteButton = true
                            }
                        } else {
                            if(this.loggedInUser) {
                                this.showEditButton = true
                                each.showEditButton = true
                                each.showDeleteButton = true
                            } else {
                                let now = new Date();
                                const oneDay = 60 * 60 * 24 * 1000;
                                var compareDatesBoolean = (now - new Date(each.CreatedDate)) > oneDay;
                                if(compareDatesBoolean) {
                                    this.showEditButton = true
                                    each.showEditButton = true
                                    each.showDeleteButton = true
                                } else {
                                    this.showEditButton = false
                                    each.showEditButton = false
                                    each.showDeleteButton = false
                                }
                            }
                        }
                        
                    })
                });
                console.log('Main data----> > > >', JSON.stringify(this.existingData))
        }
        if (this.kpiId) {
            getCommentsKpi({ kpiId: this.kpiId })
                .then(result => {
                    this.existingData = result;
                    this.existingData.forEach(each=> {
                        if(this.nameCmp == 'PRL') {
                            if(this.viewAsManager) {
                                let now = new Date();
                                const oneDay = 60 * 60 * 24 * 1000;
                                var compareDatesBoolean = (now - new Date(each.CreatedDate)) > oneDay;
                                if(compareDatesBoolean) {
                                    this.showEditButton = true
                                    each.showEditButton = true
                                    each.showDeleteButton = true
                                } else {
                                    this.showEditButton = false
                                    each.showEditButton = false
                                    each.showDeleteButton = false
                                }
                            } else {
                                this.showEditButton = true
                                each.showEditButton = true
                                each.showDeleteButton = true
                            }
                        } else {
                            if(this.loggedInUser) {
                                this.showEditButton = true
                                each.showEditButton = true
                                each.showDeleteButton = true
                            } else {
                                let now = new Date();
                                const oneDay = 60 * 60 * 24 * 1000;
                                var compareDatesBoolean = (now - new Date(each.CreatedDate)) > oneDay;
                                if(compareDatesBoolean) {
                                    this.showEditButton = true
                                    each.showEditButton = true
                                    each.showDeleteButton = true
                                } else {
                                    this.showEditButton = false
                                    each.showEditButton = false
                                    each.showDeleteButton = false
                                }
                            }
                        }
                        
                    })
                })
                .catch(error => {

                })
        }
        if (this.goalId) {
            getCommentsgoal({ goalId: this.goalId })
                .then(result => {
                    this.existingData = result;
                    this.existingData.forEach(each=> {
                        if(this.nameCmp == 'PRL') {
                            if(this.viewAsManager) {
                                let now = new Date();
                                const oneDay = 60 * 60 * 24 * 1000;
                                var compareDatesBoolean = (now - new Date(each.CreatedDate)) > oneDay;
                                if(compareDatesBoolean) {
                                    this.showEditButton = true
                                    each.showEditButton = true
                                    each.showDeleteButton = true
                                } else {
                                    this.showEditButton = false
                                    each.showEditButton = false
                                    each.showDeleteButton = false
                                }
                            } else {
                                this.showEditButton = true
                                each.showEditButton = true
                                each.showDeleteButton = true
                            }
                        } else {
                            if(this.loggedInUser) {
                                this.showEditButton = true
                                each.showEditButton = true
                                each.showDeleteButton = true
                            } else {
                                let now = new Date();
                                const oneDay = 60 * 60 * 24 * 1000;
                                var compareDatesBoolean = (now - new Date(each.CreatedDate)) > oneDay;
                                if(compareDatesBoolean) {
                                    this.showEditButton = true
                                    each.showEditButton = true
                                    each.showDeleteButton = true
                                } else {
                                    this.showEditButton = false
                                    each.showEditButton = false
                                    each.showDeleteButton = false
                                }
                            }
                        }
                        
                    })
                })
                .catch(error => {

                })
        }
    }

    commentHandler(event) {
        let index = event.currentTarget.dataset.index;
        this.existingData[index].Comment__c = event.target.value
    }

    closeEdit(event) {
        const idx = event.currentTarget.dataset.index;
        this.existingData[idx].showEditButton = false;
        this.existingData[idx].editComment = false;
        this.showEditButton = false
    }

    handleEditButton(event) {
        const idx = event.currentTarget.dataset.index;
        this.existingData[idx].showEditButton = false;
        this.existingData[idx].editComment = true;
        this.showEditButton = false
    }

    saveEditDate(event) {
        const idx = event.currentTarget.dataset.index;
        console.log('on save data full----> > > ' , JSON.stringify(this.existingData[idx]))
        updateComments({commentData : this.existingData[idx].Comment__c, commentId : this.existingData[idx].Id }).then(result=> {
            this.existingData[idx].editComment = false;
            this.showNotification('Comment Updated Successfully!!', result, 'success');
        }).catch(error => {
            this.showNotification('Some error occured!!', 'Comment is not updated.', 'error');
        })
    }



    addDeleteClickHandler(event) {

        const idx = event.currentTarget.dataset.index;
        console.log('------idx-----' + idx);
        let idToBeDeleted = this.existingData[idx].Id;
        this.existingData[idx].delete = true;
        if (idToBeDeleted) {
            deleteSelectedRecord({ commentId: idToBeDeleted })
                .then(result => {
                    this.showNotification('Comment Deleted Successfully!!', result, 'success');
                    this.loaddata();
                })
                .catch(error => {
                    this.showNotification('Some error occured!!', 'Comment is not deleted yet.', 'error');
                })
        }
    }

    closeModal() {
        this.isModalOpenInitial = false;

        this.dispatchEvent(new CustomEvent('showmodaloff', {
            detail: this.isModalOpenInitial
        }));
    }

    showNotification(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }
}