import { LightningElement,track } from 'lwc';
import filterData from '@salesforce/apex/EventListViewController.filterData';
const columns = [
    {label: 'Subject', fieldName: 'linkName', type: 'url',typeAttributes: {label: { fieldName: 'Subject' }, target: '_blank'}},
    { label: 'Start Date', fieldName: 'StartDateTime', type: 'date', typeAttributes: {day: "numeric",month: "numeric",year: "numeric",hour: '2-digit',minute: '2-digit',second: '2-digit',hour12: true},hideDefaultActions: true },
    { label: 'End Date', fieldName: 'EndDateTime', type: 'date', typeAttributes: {day: "numeric",month: "numeric",year: "numeric",hour: '2-digit',minute: '2-digit',second: '2-digit',hour12: true},hideDefaultActions: true },
    { label: 'Activity Date', fieldName: 'ActivityDate', type: 'date', typeAttributes: {day: "numeric",month: "numeric",year: "numeric",hour: '2-digit',minute: '2-digit',second: '2-digit',hour12: true},hideDefaultActions: true },
];


const My_EVENTS = 'My Events';
const My_Assigned_EVENTS = 'My Assigned Events';
 
const filterOptions = [
    { value: My_EVENTS, label: My_EVENTS },
    { value: My_Assigned_EVENTS, label: My_Assigned_EVENTS },
];


export default class EventListView extends LightningElement {
    @track currentFilter = My_EVENTS;
    @track isExpanded = false;
    itemsForCurrentView;
    @track isLoaded = false;
    filterOptions = filterOptions;
    columns = columns;
    
    connectedCallback() {
        filterData({ filter: this.currentFilter })
            .then((result) => {
                console.log('resuult',result);
            result.forEach( ( record ) => {
                record.linkName = '/employeeservicesample/s/event/' + record.Id;
            });                   
                this.itemsForCurrentView = result;
            })
            .catch((error) => {
                console.error(error);
            });
        this.isLoaded = true;
    }
 
    /*renderedCallback() {
        this.isLoaded = true;
    }*/
 
    get dropdownTriggerClass() {
        if (this.isExpanded) {
            return 'slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click custom_list_view slds-is-open'
        } else {
            return 'slds-combobox slds-dropdown-trigger slds-dropdown-trigger_click custom_list_view'
        }
    }
 
    handleFilterChangeButton(event) {
        console.log('Inside');
        this.isLoaded = false;
        let filter = event.target.dataset.filter;
        this.isExpanded = !this.isExpanded;
        if (filter !== this.currentFilter) {
            this.currentFilter = event.target.dataset.filter;
            setTimeout(() => {
                this.handleFilterData(this.currentFilter), 0
            });
        } else {
            this.isLoaded = true;
        }
    }
 
    handleFilterData(filter) {
        console.log('OutSide');
        filterData({ filter: this.currentFilter })
            .then((result) => {
                console.log('resuult',result);
            result.forEach( ( record ) => {
                record.linkName = '/employeeservicesample/s/event/' + record.Id;
                record.EmployeeName = record.Employee_Name__r.Name;
            });                   
                this.itemsForCurrentView = result;
            })
            .catch((error) => {
                console.error(error);
            });
        this.isLoaded = true;
    }
 
    handleClickExtend() {
        this.isExpanded = !this.isExpanded;
    }
}