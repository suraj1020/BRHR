import { LightningElement, track, api, wire } from 'lwc';
import TIME_ZONE from '@salesforce/i18n/timeZone';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import incidentType_Field from '@salesforce/schema/Case.Incident_Typ_e__c';
import Location_Field from '@salesforce/schema/Case.Event_Incident_Location__c';
import IncidentOccur_Field from '@salesforce/schema/Case.What_Part_of_the_employee_workday__c';
import AdministrationOfcName_Field from '@salesforce/schema/Case.Adminstrative_Office_Name__c';
import CommunityCenterName_Field from '@salesforce/schema/Case.Community_Center_Name__c';
import HeadStartCmpsName_Field from '@salesforce/schema/Case.Head_Start_Campus_Name__c';
import SeniorCenterName_Field from '@salesforce/schema/Case.Senior_Centre_Name__c';
import WorkforceCareerName_Field from '@salesforce/schema/Case.Workforce_Career_Office_Name__c';
import CharterSchoolName_Field from '@salesforce/schema/Case.Charter_School_Name__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
export default class IncidentTypeChildPage extends LightningElement {
    @api caseObj = {};
    @track caseObjData = {};
    @track caseObj = {
        Incident_Date_Time__c: null
    };
    timeZone = TIME_ZONE;



    //****Get all Picklist Values**** 
    @track typeOptions = [];
    @track locationOptions = [];
    @track incidentOccursOptions = [];
    @track administrationOfcNameOptions = [];
    @track communityCenterNameOptions = [];
    @track headStartCmpsNameOptions = [];
    @track seniorCenterNameOptions = [];
    @track workforceCareerNameOptions = [];
    @track CharterSchoolNameOptions = [];
    @track caseIncidentRecordTypeId;
    isLoaded = true;
    @api recordTypeName;
    @api currentPage;

    @wire(getObjectInfo, { objectApiName: Case_Object })
    objectInfo({ data, error }) {
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                console.log(rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Incident Related Case') {
                    this.caseIncidentRecordTypeId = rtis[element].recordTypeId;
                }
            });
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: incidentType_Field })
    incidentTypepickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOptions = [...this.typeOptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOptions--> ' + JSON.stringify(this.typeOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: Location_Field })
    locationPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.locationOptions = [...this.locationOptions, { value: val.value, label: val.label }];
            });
            console.log('this.locationOptions--> ' + JSON.stringify(this.locationOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: IncidentOccur_Field })
    incidentOccur({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.incidentOccursOptions = [...this.incidentOccursOptions, { value: val.value, label: val.label }];
            });
            console.log('this.incidentOccursOptions--> ' + JSON.stringify(this.incidentOccursOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: AdministrationOfcName_Field })
    administrationName({ data, error }) {
        if (data) {
            console.log('data-78->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.administrationOfcNameOptions = [...this.administrationOfcNameOptions, { value: val.value, label: val.label }];
            });
            console.log('this.administrationOfcNameOptions--> ' + JSON.stringify(this.administrationOfcNameOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: CommunityCenterName_Field })
    communitycenterName({ data, error }) {
        if (data) {
            console.log('data-78->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.communityCenterNameOptions = [...this.communityCenterNameOptions, { value: val.value, label: val.label }];
            });
            console.log('this.communityCenterNameOptions--> ' + JSON.stringify(this.communityCenterNameOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: HeadStartCmpsName_Field })
    headStartCenterName({ data, error }) {
        if (data) {
            console.log('data-78->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.headStartCmpsNameOptions = [...this.headStartCmpsNameOptions, { value: val.value, label: val.label }];
            });
            console.log('this.headStartCmpsNameOptions--> ' + JSON.stringify(this.headStartCmpsNameOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: SeniorCenterName_Field })
    seniorCenterCenterName({ data, error }) {
        if (data) {
            console.log('data-78->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.seniorCenterNameOptions = [...this.seniorCenterNameOptions, { value: val.value, label: val.label }];
            });
            console.log('this.seniorCenterNameOptions--> ' + JSON.stringify(this.seniorCenterNameOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: WorkforceCareerName_Field })
    workforceCareerName({ data, error }) {
        if (data) {
            console.log('data-78->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.workforceCareerNameOptions = [...this.workforceCareerNameOptions, { value: val.value, label: val.label }];
            });
            console.log('this.workforceCareerNameOptions--> ' + JSON.stringify(this.workforceCareerNameOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: CharterSchoolName_Field })
    charterSchoolName({ data, error }) {
        if (data) {
            console.log('data-78->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.CharterSchoolNameOptions = [...this.CharterSchoolNameOptions, { value: val.value, label: val.label }];
            });
            console.log('this.CharterSchoolNameOptions--> ' + JSON.stringify(this.CharterSchoolNameOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    //****End of Picklist values****



    @track adminisOfc = false;
    @track cmuntyCntr = false;
    @track workfrcCrr = false;
    @track nBrLctn = false;
    @track seniorCntr = false;
    @track headstrt = false;
    @track ChrtrSchol = false;

    connectedCallback() {
        console.log('Enter Callback--> ' + JSON.stringify(this.caseObj));
        if (this.caseObj != null && this.caseObj != undefined) {
            let obj = JSON.parse(JSON.stringify(this.caseObj));
            this.caseObj = obj;
            if (this.caseObj.Event_Incident_Location__c != null && this.caseObj.Event_Incident_Location__c != undefined && this.caseObj.Event_Incident_Location__c != '') {
                this.dependentIndentLocationName(this.caseObj.Event_Incident_Location__c);
            }
        }

    }

    handleIncidentLocation(event) {
        const fieldsToRemove = ['Adminstrative_Office_Name__c', 'Community_Center_Name__c', 'Head_Start_Campus_Name__c', 'Senior_Centre_Name__c', 'Workforce_Career_Office_Name__c', 'Non_BakerRipley_Location_Name__c', 'Charter_School_Name__c'];

        //console.log('tyy d->'+ typeof this.caseObjData);
        console.log('tyy obj->' + typeof this.caseObj);
        fieldsToRemove.forEach(fieldName => {
            console.log('199--> ' + JSON.stringify(this.caseObj));
            if (this.caseObj.hasOwnProperty(fieldName)) {
                delete this.caseObj[fieldName];
            }
            console.log('fielname->' + fieldName);
        });
        console.log('177--> ' + event.target.value);
        this.caseObj.Event_Incident_Location__c = event.target.value;
        this.dependentIndentLocationName(event.target.value);
    }

    dependentIndentLocationName(targetname) {
        if (targetname == 'Administrative Office') {
            this.adminisOfc = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.adminisOfc;
        }
        else if (targetname == 'Community Center') {
            this.cmuntyCntr = true;
            this.adminisOfc = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.cmuntyCntr;
        }
        else if (targetname == 'Head Start Campus') {
            this.headstrt = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.adminisOfc = this.ChrtrSchol = !this.headstrt;
        }
        else if (targetname == 'Senior Center') {
            this.seniorCntr = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.adminisOfc = this.headstrt = this.ChrtrSchol = !this.seniorCntr;
        }
        else if (targetname == 'Workforce Office') {
            this.workfrcCrr = true;
            this.cmuntyCntr = this.adminisOfc = this.nBrLctn = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.workfrcCrr;
        }
        else if (targetname == 'Non-BakerRipley location') {
            this.nBrLctn = true;
            this.cmuntyCntr = this.workfrcCrr = this.adminisOfc = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.nBrLctn;
        }
        else if (targetname == 'Charter School') {
            this.ChrtrSchol = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.headstrt = this.adminisOfc = !this.ChrtrSchol;
        }
    }

    handleChange(event) {
         const field = event.target.name;
        if (field === 'Incident_Date_Time__c') {
            const utcDateTimeString = event.target.value;
            console.log(utcDateTimeString);
            const utcDate = new Date(utcDateTimeString);
            console.log(utcDate);
            // const cstOffset = 10*60 +30; // CST is UTC-6
            // const cstDate = new Date(utcDate.getTime() - (cstOffset * 60 * 1000));
            // console.log(cstDate);
            const currentDateTime = new Date();
            console.log(currentDateTime);
            if (utcDate > currentDateTime) {
                this.displayMessage("Error.", "error", "Please choose date which is not a future date");
                event.target.value = '';
            } else {
                this.caseObj[field] = event.target.value;
            }
        }
         else {
            this.caseObj[field] = event.target.value;
        }

        console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));

        if (event.target.name == 'Incident_Typ_e__c') {
            console.log('Hi enter')
            this.deleteUnneccessaryFields();
            console.log('caseObh',JSON.stringify(this.caseObj));
        }

     }


    deleteUnneccessaryFields() {
        if (this.caseObj.Incident_Typ_e__c == 'Employee related Incident') {
            console.log('1')
            if (this.caseObj.hasOwnProperty('Type_of_Abuse_Exploitation__c')) {
                delete this.caseObj.Type_of_Abuse_Exploitation__c;
            }
            if (this.caseObj.hasOwnProperty('Case_Submitted__c')) {
                delete this.caseObj.Case_Submitted__c;
            }
            if (this.caseObj.hasOwnProperty('Case_Number__c')) {
                delete this.caseObj.Case_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Sign_of_Abuse_Neglect__c')) {
                delete this.caseObj.Sign_of_Abuse_Neglect__c;
            }
            if (this.caseObj.hasOwnProperty('Result_of_Abuse__c')) {
                delete this.caseObj.Result_of_Abuse__c;
            }


            if (this.caseObj.hasOwnProperty('IT_Incident_Type__c')) {
                delete this.caseObj.IT_Incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Steps_Taken__c')) {
                delete this.caseObj.Steps_Taken__c;
            }
            if (this.caseObj.hasOwnProperty('IT_Incident_Type__c')) {
                delete this.caseObj.IT_Incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Affected_System_Device_Type__c')) {
                delete this.caseObj.Affected_System_Device_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Sensitive_Data__c')) {
                delete this.caseObj.Sensitive_Data__c;
            }
            if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
                delete this.caseObj.Police_Report_filed__c;
            }
            if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                delete this.caseObj.Report_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                delete this.caseObj.Officer_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                delete this.caseObj.Badge_Number__c;
            }


            if (this.caseObj.hasOwnProperty('Facility_incident_Type__c')) {
                delete this.caseObj.Facility_incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Accident__c')) {
                delete this.caseObj.Accident__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Property_Damage__c')) {
                delete this.caseObj.Type_of_Property_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Security_Issue__c')) {
                delete this.caseObj.Type_of_Security_Issue__c;
            }
            if (this.caseObj.hasOwnProperty('Air_Bag_Deployed__c')) {
                delete this.caseObj.Air_Bag_Deployed__c;
            }
            if (this.caseObj.hasOwnProperty('Emergency_Services_called__c')) {
                delete this.caseObj.Emergency_Services_called__c;
            }
            if (this.caseObj.hasOwnProperty('Seat_Belt_Used__c')) {
                delete this.caseObj.Seat_Belt_Used__c;
            }
            if (this.caseObj.hasOwnProperty('Police__c')) {
                delete this.caseObj.Police__c;
            }
            if (this.caseObj.hasOwnProperty('Fire__c')) {
                delete this.caseObj.Fire__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance__c')) {
                delete this.caseObj.Ambulance__c;
            }
            if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
                delete this.caseObj.Police_Report_filed__c;
            }
            if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                delete this.caseObj.Report_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                delete this.caseObj.Officer_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                delete this.caseObj.Badge_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Details__c')) {
                delete this.caseObj.Vehicle_Details__c;
            }
            if (this.caseObj.hasOwnProperty('License_Plate_Number__c')) {
                delete this.caseObj.License_Plate_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Type__c')) {
                delete this.caseObj.Vehicle_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Model__c')) {
                delete this.caseObj.Model__c;
            }
            if (this.caseObj.hasOwnProperty('VIN_Number__c')) {
                delete this.caseObj.VIN_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Year__c')) {
                delete this.caseObj.Year__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Building_Damage__c')) {
                delete this.caseObj.Type_of_Building_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Action_Taken__c')) {
                delete this.caseObj.Action_Taken__c;
            }
            if (this.caseObj.hasOwnProperty('Description_of_Damage__c')) {
                delete this.caseObj.Description_of_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Weather__c')) {
                delete this.caseObj.Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Weather__c')) {
                delete this.caseObj.Other_Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Pavement__c')) {
                delete this.caseObj.Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Pavement__c')) {
                delete this.caseObj.Other_Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Conditions__c')) {
                delete this.caseObj.Conditions__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Conditions__c')) {
                delete this.caseObj.Other_Conditions__c;
            }


        } else if (this.caseObj.Incident_Typ_e__c == 'Abuse/Exploitation & Neglect') {
            console.log('2')
            if (this.caseObj.hasOwnProperty('IT_Incident_Type__c')) {
                delete this.caseObj.IT_Incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Steps_Taken__c')) {
                delete this.caseObj.Steps_Taken__c;
            }
            if (this.caseObj.hasOwnProperty('IT_Incident_Type__c')) {
                delete this.caseObj.IT_Incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Affected_System_Device_Type__c')) {
                delete this.caseObj.Affected_System_Device_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Sensitive_Data__c')) {
                delete this.caseObj.Sensitive_Data__c;
            }
            if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
                delete this.caseObj.Police_Report_filed__c;
            }
            if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                delete this.caseObj.Report_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                delete this.caseObj.Officer_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                delete this.caseObj.Badge_Number__c;
            }


            if (this.caseObj.hasOwnProperty('Facility_incident_Type__c')) {
                delete this.caseObj.Facility_incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Accident__c')) {
                delete this.caseObj.Accident__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Property_Damage__c')) {
                delete this.caseObj.Type_of_Property_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Security_Issue__c')) {
                delete this.caseObj.Type_of_Security_Issue__c;
            }
            if (this.caseObj.hasOwnProperty('Air_Bag_Deployed__c')) {
                delete this.caseObj.Air_Bag_Deployed__c;
            }
            if (this.caseObj.hasOwnProperty('Emergency_Services_called__c')) {
                delete this.caseObj.Emergency_Services_called__c;
            }
            if (this.caseObj.hasOwnProperty('Seat_Belt_Used__c')) {
                delete this.caseObj.Seat_Belt_Used__c;
            }
            if (this.caseObj.hasOwnProperty('Police__c')) {
                delete this.caseObj.Police__c;
            }
            if (this.caseObj.hasOwnProperty('Fire__c')) {
                delete this.caseObj.Fire__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance__c')) {
                delete this.caseObj.Ambulance__c;
            }
            if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
                delete this.caseObj.Police_Report_filed__c;
            }
            if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                delete this.caseObj.Report_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                delete this.caseObj.Officer_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                delete this.caseObj.Badge_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Details__c')) {
                delete this.caseObj.Vehicle_Details__c;
            }
            if (this.caseObj.hasOwnProperty('License_Plate_Number__c')) {
                delete this.caseObj.License_Plate_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Type__c')) {
                delete this.caseObj.Vehicle_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Model__c')) {
                delete this.caseObj.Model__c;
            }
            if (this.caseObj.hasOwnProperty('VIN_Number__c')) {
                delete this.caseObj.VIN_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Year__c')) {
                delete this.caseObj.Year__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Building_Damage__c')) {
                delete this.caseObj.Type_of_Building_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Action_Taken__c')) {
                delete this.caseObj.Action_Taken__c;
            }
            if (this.caseObj.hasOwnProperty('Description_of_Damage__c')) {
                delete this.caseObj.Description_of_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Weather__c')) {
                delete this.caseObj.Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Weather__c')) {
                delete this.caseObj.Other_Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Pavement__c')) {
                delete this.caseObj.Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Pavement__c')) {
                delete this.caseObj.Other_Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Conditions__c')) {
                delete this.caseObj.Conditions__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Conditions__c')) {
                delete this.caseObj.Other_Conditions__c;
            }



            if (this.caseObj.hasOwnProperty('Description_of_the_incident__c')) {
                delete this.caseObj.Description_of_the_incident__c;
            }
            if (this.caseObj.hasOwnProperty('Date_reported_to_employer__c')) {
                delete this.caseObj.Date_reported_to_employer__c;
            }
            if (this.caseObj.hasOwnProperty('Incident_result_in_loss_of_life__c')) {
                delete this.caseObj.Incident_result_in_loss_of_life__c;
            }
            if (this.caseObj.hasOwnProperty('Date_of_fatality__c')) {
                delete this.caseObj.Date_of_fatality__c;
            }
            if (this.caseObj.hasOwnProperty('Did_incident_result_in_absence_from_work__c')) {
                delete this.caseObj.Did_incident_result_in_absence_from_work__c;
            }
            if (this.caseObj.hasOwnProperty('Date_returned_to_work__c')) {
                delete this.caseObj.Date_returned_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('What_duties_the_employee_able_to_perform__c')) {
                delete this.caseObj.What_duties_the_employee_able_to_perform__c;
            }
            if (this.caseObj.hasOwnProperty('Employee_returned_to_work__c')) {
                delete this.caseObj.Employee_returned_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('Employee_s_pay_status__c')) {
                delete this.caseObj.Employee_s_pay_status__c;
            }
            if (this.caseObj.hasOwnProperty('Pay_amount_hourly_hide__c')) {
                delete this.caseObj.Pay_amount_hourly_hide__c;
            }
            if (this.caseObj.hasOwnProperty('First_full_day_back_to_work__c')) {
                delete this.caseObj.First_full_day_back_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('Anticipated_return_to_work_date__c')) {
                delete this.caseObj.Anticipated_return_to_work_date__c;
            }
            if (this.caseObj.hasOwnProperty('Incident_Category__c')) {
                delete this.caseObj.Incident_Category__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance_Called__c')) {
                delete this.caseObj.Ambulance_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Name__c')) {
                delete this.caseObj.Provider_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Phone__c')) {
                delete this.caseObj.Provider_Phone__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_concern__c')) {
                delete this.caseObj.Type_of_concern__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Illness__c')) {
                delete this.caseObj.Type_of_Illness__c;
            }
            if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
                delete this.caseObj.Medical_Treatment_Provided__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Email__c')) {
                delete this.caseObj.Provider_Email__c;
            }
            if (this.caseObj.hasOwnProperty('X911_Called__c')) {
                delete this.caseObj.X911_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Medical_Treatment_Provided__c')) {
                delete this.caseObj.Type_of_Medical_Treatment_Provided__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Address__c')) {
                delete this.caseObj.Provider_Address__c;
            }
            if (this.caseObj.hasOwnProperty('Cause_of_injury__c')) {
                delete this.caseObj.Cause_of_injury__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance_Called__c')) {
                delete this.caseObj.Ambulance_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Type_Of_Injury__c')) {
                delete this.caseObj.Type_Of_Injury__c;
            }

        } else if (this.caseObj.Incident_Typ_e__c == 'Facility Incident') {
            console.log('3')
            if (this.caseObj.hasOwnProperty('Type_of_Abuse_Exploitation__c')) {
                delete this.caseObj.Type_of_Abuse_Exploitation__c;
            }
            if (this.caseObj.hasOwnProperty('Case_Submitted__c')) {
                delete this.caseObj.Case_Submitted__c;
            }
            if (this.caseObj.hasOwnProperty('Case_Number__c')) {
                delete this.caseObj.Case_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Sign_of_Abuse_Neglect__c')) {
                delete this.caseObj.Sign_of_Abuse_Neglect__c;
            }
            if (this.caseObj.hasOwnProperty('Result_of_Abuse__c')) {
                delete this.caseObj.Result_of_Abuse__c;
            }

            if (this.caseObj.hasOwnProperty('IT_Incident_Type__c')) {
                delete this.caseObj.IT_Incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Steps_Taken__c')) {
                delete this.caseObj.Steps_Taken__c;
            }
            if (this.caseObj.hasOwnProperty('IT_Incident_Type__c')) {
                delete this.caseObj.IT_Incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Affected_System_Device_Type__c')) {
                delete this.caseObj.Affected_System_Device_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Sensitive_Data__c')) {
                delete this.caseObj.Sensitive_Data__c;
            }
            if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
                delete this.caseObj.Police_Report_filed__c;
            }
            if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                delete this.caseObj.Report_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                delete this.caseObj.Officer_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                delete this.caseObj.Badge_Number__c;
            }

            if (this.caseObj.hasOwnProperty('Description_of_the_incident__c')) {
                delete this.caseObj.Description_of_the_incident__c;
            }
            if (this.caseObj.hasOwnProperty('Date_reported_to_employer__c')) {
                delete this.caseObj.Date_reported_to_employer__c;
            }
            if (this.caseObj.hasOwnProperty('Incident_result_in_loss_of_life__c')) {
                delete this.caseObj.Incident_result_in_loss_of_life__c;
            }
            if (this.caseObj.hasOwnProperty('Date_of_fatality__c')) {
                delete this.caseObj.Date_of_fatality__c;
            }
            if (this.caseObj.hasOwnProperty('Did_incident_result_in_absence_from_work__c')) {
                delete this.caseObj.Did_incident_result_in_absence_from_work__c;
            }
            if (this.caseObj.hasOwnProperty('Date_returned_to_work__c')) {
                delete this.caseObj.Date_returned_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('What_duties_the_employee_able_to_perform__c')) {
                delete this.caseObj.What_duties_the_employee_able_to_perform__c;
            }
            if (this.caseObj.hasOwnProperty('Employee_returned_to_work__c')) {
                delete this.caseObj.Employee_returned_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('Employee_s_pay_status__c')) {
                delete this.caseObj.Employee_s_pay_status__c;
            }
            if (this.caseObj.hasOwnProperty('Pay_amount_hourly_hide__c')) {
                delete this.caseObj.Pay_amount_hourly_hide__c;
            }
            if (this.caseObj.hasOwnProperty('First_full_day_back_to_work__c')) {
                delete this.caseObj.First_full_day_back_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('Anticipated_return_to_work_date__c')) {
                delete this.caseObj.Anticipated_return_to_work_date__c;
            }
            if (this.caseObj.hasOwnProperty('Incident_Category__c')) {
                delete this.caseObj.Incident_Category__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance_Called__c')) {
                delete this.caseObj.Ambulance_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Name__c')) {
                delete this.caseObj.Provider_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Phone__c')) {
                delete this.caseObj.Provider_Phone__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_concern__c')) {
                delete this.caseObj.Type_of_concern__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Illness__c')) {
                delete this.caseObj.Type_of_Illness__c;
            }
            if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
                delete this.caseObj.Medical_Treatment_Provided__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Email__c')) {
                delete this.caseObj.Provider_Email__c;
            }
            if (this.caseObj.hasOwnProperty('X911_Called__c')) {
                delete this.caseObj.X911_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Medical_Treatment_Provided__c')) {
                delete this.caseObj.Type_of_Medical_Treatment_Provided__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Address__c')) {
                delete this.caseObj.Provider_Address__c;
            }
            if (this.caseObj.hasOwnProperty('Cause_of_injury__c')) {
                delete this.caseObj.Cause_of_injury__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance_Called__c')) {
                delete this.caseObj.Ambulance_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Type_Of_Injury__c')) {
                delete this.caseObj.Type_Of_Injury__c;
            }
        } else {
            console.log('4')
            if (this.caseObj.hasOwnProperty('Type_of_Abuse_Exploitation__c')) {
                delete this.caseObj.Type_of_Abuse_Exploitation__c;
            }
            if (this.caseObj.hasOwnProperty('Case_Submitted__c')) {
                delete this.caseObj.Case_Submitted__c;
            }
            if (this.caseObj.hasOwnProperty('Case_Number__c')) {
                delete this.caseObj.Case_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Sign_of_Abuse_Neglect__c')) {
                delete this.caseObj.Sign_of_Abuse_Neglect__c;
            }
            if (this.caseObj.hasOwnProperty('Result_of_Abuse__c')) {
                delete this.caseObj.Result_of_Abuse__c;
            }

            if (this.caseObj.hasOwnProperty('Description_of_the_incident__c')) {
                delete this.caseObj.Description_of_the_incident__c;
            }
            if (this.caseObj.hasOwnProperty('Date_reported_to_employer__c')) {
                delete this.caseObj.Date_reported_to_employer__c;
            }
            if (this.caseObj.hasOwnProperty('Incident_result_in_loss_of_life__c')) {
                delete this.caseObj.Incident_result_in_loss_of_life__c;
            }
            if (this.caseObj.hasOwnProperty('Date_of_fatality__c')) {
                delete this.caseObj.Date_of_fatality__c;
            }
            if (this.caseObj.hasOwnProperty('Did_incident_result_in_absence_from_work__c')) {
                delete this.caseObj.Did_incident_result_in_absence_from_work__c;
            }
            if (this.caseObj.hasOwnProperty('Date_returned_to_work__c')) {
                delete this.caseObj.Date_returned_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('What_duties_the_employee_able_to_perform__c')) {
                delete this.caseObj.What_duties_the_employee_able_to_perform__c;
            }
            if (this.caseObj.hasOwnProperty('Employee_returned_to_work__c')) {
                delete this.caseObj.Employee_returned_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('Employee_s_pay_status__c')) {
                delete this.caseObj.Employee_s_pay_status__c;
            }
            if (this.caseObj.hasOwnProperty('Pay_amount_hourly_hide__c')) {
                delete this.caseObj.Pay_amount_hourly_hide__c;
            }
            if (this.caseObj.hasOwnProperty('First_full_day_back_to_work__c')) {
                delete this.caseObj.First_full_day_back_to_work__c;
            }
            if (this.caseObj.hasOwnProperty('Anticipated_return_to_work_date__c')) {
                delete this.caseObj.Anticipated_return_to_work_date__c;
            }
            if (this.caseObj.hasOwnProperty('Incident_Category__c')) {
                delete this.caseObj.Incident_Category__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance_Called__c')) {
                delete this.caseObj.Ambulance_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Name__c')) {
                delete this.caseObj.Provider_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Phone__c')) {
                delete this.caseObj.Provider_Phone__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_concern__c')) {
                delete this.caseObj.Type_of_concern__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Illness__c')) {
                delete this.caseObj.Type_of_Illness__c;
            }
            if (this.caseObj.hasOwnProperty('Medical_Treatment_Provided__c')) {
                delete this.caseObj.Medical_Treatment_Provided__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Email__c')) {
                delete this.caseObj.Provider_Email__c;
            }
            if (this.caseObj.hasOwnProperty('X911_Called__c')) {
                delete this.caseObj.X911_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Medical_Treatment_Provided__c')) {
                delete this.caseObj.Type_of_Medical_Treatment_Provided__c;
            }
            if (this.caseObj.hasOwnProperty('Provider_Address__c')) {
                delete this.caseObj.Provider_Address__c;
            }
            if (this.caseObj.hasOwnProperty('Cause_of_injury__c')) {
                delete this.caseObj.Cause_of_injury__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance_Called__c')) {
                delete this.caseObj.Ambulance_Called__c;
            }
            if (this.caseObj.hasOwnProperty('Type_Of_Injury__c')) {
                delete this.caseObj.Type_Of_Injury__c;
            }

            if (this.caseObj.hasOwnProperty('Facility_incident_Type__c')) {
                delete this.caseObj.Facility_incident_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Accident__c')) {
                delete this.caseObj.Accident__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Property_Damage__c')) {
                delete this.caseObj.Type_of_Property_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Security_Issue__c')) {
                delete this.caseObj.Type_of_Security_Issue__c;
            }
            if (this.caseObj.hasOwnProperty('Air_Bag_Deployed__c')) {
                delete this.caseObj.Air_Bag_Deployed__c;
            }
            if (this.caseObj.hasOwnProperty('Emergency_Services_called__c')) {
                delete this.caseObj.Emergency_Services_called__c;
            }
            if (this.caseObj.hasOwnProperty('Seat_Belt_Used__c')) {
                delete this.caseObj.Seat_Belt_Used__c;
            }
            if (this.caseObj.hasOwnProperty('Police__c')) {
                delete this.caseObj.Police__c;
            }
            if (this.caseObj.hasOwnProperty('Fire__c')) {
                delete this.caseObj.Fire__c;
            }
            if (this.caseObj.hasOwnProperty('Ambulance__c')) {
                delete this.caseObj.Ambulance__c;
            }
            if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
                delete this.caseObj.Police_Report_filed__c;
            }
            if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                delete this.caseObj.Report_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                delete this.caseObj.Officer_Name__c;
            }
            if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                delete this.caseObj.Badge_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Details__c')) {
                delete this.caseObj.Vehicle_Details__c;
            }
            if (this.caseObj.hasOwnProperty('License_Plate_Number__c')) {
                delete this.caseObj.License_Plate_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Vehicle_Type__c')) {
                delete this.caseObj.Vehicle_Type__c;
            }
            if (this.caseObj.hasOwnProperty('Model__c')) {
                delete this.caseObj.Model__c;
            }
            if (this.caseObj.hasOwnProperty('VIN_Number__c')) {
                delete this.caseObj.VIN_Number__c;
            }
            if (this.caseObj.hasOwnProperty('Year__c')) {
                delete this.caseObj.Year__c;
            }
            if (this.caseObj.hasOwnProperty('Type_of_Building_Damage__c')) {
                delete this.caseObj.Type_of_Building_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Action_Taken__c')) {
                delete this.caseObj.Action_Taken__c;
            }
            if (this.caseObj.hasOwnProperty('Description_of_Damage__c')) {
                delete this.caseObj.Description_of_Damage__c;
            }
            if (this.caseObj.hasOwnProperty('Weather__c')) {
                delete this.caseObj.Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Weather__c')) {
                delete this.caseObj.Other_Weather__c;
            }
            if (this.caseObj.hasOwnProperty('Pavement__c')) {
                delete this.caseObj.Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Pavement__c')) {
                delete this.caseObj.Other_Pavement__c;
            }
            if (this.caseObj.hasOwnProperty('Conditions__c')) {
                delete this.caseObj.Conditions__c;
            }
            if (this.caseObj.hasOwnProperty('Other_Conditions__c')) {
                delete this.caseObj.Other_Conditions__c;
            }
        }
    }

    @api
    handleNext() {
        console.log(' this.caseObj before sending',JSON.stringify(this.caseObj));
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid && allCBValid) {
            this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.caseObj }));
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }
    }

    displayMessage(title, variant, msg) {
        const toastEvent = new ShowToastEvent({
            title: title,
            message: msg,
            variant: variant,
        });
        this.dispatchEvent(toastEvent);
    }

    @api
    handleSaveAndExit() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid && allCBValid) {
            this.isLoaded = false;
            this.caseObj.Status = 'Draft';
            this.caseObj.CurrentPage__c = this.currentPage;
            createCaseOnSubmit({
                caseObj: this.caseObj,
                fileData: [],
                incidentUserList: [],
                recordTypeName: this.recordTypeName,
                injuryData: [],
                damageData: [],
                courseInformation: []
            })
                .then(result => {
                    if (result != null) {
                        this.isLoaded = true;
                        console.log('--92--> ' + result);
                        this.displayMessage("Success", "success", "Case saved as draft.");
                        this.dispatchEvent(new CustomEvent('saveexit'));
                    } else {
                        this.isLoaded = true;
                    }
                }).catch(error => {
                    this.displayMessage("Error", "error", reduceErrors(error).toString());
                    this.isLoaded = true;
                })
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }

    }
}