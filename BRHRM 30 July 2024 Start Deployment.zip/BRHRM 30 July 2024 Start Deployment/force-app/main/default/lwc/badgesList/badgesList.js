import { LightningElement, wire } from 'lwc';
import RecognitionIcon from "@salesforce/resourceUrl/RecognitionIcon";
import EmptyData from "@salesforce/resourceUrl/EmptyData";
import getEmployeeWorkBadges from'@salesforce/apex/BadgesListController.getEmployeeWorkBadges';

const columns = [
    { label: 'Recognition Category', fieldName: 'recognitionCategory' },
    {
        label: 'Recognition ID',
        fieldName: 'recognitionID',
        sortable: true,
        cellAttributes: { alignment: 'left' },
    },
    { label: 'Recognition name', fieldName: 'recognitionName', type:'image'},
    { label: 'Given Date', fieldName: 'givenDate', type: 'date' },
    { label: 'Given To', fieldName: 'givenTo'},
    { label: 'Title', fieldName: 'title'},
    { label: 'Department', fieldName: 'department'},
    { label: 'Given By', fieldName: 'givenBy'},

];

export default class BadgesList extends LightningElement {
    isRecordFound = true;
    getRecognitionIcon = RecognitionIcon;
    getEmptyDataImage = EmptyData;
    data=[];
    columns = columns;
    value = 'all';

    get options() {
        return [
            { label: 'FACETS Recognition', value: 'FACETS' }, 
            { label: 'H.E.R.O.I.C Recognition', value: 'HEROIC' },
            { label: 'Service Anniversary', value: 'SERVICE ANNIVERSARY' },
            { label: 'All My Recognition', value: 'all' },                       
        ];
    }

    handleChange(event) {
        this.value = event.detail.value;
    }

    @wire(getEmployeeWorkBadges,{filter : '$value'})
    workBadgesList({data, error}){ 
        if(data){             
            this.data = data;
            let tempData = JSON.parse(JSON.stringify(this.data))
            console.log('all badge data on load-----> > > ' , JSON.stringify(this.data))
            const monthsArr = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            if(this.data == ''){
                this.isRecordFound = false;
            }else{
                this.isRecordFound = true;
                tempData.forEach(eachData => {
                    const currentDateObj = new Date(eachData.givenDate);
                    const currentDate  = currentDateObj.getDate();
                    const currentMonth  = monthsArr[currentDateObj.getMonth()];
                    const currentYear = currentDateObj.getFullYear();
                    eachData.givenDate = currentMonth + ' ' + currentDate + ', ' + currentYear
                })
                this.data = tempData
            }
        }
        if(error){
            console.log('Error: ',JSON.stringify(error));
        }
    }
}