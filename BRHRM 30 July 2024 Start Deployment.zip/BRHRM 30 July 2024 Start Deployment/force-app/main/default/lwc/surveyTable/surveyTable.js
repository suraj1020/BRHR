import { LightningElement, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import returnSurvey from '@salesforce/apex/SurveyTableController.returnSurvey';
import filterSurvey from '@salesforce/apex/SurveyTableController.filterSurvey';
import surveyFilterYear from '@salesforce/apex/SurveyTableController.surveyFilterYear';
import { NavigationMixin } from 'lightning/navigation';

export default class SurveyTable extends NavigationMixin(LightningElement) {
    surveyList = [];
    data = [];
    filterYear;
    value;
    options = [];

    connectedCallback() {
        const d = new Date();
        this.value = d.getFullYear().toString();
        console.log('year -- '+this.value);
        // Fetch survey list
        returnSurvey()
            .then(res => {
                this.surveyList = res;
                console.log('Survey List:', this.surveyList);
            })
            .catch(error => {
                console.error('Error fetching survey list:', error);
                this.displayMessage('Error Occurred', 'error', error.body.message);
            });

        // Fetch filter year options
        surveyFilterYear()
            .then(res => {
                this.filterYear = res;
                console.log('Survey Filter Year:', this.filterYear);

                // Update options array based on filterYear
                this.updateOptionsFromFilterYear();
            })
            .catch(error => {
                console.error('Error fetching filter year:', error);
                this.displayMessage('Error Occurred', 'error', JSON.stringify(error));
            });
    }

    updateOptionsFromFilterYear() {
        // Split comma-separated values into an array
        const valuesArray = this.filterYear.split(',').map(item => item.trim());

        // Map array to objects with label and value properties
        this.options = valuesArray.map(value => ({ label: value, value }));
        console.log('Options:', this.options);
    }

    @wire(filterSurvey, { filter: '$value' })
    wiredReturnSurvey({ error, data }) {
        if (data) {
            this.data = data;
            console.log('Filtered Data:', this.data);
        } else if (error) {
            console.error('Error filtering survey:', error);
            this.displayMessage('Error Occurred', 'error', JSON.stringify(error));
        }
    }

    handleChange(event) {
        this.value = event.detail.value;
    }

    openScoreTable(event) {
        let surveyTakerId = event.target.dataset.id;
        console.log('Survey Taker Id:', surveyTakerId);
        let pageURL = '/employeeservicesample/s/score-table?recordId=' + surveyTakerId;
        window.open(pageURL, '_blank');
    }

    openSurveyPage(event) {
        let surveyId = event.target.dataset.id;
        console.log('Survey Id:', surveyId);
        let pageURL = '/surveys?recordId=' + surveyId;
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: pageURL
            }
        });
    }

    displayMessage(title, type, message) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: title,
                message: message,
                variant: type,
                mode: 'dismissable'
            })
        );
    }
}