import { LightningElement, track, api, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { CurrentPageReference } from 'lightning/navigation';
import getCaseRecordInformation from '@salesforce/apex/CaseCreation.getCaseRecordData';
export default class IncidentReportParentPage extends NavigationMixin(LightningElement) {
    @track page1 = true;
    @track page2 = false;
    @track page3 = false;
    @track page4 = false;
    @track page5 = false;
    @track currentStep = 1;
    @track preVisibiliy = false;
    @track cancelVisibility = true;
    @track SEvisibility = true;
    @track SNvisibility = true;
    @track doneVisibility = false;
    @track submitVisibility = false;
    @track employeeIncident = false;
    @track abuseIncident = false;
    @track facilityIncident = false;
    @track ItIncident = false;
    @track caseData = {};
    @track dataList = [];
    @track childcmpName = 'c-incident-type-child-page';
    @track caseNumber;
    @track fileDataOfMember = [];
    recordTypeName = 'Incident Related Case';
    progressValue = 1;
    @track injuryData = [];
    communitPageReferenceId;
    isLoaded = false;
    @track damageData = [];
    parameters = {};
    subject;

    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            this.communitPageReferenceId = currentPageReference.state?.id ? currentPageReference.state?.id : '';
        }
    }

    connectedCallback() {
        this.parameters = this.getQueryParameters();
         this.subject = this.parameters.subject;
        console.log('this.parameters -- '+this.parameters.subject+' --- '+JSON.stringify(this.parameters));

        console.log('this.communitPageReferenceId', this.communitPageReferenceId);
        this.getCaseValue(this.parameters.subject);
    }

    getQueryParameters() {

        var params = {};
        var search = location.search.substring(1);

        if (search) {
            params = JSON.parse('{"' + search.replace(/&/g, '","').replace(/=/g, '":"') + '"}', (key, value) => {
                return key === "" ? value : decodeURIComponent(value)
            });
        }

        return params;
    }

    isNullOrUndefined(value) {
        return value === undefined || value === null;
    }

    getCaseValue(caseSubject) {
        this.isLoaded = true;
        getCaseRecordInformation({
            caseId: this.communitPageReferenceId
        })
            .then(result => {
                if (result) {
                    let obj = JSON.parse(JSON.stringify(result));
                    console.log('this.obj--> ', JSON.stringify(obj));
                    this.caseData = obj.caseObj;
                    if(!this.isNullOrUndefined(caseSubject)) {
                        this.caseData.Subject = caseSubject;
                    } else {
                        this.caseData.Subject = this.caseObj.Subject;
                    }
                    
                    console.log('this.caseData--> ', JSON.stringify(this.caseData));                    
                    this.dataList = obj.relatedIncidentUserList;
                    console.log('this.dataList--> ', JSON.stringify(this.dataList));
                    if (this.communitPageReferenceId) {
                        this.currentStep = obj.caseObj.CurrentPage__c;
                    }
                    console.log('this.currentStep--> ', this.currentStep);
                    this.injuryData = obj.relatedInjuryList;
                    console.log('this.injuryData--> ', JSON.stringify(this.injuryData));

                    this.damageData = obj.relatedDamageList;
                    console.log('this.damageData--> ', JSON.stringify(this.damageData));
                    this.pageChanger(this.currentStep);

                }
            }).catch(error => {

            }).finally(() => {
                this.isLoaded = false;;
            });
    }

    //Progress Step
    progressStepList = [
        { label: 'Incident Type', value: 'Incident Type', index: 1 },
        { label: 'Incident Details', value: 'Incident Details', index: 2 },
        { label: 'Involved Parties', value: 'Involved Parties', index: 3 },
        { label: 'Additional Description', value: 'Additional Description', index: 4 },
        { label: 'Confirmation', value: 'Confirmation', index: 5 },
    ]


    handleProgressStepClick(event) {
        console.log('currentcalue-->' + event.target.value);
        console.log('this.progressValue', this.progressValue);
        if (event.target.value > this.progressValue) {
            console.log('this.currentStep', this.currentStep);
            console.log('this.childcmpName', this.childcmpName);
            const childComp = this.template.querySelector(this.childcmpName);
            childComp.handleNext();
        } else {
            if(event.target.value != 1)
            console.log('this.childcmpName', this.childcmpName);
            const childComp = this.template.querySelector(this.childcmpName);
            childComp.handlePrevious();
        }
        console.log('this.progressValue', this.progressValue);
        console.log('this.currentStep', this.currentStep);

    }

    pageChanger(currentstep) {
        this.currentStep = currentstep;
        this.progressValue = currentstep;
        console.log('this.currentStep->' + this.currentStep);
        if (currentstep == 1) {
            this.page1 = true;
            this.page2 = this.page3 = this.page4 = this.page5 = !this.page1;
            this.childcmpName = 'c-incident-type-child-page';

            this.preVisibiliy = false;
            this.cancelVisibility = true;
            this.SEvisibility = true;
            this.SNvisibility = true;
            this.doneVisibility = false;
            this.submitVisibility = false;
        }
        else if (currentstep == 2) {
            this.page2 = true;
            this.page1 = this.page3 = this.page4 = this.page5 = !this.page2;
            this.genericMethod();
            this.preVisibiliy = true;
            this.cancelVisibility = false;
            this.SEvisibility = true;
            this.SNvisibility = true;
            this.doneVisibility = false;
            this.submitVisibility = false;
        }
        else if (currentstep == 3) {
            this.page3 = true;
            this.page1 = this.page2 = this.page4 = this.page5 = !this.page3;
            this.childcmpName = 'c-involved-parties-information-child-page';
            this.preVisibiliy = true;
            this.cancelVisibility = false;
            this.SEvisibility = true;
            this.SNvisibility = true;
            this.doneVisibility = false;
            this.submitVisibility = false;
        }
        else if (currentstep == 4) {
            this.page4 = true;
            this.page1 = this.page2 = this.page3 = this.page5 = !this.page4;
            this.childcmpName = 'c-additional-description-case-child-page';

            this.preVisibiliy = true;
            this.cancelVisibility = false;
            this.SEvisibility = false;
            this.SNvisibility = false;
            this.doneVisibility = false;
            this.submitVisibility = true;
        }
        else if (currentstep == 5) {
            this.page5 = true;
            this.page1 = this.page2 = this.page3 = this.page4 = !this.page5;

            this.preVisibiliy = false;
            this.cancelVisibility = false;
            this.SEvisibility = false;
            this.SNvisibility = false;
            this.doneVisibility = true;
            this.submitVisibility = false;
        }


    }

    handleSaveNext() {
        console.log('this.currentStep', this.currentStep);
        console.log('this.childcmpName', this.childcmpName);
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handleNext();
    }

    handlePrevious() {
        console.log('this.childcmpName', this.childcmpName);
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handlePrevious();
    }



    handleSubmit() {
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handleNext();
    }

    handleCancel() {
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "/employeeservicesample/s/casehomepage"
            }
        });
    }

    handleDone() {
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "/employeeservicesample/s/casehomepage"
            }
        });
    }

    handleEvent(event) {
        console.log('event--116-->' + JSON.stringify(event.detail));
        this.caseData = event.detail;

        if (this.caseData.Incident_Typ_e__c == 'Employee related Incident') {
            this.employeeIncident = true;
            this.abuseIncident = false;
            this.facilityIncident = false;
            this.ItIncident = false;
            this.childcmpName = 'c-incident-details-employee-child-page';
            this.damageData = [];

        }
        else if (this.caseData.Incident_Typ_e__c == 'Abuse/Exploitation & Neglect') {
            this.employeeIncident = false;
            this.abuseIncident = true;
            this.facilityIncident = false;
            this.ItIncident = false;
            this.childcmpName = 'c-incident-details-abuse-childpage';
            this.injuryData = [];
            this.damageData = [];
        }
        else if (this.caseData.Incident_Typ_e__c == 'Facility Incident') {
            this.employeeIncident = false;
            this.abuseIncident = false;
            this.facilityIncident = true;
            this.ItIncident = false;
            this.childcmpName = 'c-incident-details-facility-child-page';
            this.injuryData = [];
        }
        else if (this.caseData.Incident_Typ_e__c == 'IT Incident') {
            this.employeeIncident = false;
            this.abuseIncident = false;
            this.facilityIncident = false;
            this.ItIncident = true;
            this.childcmpName = 'c-incident-details-i-t-child-page';
            this.injuryData = [];
            this.damageData = [];
        }

        console.log('this.employeeIncident--162-->' + this.employeeIncident);

        console.log('event--120--> ' + JSON.stringify(this.caseData));
        this.pageChanger(this.currentStep + 1);
    }

    handleCaseEvent(event) {
        console.log('event--122-->' + event.detail);
        this.caseNumber = event.detail;
        if (this.caseNumber != null && this.caseNumber != '') {
            this.pageChanger(this.currentStep + 1);
        }
    }

    handlePreviousCaseEvent(event) {
        this.fileDataOfMember = event.detail.file;
        this.caseData = { ...this.caseData, ...event.detail.caseObject };
        this.pageChanger(this.currentStep - 1);
    }

    handlePreviousEvent(event) {
        console.log('event--116-->' + JSON.stringify(event.detail));
        this.caseData = { ...this.caseData, ...event.detail };
        this.pageChanger(this.currentStep - 1);
    }

    handleParties(event) {
        console.log('--188->' + JSON.stringify(event.detail));
        this.dataList = event.detail;
        this.pageChanger(this.currentStep + 1);
    }

    handlePartiesPrevious(event) {
        this.dataList = event.detail;
        this.pageChanger(this.currentStep - 1);
    }

    genericMethod() {
        if (this.caseData.Incident_Typ_e__c == 'Employee related Incident') {
            this.employeeIncident = true;
            this.abuseIncident = false;
            this.facilityIncident = false;
            this.ItIncident = false;
            this.childcmpName = 'c-incident-details-employee-child-page';
        }
        else if (this.caseData.Incident_Typ_e__c == 'Abuse/Exploitation & Neglect') {
            this.employeeIncident = false;
            this.abuseIncident = true;
            this.facilityIncident = false;
            this.ItIncident = false;
            this.childcmpName = 'c-incident-details-abuse-childpage';
        }
        else if (this.caseData.Incident_Typ_e__c == 'Facility Incident') {
            this.employeeIncident = false;
            this.abuseIncident = false;
            this.facilityIncident = true;
            this.ItIncident = false;
            this.childcmpName = 'c-incident-details-facility-child-page';
        }
        else if (this.caseData.Incident_Typ_e__c == 'IT Incident') {
            this.employeeIncident = false;
            this.abuseIncident = false;
            this.facilityIncident = false;
            this.ItIncident = true;
            this.childcmpName = 'c-incident-details-i-t-child-page';
        }
    }

    handleSaveExit() {
        const childComp = this.template.querySelector(this.childcmpName);
        childComp.handleSaveAndExit();
    }

    handleSaveAndExitMethod() {
        this[NavigationMixin.Navigate]({
            "type": "standard__webPage",
            "attributes": {
                "url": "/employeeservicesample/s/casehomepage"
            }
        });
    }

    handleInjryData(event) {
        this.injuryData = event.detail;
    }

    handleDamagaeData(event) {
        this.damageData = event.detail
        console.log('this.damageData parent-->' + JSON.stringify(this.damageData));
    }
}