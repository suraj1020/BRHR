import { LightningElement, track, api, wire } from 'lwc';
import returnRecordId from '@salesforce/apex/FileAttachmentController.returnRecordId';

export default class UploadDocumentsForTraining extends LightningElement {

    @api recordId;

    get acceptedFormats() {
        return ['.pdf', '.png', '.jpg', '.jpeg'];
    }
    
    connectedCallback() {
        console.log('Line 12--> '+ this.recordId);
        returnRecordId({recordId: this.recordId})
        .then(result =>{
            this.recordId = result;
        });
    }
    handleUploadFinished(event) {
        // Get the list of uploaded files
        const uploadedFiles = event.detail.files;
        this.template.querySelector('c-files-dynamic-data-table').getFiles();
    }
}