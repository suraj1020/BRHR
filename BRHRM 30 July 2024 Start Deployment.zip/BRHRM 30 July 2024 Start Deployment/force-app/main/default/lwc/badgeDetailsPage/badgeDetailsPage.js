import { LightningElement, wire, api, track } from 'lwc';
import getWorkBadgeRecord from'@salesforce/apex/BadgesListController.getWorkBadgeRecord';

export default class BadgeDetailsPage extends LightningElement {
    @track workBadgeData = {};
    @api recordId;

@wire(getWorkBadgeRecord, { workBadgeRecordID: '$recordId' })
    workBadgeRecord({data, error}){ 
        if(data){             
            this.workBadgeData = data;            
            console.log('WorkBadges Record: ',JSON.stringify(this.workBadgeData));

            console.log('Badge Name: ',this.workBadgeData.name);
            console.log('recordId: ',this.recordId);

        }
        if(error){
            console.log('Error: ',JSON.stringify(error));
        }
    }
}