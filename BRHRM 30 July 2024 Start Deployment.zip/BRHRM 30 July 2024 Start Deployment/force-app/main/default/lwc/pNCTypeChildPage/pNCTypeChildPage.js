import { LightningElement, track, wire, api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import PNCType_Field from '@salesforce/schema/Case.P_C_Type__c';
import AccommodationType_Field from '@salesforce/schema/Case.Accommodati_on_Type__c';
import ReasonRecruitment_Field from '@salesforce/schema/Case.Reason_for_Recruitment__c';
import RecruitmentCaseType_Field from '@salesforce/schema/Case.Recruiting_Case_Type__c';
import ThirdPartyStaff_Field from '@salesforce/schema/Case.Third_Party_Staffing__c';
import EmployeeManagType_Field from '@salesforce/schema/Case.Employee_Management_Type__c';
import InquiryType_Field from '@salesforce/schema/Case.Inquiry_Type__c';
import HRISCaseType_Field from '@salesforce/schema/Case.HRIS_Case_Type__c';
import HRISSystemType_Field from '@salesforce/schema/Case.HRIS_System_Type__c';
import HRISCaseAccessType_Field from '@salesforce/schema/Case.Access_Type__c';
import TrainingDevType_Field from '@salesforce/schema/Case.Training_Development_Type__c';
import VirtualOrInPerson_Field from '@salesforce/schema/Case.Virtual_or_In_Person__c';
import DataReportType_Field from '@salesforce/schema/Case.Data_Report_Type__c';
import CourseOutcome_Field from '@salesforce/schema/Case.Course_Outcome__c';
import EmployeeReferral_Field from '@salesforce/schema/Case.Employee_Referral__c';
import BenefitsType_Field from '@salesforce/schema/Case.Retirement_Benefits__c';
import PerformanceType_Field from '@salesforce/schema/Case.Performance_Type__c';
import DepartmentPolicy_Field from '@salesforce/schema/Case.Which_Department_s_Policy_Procedure__c';
import LMSCaseType_Field from '@salesforce/schema/Case.LMS_Case_Type__c';
import Departmentt__c_Field from '@salesforce/schema/Case.Departmentt__c'; 
import requestData_Field from '@salesforce/schema/Case.Request_Data_Columns__c';
import requestType_Field from '@salesforce/schema/Case.Request_type__c';
import requesInfo_Field from '@salesforce/schema/Case.Request_Information_for__c';
import frequency_Field from '@salesforce/schema/Case.Frequency__c';
import IncidentUser_Object from '@salesforce/schema/Involved_Party__c';
import RelationtoBakerRipley_Field from '@salesforce/schema/Involved_Party__c.Relation_to_BakerRipley__c';
import MemberRole_Field from '@salesforce/schema/Involved_Party__c.Member_Role__c';
import { loadStyle } from 'lightning/platformResourceLoader';
import COLORS from '@salesforce/resourceUrl/Colors';
import Location_Field from '@salesforce/schema/Case.Event_Incident_Location__c';
import AdministrationOfcName_Field from '@salesforce/schema/Case.Adminstrative_Office_Name__c';
import CommunityCenterName_Field from '@salesforce/schema/Case.Community_Center_Name__c';
import HeadStartCmpsName_Field from '@salesforce/schema/Case.Head_Start_Campus_Name__c';
import SeniorCenterName_Field from '@salesforce/schema/Case.Senior_Centre_Name__c';
import WorkforceCareerName_Field from '@salesforce/schema/Case.Workforce_Career_Office_Name__c';
import CharterSchoolName_Field from '@salesforce/schema/Case.Charter_School_Name__c';
import TuitionReimbursmentType_Field from '@salesforce/schema/Case.Tuition_Reimbursement_Type__c';
import COURSE_REQUIRED from '@salesforce/schema/Course__c.Course_Required__c';
import DEGREE_TYPE from '@salesforce/schema/Course__c.Degree_Type__c';
import THIS_COURSE_Will from '@salesforce/schema/Course__c.This_Course_Will__c';
import COURSE_OBJECT from "@salesforce/schema/Course__c";

import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
// const actions = [
//     { label: 'View', name: 'view' },
//     { label: 'Edit', name: 'edit' },
// ];
export default class PNCTypeChildPage extends NavigationMixin(LightningElement) {
    communityURL = window.location.origin+'/employeeservicesample/s/libraries';
    actions = [
        { label: 'Edit', name: 'edit' },
        { label: 'Delete', name: 'delete' },
    ];
    @track courseObj = {};
    degreeType;
    degreePlan;
    expectedGraducation;
    thisCourseWill;

    hrisCaseType = '';
    accommodationTypeValue='';
    benefitSubCategories ='';
    carValues;
    carColorValues;
    selectedCarValue = '';
    picklistValuesObj;
    selectedCarColorValue = '';
    isGrievence = false;
    @track locationOptions = [];
    @track adminisOfc = false;
    @track cmuntyCntr = false;
    @track workfrcCrr = false;
    @track nBrLctn = false;
    @track seniorCntr = false;
    @track headstrt = false;
    @track ChrtrSchol = false;
    @track reportingRequest = false;
    @track administrationOfcNameOptions = [];
    @track communityCenterNameOptions = [];
    @track headStartCmpsNameOptions = [];
    @track seniorCenterNameOptions = [];
    @track workforceCareerNameOptions = [];
    @track CharterSchoolNameOptions = [];
    @track TuitionReimbursmentTypeOption = [];
    addCourseModal = false;
    courseCheck = true;
    @track requestArray = [];
    @track columnArray = [];

    isLoaded = true;
    @track recordIds;
    isCssLoaded = false;
    graducationDate;
    firstClassDate;

    @api currentPage;
subBenefit = 'Critical Illness - Employee';
    @api caseObj = {};
    @api caseRecordTypeId;
    @track departmentOption = [];
    @track pncTypeoptions = [];
    @track accommodationTypeoptions = [];
    @track recruitmentReasonoptions = [];
    @track recruitmentCaseTypeoptions = [];
    @track thirdPartyStaffoptions = [];
    @track employeeManagTypeoptions = [];
    @track InquiryTypeoptions = [];
    @track hrisCaseTypeoptions = [];
    @track hrisSystemTypeoptions = [];
    @track hrisCaseAccessTypeoptions = [];
    @track trainingDevoptions = [];
    @track VirtualOrInPersonOptions = [];
    @track dataReportTypeOptions = [];
    @track typeofVerificationOptions = [];
    @track courseOutcomePickOptions = [];
    @track employeeReferralPickOptions = [];
    @track benefitsTypeOptions = [];
    @track PerformanceTypeOption = [];
    @track DepartmentPolicyOption = [];
    @track lmsCaseTypeOption = [];
    @track PaidTimeOffTypeOption = [];
    @track requestDataColumns = [];
    @track requestTypeColumns = [];
    @track requestInfoColumns = [];
    @track frequencyColumns = [];
    @track requestDataColumnsOptions = [];
    @track requestTypeOptions = [];
    @track frequencyOption = [];
    @track requestInformationForOption = [];

    @track benefitsType = false;
    @track accomodationType = false;
    @track recritmentType = false;
    @track compensationType = false;
    @track employeeManagType = false;
    @track InquiryType = false;
    @track grievancesCheck = false;
    @track hrInfoType = false;
    @track trainingDevType = false;
    @track jobFnc = false;
    @track trainingAndDevelopmentType = false;
    @track accessType = false;
    @track eParChangeEffectiveDate = false;
    @track dateReports = false;
    @track locationChangeRequest = false;
    @track timeAllocation = false;
    @track paidTimeOff = false;
    @track tuitionReimbursement = false;
    @track referralInformation = false;
    @track nonMedical = false;
    @track PerformanceManagement = false;
    @track PerformanceType = false;
    @track departmentPolicy = false;
    @track eParChangeEffectiveDateValue;
    @track canYouPerform = false;
    @track verificationCheck = false;
    @track lmsCaseType = false;
    @track performanceEssential = false;
    @track subCategory = false;
    @track preAutharization = false;
    @track reimbursementRequest = false;
    @track hrisSystemType = false;
    @track checkOtherColumn = false;
    @track checkOtherRequest = false;
    recordTypeName = 'People and Culture Related Case';
    @api courseInformation = [];
    @track handleChangeEventValue;
    @track handleChangeEventName;

    @track yesNoOptions = [
        { label: 'Yes', value: 'Yes' },
        { label: 'No', value: 'No' }
    ];

    //----------------------------------------------------------------------------
    @track controllerValuePNC;
    dependentDisabled = true;
    @track finalDependentVal = [];
    showdependent = false;
    dependentPicklist;
    //-----------------------------------------------------------------------------

    controllerValue;
    dependentValue;
    checkBoolean = false;
    //Dependent Picklist ------------------------------------------------------------------------------//

    handleIncidentLocation(event) {
        const fieldsToRemove = ['Adminstrative_Office_Name__c', 'Community_Center_Name__c', 'Head_Start_Campus_Name__c', 'Senior_Centre_Name__c', 'Workforce_Career_Office_Name__c', 'Non_BakerRipley_Location_Name__c', 'Charter_School_Name__c'];

        fieldsToRemove.forEach(fieldName => {
            console.log('199--> ' + JSON.stringify(this.caseObj));
            if (this.caseObj.hasOwnProperty(fieldName)) {
                delete this.caseObj[fieldName];
            }
        });
        this.caseObj.Event_Incident_Location__c = event.target.value;
        this.dependentIndentLocationName(event.target.value);
    }

    dependentIndentLocationName(targetname) {
        if (targetname == 'Administrative Office') {
            this.adminisOfc = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.adminisOfc;
        }
        else if (targetname == 'Community Center') {
            this.cmuntyCntr = true;
            this.adminisOfc = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.cmuntyCntr;
        }
        else if (targetname == 'Head Start Campus') {
            this.headstrt = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.adminisOfc = this.ChrtrSchol = !this.headstrt;
        }
        else if (targetname == 'Senior Center') {
            this.seniorCntr = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.adminisOfc = this.headstrt = this.ChrtrSchol = !this.seniorCntr;
        }
        else if (targetname == 'Workforce Career Office Name') {
            this.workfrcCrr = true;
            this.cmuntyCntr = this.adminisOfc = this.nBrLctn = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.workfrcCrr;
        }
        else if (targetname == 'Non-BakerRipley location') {
            this.nBrLctn = true;
            this.cmuntyCntr = this.workfrcCrr = this.adminisOfc = this.seniorCntr = this.headstrt = this.ChrtrSchol = !this.nBrLctn;
        }
        else if (targetname == 'Charter School') {
            this.ChrtrSchol = true;
            this.cmuntyCntr = this.workfrcCrr = this.nBrLctn = this.seniorCntr = this.headstrt = this.adminisOfc = !this.ChrtrSchol;
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: AdministrationOfcName_Field })
    administrationName({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.administrationOfcNameOptions = [...this.administrationOfcNameOptions, { value: val.value, label: val.label }];
            });
            console.log('this.administrationOfcNameOptions--> ' + JSON.stringify(this.administrationOfcNameOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: CommunityCenterName_Field })
    communitycenterName({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.communityCenterNameOptions = [...this.communityCenterNameOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: HeadStartCmpsName_Field })
    headStartCenterName({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.headStartCmpsNameOptions = [...this.headStartCmpsNameOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: SeniorCenterName_Field })
    seniorCenterCenterName({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.seniorCenterNameOptions = [...this.seniorCenterNameOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: WorkforceCareerName_Field })
    workforceCareerName({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.workforceCareerNameOptions = [...this.workforceCareerNameOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: CharterSchoolName_Field })
    charterSchoolName({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.CharterSchoolNameOptions = [...this.CharterSchoolNameOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: Location_Field })
    locationPickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.locationOptions = [...this.locationOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValuesByRecordType, { objectApiName: 'Case', recordTypeId: '$caseRecordTypeId' }) //'012DG000000EBlgYAG'
    newPicklistValues({ error, data }) {
        if (data) {
            this.error = null;
            this.picklistValuesObj = data.picklistFieldValues;
            let carValueslist = data.picklistFieldValues.Benefit_Type__c.values;
            let carValues = [];
            for (let i = 0; i < carValueslist.length; i++) {
                carValues.push({
                    label: carValueslist[i].label,
                    value: carValueslist[i].value
                });
            }
            this.carValues = carValues;
            if(this.picklistValuesObj ){
                this.carColorValues = this.handleCarChange(this.caseObj.Benefit_Type__c);
                this.isLoaded = true;
            }
             
        }
        else if (error) {
            this.error = JSON.stringify(error);
            console.log(JSON.stringify(error));
        }
    }

    handleCarChange(controllerValues) {
        this.selectedCarValue = controllerValues;
        this.caseObj.Benefit_Type__c = this.selectedCarValue;
        let carColorPicklists = [];
        if (this.selectedCarValue && this.picklistValuesObj) { //&& data.Benefit_Sub_Categories__c
            let data = this.picklistValuesObj;
            let totalCarColorValues = data.Benefit_Sub_Categories__c;
            let controllerValueIndex = totalCarColorValues.controllerValues[this.selectedCarValue];
            let colorPicklistValues = data.Benefit_Sub_Categories__c.values;
            
            colorPicklistValues.forEach(key => {
                for (let i = 0; i < key.validFor.length; i++) {
                    if (controllerValueIndex == key.validFor[i]) {
                        carColorPicklists.push({
                            label: key.label,
                            value: key.value
                        });
                    }
                }
            })
            console.log(' data carColorPicklists' + JSON.stringify(carColorPicklists));
            if (carColorPicklists && carColorPicklists.length > 0) {
                this.carColorValues = carColorPicklists;
            }
            this.controllFieldDependancy();
        }
        return carColorPicklists;
    }

    callFromChild(event) {
        this.controllerValue = event.detail.controllerValue;
        this.dependentValue = event.detail.dependentValue
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: requesInfo_Field })
    RequestInfoPickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.requestInfoColumns = [...this.requestInfoColumns, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: frequency_Field })
    FrequencyPickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.frequencyColumns = [...this.frequencyColumns, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: requestType_Field })
    RequestTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.requestTypeColumns = [...this.requestTypeColumns, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: requestData_Field })
    requestDataPickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.requestDataColumns = [...this.requestDataColumns, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: PNCType_Field })
    pncTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.pncTypeoptions = [...this.pncTypeoptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: AccommodationType_Field })
    accommodationTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.accommodationTypeoptions = [...this.accommodationTypeoptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: BenefitsType_Field })
    benefitsTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.benefitsTypeOptions = [...this.benefitsTypeOptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: ReasonRecruitment_Field })
    recruitmentReasonPickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.recruitmentReasonoptions = [...this.recruitmentReasonoptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: RecruitmentCaseType_Field })
    recruitmentCaseTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.recruitmentCaseTypeoptions = [...this.recruitmentCaseTypeoptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: ThirdPartyStaff_Field })
    thirdPartyStaffTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.thirdPartyStaffoptions = [...this.thirdPartyStaffoptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: EmployeeManagType_Field })
    employeeManagTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.employeeManagTypeoptions = [...this.employeeManagTypeoptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: InquiryType_Field })
    inquiryTypePickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.InquiryTypeoptions = [...this.InquiryTypeoptions, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: TrainingDevType_Field })
    trainingDevPickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.trainingDevoptions = [...this.trainingDevoptions, { value: val.value, label: val.label }];
            });
            //console.log('this.trainingDevoptions--> ' + JSON.stringify(this.trainingDevoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: HRISCaseType_Field })
    hrisCaseTypePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.hrisCaseTypeoptions = [...this.hrisCaseTypeoptions, { value: val.value, label: val.label }];
            });
            //console.log('this.hrisCaseTypeoptions--> ' + JSON.stringify(this.hrisCaseTypeoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: HRISSystemType_Field })
    hrisSystemTypePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.hrisSystemTypeoptions = [...this.hrisSystemTypeoptions, { value: val.value, label: val.label }];
            });
            //console.log('this.hrisSystemTypeoptions--> ' + JSON.stringify(this.hrisSystemTypeoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: HRISCaseAccessType_Field })
    hrisCaseAccessTypePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.hrisCaseAccessTypeoptions = [...this.hrisCaseAccessTypeoptions, { value: val.value, label: val.label }];
            });
            //console.log('this.hrisCaseAccessTypeoptions--> ' + JSON.stringify(this.hrisCaseAccessTypeoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: VirtualOrInPerson_Field })
    VirtualOrInPersonPickValues({ data, error }) {
        if (data) {
           // console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.VirtualOrInPersonOptions = [...this.VirtualOrInPersonOptions, { value: val.value, label: val.label }];
            });
            //console.log('this.VirtualOrInPersonOptions--> ' + JSON.stringify(this.VirtualOrInPersonOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: DataReportType_Field })
    DataReportTypePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.dataReportTypeOptions = [...this.dataReportTypeOptions, { value: val.value, label: val.label }];
            });
            //console.log('this.dataReportTypeOptions--> ' + JSON.stringify(this.dataReportTypeOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: CourseOutcome_Field })
    CourseOutcomePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.courseOutcomePickOptions = [...this.courseOutcomePickOptions, { value: val.value, label: val.label }];
            });
            //console.log('this.courseOutcomePickOptions--> ' + JSON.stringify(this.courseOutcomePickOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: EmployeeReferral_Field })
    EmployeeReferralPickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.employeeReferralPickOptions = [...this.employeeReferralPickOptions, { value: val.value, label: val.label }];
            });
            //console.log('this.employeeReferralPickOptions--> ' + JSON.stringify(this.employeeReferralPickOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: PerformanceType_Field })
    PerformanceTypePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.PerformanceTypeOption = [...this.PerformanceTypeOption, { value: val.value, label: val.label }];
            });
            //console.log('this.PerformanceTypeOption--> ' + JSON.stringify(this.PerformanceTypeOption));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: DepartmentPolicy_Field })
    DepartmentPolicyProcedurePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.DepartmentPolicyOption = [...this.DepartmentPolicyOption, { value: val.value, label: val.label }];
            });
            //console.log('this.DepartmentPolicyOption--> ' + JSON.stringify(this.DepartmentPolicyOption));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: LMSCaseType_Field })
    lmsCaseTypePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.lmsCaseTypeOption = [...this.lmsCaseTypeOption, { value: val.value, label: val.label }];
            });
            //console.log('this.lmsCaseTypeOption--> ' + JSON.stringify(this.lmsCaseTypeOption));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: TuitionReimbursmentType_Field })
    tuitionReimbursmentTypePickValues({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.TuitionReimbursmentTypeOption = [...this.TuitionReimbursmentTypeOption, { value: val.value, label: val.label }];
            });
            //console.log('this.TuitionReimbursmentTypeOption--> ' + JSON.stringify(this.TuitionReimbursmentTypeOption));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseRecordTypeId', fieldApiName: Departmentt__c_Field })
    departmenttPickValues({ data, error }) {
        if (data) {
            data.values.forEach(val => {
                this.departmentOption = [...this.departmentOption, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    connectedCallback() {
        try{
            this.isLoaded = false;
        console.log('sub-cat: -->'+ this.caseObj.Benefit_Sub_Categories__c);
            if(this.caseObj.Benefit_Sub_Categories__c){
            this.benefitSubCategories = this.caseObj.Benefit_Sub_Categories__c;
            }


        let obj = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj;
        let courInf = JSON.parse(JSON.stringify(this.courseInformation));
        console.log('courInf: '+(JSON.stringify(courInf))); 

        console.log('courInf.length -- : '+courInf);
        console.log('courInf.length: '+courInf.length);
        if(courInf.length > 0 ){
            console.log('check :');
            this.degreeType = courInf[0].Degree_Type__c;
            this.degreePlan = courInf[0].Degree_Plan__c;
            this.expectedGraducation = courInf[0].Expected_Graducation_Date__c;
            this.thisCourseWill = courInf[0].This_Course_Will__c;
            console.log('Course copy: '+this.degreeType+' : '+this.degreePlan+' : '+this.expectedGraducation+' : '+this.thisCourseWill);
        }        

        this.couseList = courInf;
        let counter = 1;
        this.couseList.forEach(el => {
            el.rowId = counter;
            counter++;
        })

        if (this.couseList.length > 0) {
            this.showCourseData = true
        } else {
            this.showCourseData = false;
        }

         this.controllFieldDependancy();
         //this.handleCourseChange();

        if (this.caseObj.hasOwnProperty('Request_Data_Columns__c')) {
            if (Array.isArray(this.caseObj.Request_Data_Columns__c)) {
                this.requestDataColumnsOptions = [...this.requestDataColumnsOptions, ...this.caseObj.Request_Data_Columns__c]
                this.checkOtherColumn = this.requestDataColumnsOptions.includes("Other");
            } else {
                if(this.requestDataColumnsOptions > 0){
                    this.requestDataColumnsOptions = [...this.requestDataColumnsOptions, ...this.caseObj.Request_Data_Columns__c.split(';')]
                    this.checkOtherColumn = this.requestDataColumnsOptions.includes("Other");
                }else{
                    if(this.caseObj.Request_Data_Columns__c){
                        this.requestDataColumnsOptions = this.caseObj.Request_Data_Columns__c.split(';');
                        this.checkOtherColumn = this.requestDataColumnsOptions.includes("Other");

                    }
                }
            }
        }

        if (this.caseObj.hasOwnProperty('Request_type__c')) {
            if (Array.isArray(this.caseObj.Request_type__c)) {
                this.requestTypeOptions = [...this.requestTypeOptions, ...this.caseObj.Request_type__c]
                this.checkOtherRequest = this.requestTypeOptions.includes("Others");
            } else {
                if(this.requestTypeOptions > 0){
                this.requestTypeOptions = [...this.requestTypeOptions, ...this.caseObj.Request_type__c.split(';')]
                this.checkOtherRequest = this.requestTypeOptions.includes("Others");
                }else{
                    if(this.caseObj.Request_type__c){
                        this.requestTypeOptions = this.caseObj.Request_type__c.split(';');
                        this.checkOtherRequest = this.requestTypeOptions.includes("Others");
                    }
                }                
            }
        }

        if (this.caseObj.hasOwnProperty('Request_Information_for__c')) {
            if (Array.isArray(this.caseObj.Request_Information_for__c)) {
                this.requestInformationForOption = [...this.requestInformationForOption, ...this.caseObj.Request_Information_for__c]
            } else {
                if(this.requestInformationForOption > 0){
                this.requestInformationForOption = [...this.requestInformationForOption, ...this.caseObj.Request_Information_for__c.split(';')]
                }else{
                    if(this.caseObj.Request_Information_for__c){
                        this.requestInformationForOption = this.caseObj.Request_Information_for__c.split(';');
                    }
                }
            }           
        }

        if (this.caseObj.hasOwnProperty('Frequency__c')) {
            if (Array.isArray(this.caseObj.Frequency__c)) {
                this.frequencyOption = [...this.frequencyOption, ...this.caseObj.Frequency__c]
            } else {
                if(this.frequencyOption > 0){
                this.frequencyOption = [...this.frequencyOption, ...this.caseObj.Frequency__c.split(';')]
                }else{
                    if(this.caseObj.Frequency__c){
                        this.frequencyOption = this.caseObj.Frequency__c.split(';');
                    }
                }
            }
        }
        
        /*if(this.caseObj.Frequency__c > 0){
            this.frequencyOption = Array.isArray(this.caseObj.Frequency__c);            
        }else{
            this.frequencyOption = this.caseObj.Frequency__c.split(';');
        }*/

        if (this.caseObj.hasOwnProperty('Event_Incident_Location__c')) {
            this.dependentIndentLocationName(this.caseObj.Event_Incident_Location__c);
        }
        if (this.isCssLoaded) return
        this.isCssLoaded = true;
        //console.log('=======>');
        loadStyle(this, COLORS).then(() => {
            console.log("Loaded Successfully")
        }).catch(error => {
            console.error("Error in loading the colors")
        });
               
        }catch(error){
            console.log('error=>'+JSON.stringify(error));
        }

    }

    handleChange(event) {        
        this.checkBoolean = event.target.checked;
        this.caseObj.Attestation__c = event.target.checked;

        this.handleChangeEventValue = event.target.value;
        this.handleChangeEventName = event.target.name;
        this.caseObj[event.target.name] = event.target.value;

        console.log('Handle change: '+event.target.value+' : '+event.target.name+' : '+event.target.label);

        console.log('this.caseObj: ', JSON.stringify(this.caseObj));


        if('Benefit_Sub_Categories__c' == event.target.name){
            this.caseObj.Benefit_Sub_Categories__c = event.target.value;
            console.log('sub cat values: '+ this.caseObj.Benefit_Sub_Categories__c);
        }

        if (this.caseObj.Benefit_Type__c == "Dental Insurance" || this.caseObj.Benefit_Type__c == 'Critical Illness Insurance' || this.caseObj.Benefit_Type__c == 'Dental Insurance' || this.caseObj.Benefit_Type__c == 'Disability' || this.caseObj.Benefit_Type__c == "Flexible Spending Account" || this.caseObj.Benefit_Type__c == 'Medical Insurance' || this.caseObj.Benefit_Type__c == 'Disability Insurance'){
            this.carColorValues = this.handleCarChange(this.caseObj.Benefit_Type__c);
        }
        this.controllFieldDependancy();
    }

    controllFieldDependancy() {  
        console.log('this.courseObj --> '+ JSON.stringify(this.courseObj));     
        //console.log('line 905--> '+ this.caseObj.P_C_Type__c === 'Benefits'); 
        if(this.caseObj.Attestation__c){
            console.log('Attestation: '+this.caseObj.Attestation__c);
            this.checkBoolean = this.caseObj.Attestation__c;
            this.caseObj.Attestation__c = this.caseObj.Attestation__c;
        }
        if (this.caseObj.Date_of_First_Class__c != '') {
            this.firstClassDate = new Date(this.caseObj.Date_of_First_Class__c);
            
            if(this.firstClassDate > this.graducationDate){
                this.caseObj.Date_of_First_Class__c = '';
                this.displayMessage("Error.", "error", "Expected Graduation Date should be always after Date of First Class");
            }
        } 

        if(this.handleChangeEventName  == 'Request_type__c'){
            this.requestArray = this.caseObj.Request_type__c;
            this.checkOtherRequest = this.requestArray.includes("Others");
        }

        if(this.handleChangeEventName  == 'Request_Data_Columns__c'){
            this.columnArray = this.caseObj.Request_Data_Columns__c;
            this.checkOtherColumn = this.columnArray.includes("Other");
        }

        
        /*if(!(this.checkOtherRequest)){
            this.caseObj.Other_Data_Columns__c = null;
        }

        if(!(this.checkOtherColumn)){
            this.caseObj.Other_Types__c = null;
        }*/

        if (this.courseObj.Degree_Type__c) { 
            this.degreeTypeValue = this.courseObj.Degree_Type__c;
        }

        if (this.courseObj.This_Course_Will__c) { 
            this.thisCourseWill = this.courseObj.This_Course_Will__c;
        }
        
        
        if (this.caseObj.P_C_Type__c == 'Accommodation') {            
            this.accomodationType = true;
            this.benefitsType = false;
            this.compensationType = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingDevType = false;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = false;
            this.subCategory = false;
            this.reportingRequest = false;
            this.hrInfoType = false;
            this.hrisSystemType = false;

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;

            this.caseObj.Benefit_Type__c = '';
            this.caseObj.Training_Development_Type__c = '';
            this.caseObj.Benefit_Sub_Categories__c = '';
            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Employee_Management_Type__c = '';
            this.caseObj.Performance_Type__c = '';
            this.caseObj.Inquiry_Type__c = '';
            this.caseObj.Tuition_Reimbursement_Type__c = '';
            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Retirement_Benefits__c = null;            

            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
            this.caseObj.LMS_Case_Type__c = null;

            this.caseObj.Access_Type__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Business_Purpose__c = null;
            //this.caseObj.Request_type__c = null;
            //this.caseObj.Request_Data_Columns__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Request_Information_for__c = null;
            //this.caseObj.Frequency__c = null;

            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Charter_School_Name__c = null;

            this.caseObj.Inquiry_Type__c = null;
            this.caseObj.Which_Department_s_Policy_Procedure__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Employee_Referral__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Referred_Dandidate_Position__c = null;        
            this.caseObj.Attestation__c = null;    
            this.caseObj.Inquiry_Type__c = null; 
            this.selectedCarValue = '';       
            this.hrisCaseType = '';

            this.caseObj.Old_Location_Address__c = ''; 
            this.caseObj.New_Location_Address__c = ''; 
            this.caseObj.Reason_For_Change__c = ''; 
            this.caseObj.Effective_Date__c = ''; 
        }
        if (this.caseObj.Accommodati_on_Type__c == 'Medical' || this.caseObj.Accommodati_on_Type__c == 'Non-Medical') {
            this.nonMedical = true;
            if(this.caseObj.Accommodati_on_Type__c = 'Medical'){
                this.accommodationTypeValue = 'Medical';
            }
            if(this.caseObj.Accommodati_on_Type__c = 'Non-Medical'){
                this.accommodationTypeValue = 'Non-Medical';
            }
            
            console.log('this.caseObj.Accommodati_on_Type__c: '+this.caseObj.Accommodati_on_Type__c+' : '+this.accommodationTypeValue);
        }
        if (this.caseObj.Able_to_Perform_Essential_Job_Functions__c == "Yes") {
            this.performanceEssential = true;
            //console.log('this.performanceEssential -- ');
        }
        if (this.caseObj.Able_to_Perform_Essential_Job_Functions__c == "No") {
            this.performanceEssential = false;
        }
        if (this.caseObj.P_C_Type__c == "Benefits") {             
            this.benefitsType = true;
            this.accomodationType = false;
            this.nonMedical = false;
            this.compensationType = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.hrInfoType = false;
            this.hrisSystemType = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingDevType = false;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = false;
            this.reportingRequest = false;
            this.performanceEssential = false;

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;

            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Able_to_Perform_Essential_Job_Functions__c = '';
            this.caseObj.Accommodati_on_Type__c = '';
            this.caseObj.Emergency_Contact_Email__c = '';
            this.caseObj.Emergency_Contact_Phone__c = '';
            this.caseObj.Emergency_Contact_Name__c = '';
            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Employee_Management_Type__c = '';
            this.caseObj.Performance_Type__c = '';
            this.caseObj.Inquiry_Type__c = '';
            this.caseObj.Training_Development_Type__c = '';
            this.caseObj.Tuition_Reimbursement_Type__c = '';
            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
            this.caseObj.LMS_Case_Type__c = null;            
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Business_Purpose__c = null;
            //this.caseObj.Request_type__c = null;
            //this.caseObj.Request_Data_Columns__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Request_Information_for__c = null;
            //this.caseObj.Frequency__c = null;
            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Charter_School_Name__c = null;
            this.caseObj.Which_Department_s_Policy_Procedure__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Employee_Referral__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Referred_Dandidate_Position__c = null;          
            this.caseObj.Attestation__c = null;
            this.caseObj.Retirement_Benefits__c = null;
            this.caseObj.Accommodati_on_Type__c = null;
            this.accommodationTypeValue = '';
            this.hrisCaseType = '';
            this.caseObj.Old_Location_Address__c = ''; 
            this.caseObj.New_Location_Address__c = ''; 
            this.caseObj.Reason_For_Change__c = ''; 
            this.caseObj.Effective_Date__c = ''; 
        }
        
        if (this.caseObj.P_C_Type__c == "Compensation") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.compensationType = true;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.hrInfoType = false;
            this.hrisSystemType = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingDevType = false;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = false;
            this.subCategory = false;
            this.reportingRequest = false;
            this.performanceEssential = false;

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;

            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
            this.caseObj.LMS_Case_Type__c = null;
            this.caseObj.Access_Type__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Business_Purpose__c = null;
            //this.caseObj.Request_type__c = null;
            //this.caseObj.Request_Data_Columns__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Request_Information_for__c = null;
            //this.caseObj.Frequency__c = null;
            this.caseObj.Employee_Management_Type__c = '';
            this.caseObj.Benefit_Type__c = '';
            this.caseObj.Benefit_Sub_Categories__c = '';
            this.caseObj.Performance_Type__c = '';
            this.caseObj.Inquiry_Type__c = '';
            this.caseObj.Training_Development_Type__c = '';
            this.caseObj.Tuition_Reimbursement_Type__c = '';
            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Charter_School_Name__c = null;
            this.caseObj.Which_Department_s_Policy_Procedure__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Employee_Referral__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Referred_Dandidate_Position__c = null;            
            this.caseObj.Attestation__c = null;
            this.caseObj.Accommodati_on_Type__c = null;
            this.accommodationTypeValue = null;
            this.caseObj.Able_to_Perform_Essential_Job_Functions__c = null;
            this.caseObj.Emergency_Contact_Name__c = null;
            this.caseObj.Emergency_Contact_Phone__c = null;
            this.caseObj.Emergency_Contact_Email__c = null;
            this.selectedCarValue = '';
            this.caseObj.Old_Location_Address__c = ''; 
            this.caseObj.New_Location_Address__c = ''; 
            this.caseObj.Reason_For_Change__c = ''; 
            this.caseObj.Effective_Date__c = ''; 
        }
        if (this.caseObj.Compensation_Type__c == "Tuition Reimbursement") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = true;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
           //this.retirementBenefits = false;
           console.log(' Boolean: '+this.caseObj.Attestation__c);
        }
        if (this.caseObj.Compensation_Type__c == "Referral Information") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = true;
            //this.retirementBenefits = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;
        }
        if (this.caseObj.P_C_Type__c == "Employee Management") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.employeeManagType = true;
            this.compensationType = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.hrInfoType = false;
            this.hrisSystemType = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingDevType = false;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = false;
            this.reportingRequest = false;
            this.performanceEssential = false;
            this.subCategory = false;

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;

            this.caseObj.Able_to_Perform_Essential_Job_Functions__c = '';
            this.caseObj.Accommodati_on_Type__c = '';
            this.caseObj.Emergency_Contact_Email__c = '';
            this.caseObj.Emergency_Contact_Phone__c = '';
            this.caseObj.Emergency_Contact_Name__c = '';
            this.caseObj.Benefit_Sub_Categories__c = '';
            this.caseObj.Benefit_Type__c = '';
            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Inquiry_Type__c = '';
            this.caseObj.Training_Development_Type__c = '';
            this.caseObj.Tuition_Reimbursement_Type__c = '';
            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Retirement_Benefits__c = null;
            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
            this.caseObj.LMS_Case_Type__c = null;
            this.caseObj.Access_Type__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Business_Purpose__c = null;
            //this.caseObj.Request_type__c = null;
            //this.caseObj.Request_Data_Columns__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Request_Information_for__c = null;
            //this.caseObj.Frequency__c = null;
            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Charter_School_Name__c = null;
            this.caseObj.Which_Department_s_Policy_Procedure__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Employee_Referral__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Referred_Dandidate_Position__c = null;            
            this.caseObj.Attestation__c = null;
            this.accommodationTypeValue = null;
            this.selectedCarValue = '';  
            this.hrisCaseType = '';
            this.caseObj.Old_Location_Address__c = ''; 
            this.caseObj.New_Location_Address__c = ''; 
            this.caseObj.Reason_For_Change__c = ''; 
            this.caseObj.Effective_Date__c = ''; 
        }
        if (this.caseObj.Employee_Management_Type__c == "Employee Performance") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = true;
            this.caseObj.Inquiry_Type__c = '';
        }
        if (this.caseObj.Performance_Type__c == "Corrective Plan" || this.caseObj.Performance_Type__c == "Bridge Plan") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceType = true;
            this.caseObj.Inquiry_Type__c = '';
        } else {
            this.PerformanceType = false;
        }
        if (this.caseObj.P_C_Type__c == "P&C General Inquires") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.InquiryType = true;
            this.hrInfoType = false;
            this.hrisSystemType = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingDevType = false;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = false;
            this.reportingRequest = false;
            this.performanceEssential = false;
            this.compensationType = false;
            this.subCategory = false;

            this.caseObj.Able_to_Perform_Essential_Job_Functions__c = '';
            this.caseObj.Accommodati_on_Type__c = '';
            this.caseObj.Emergency_Contact_Email__c = '';
            this.caseObj.Emergency_Contact_Phone__c = '';
            this.caseObj.Emergency_Contact_Name__c = '';
            this.caseObj.Benefit_Sub_Categories__c = '';
            this.caseObj.Benefit_Type__c = '';
            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Employee_Management_Type__c = '';
            this.caseObj.Training_Development_Type__c = '';
            this.caseObj.Performance_Type__c = '';
            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
            this.caseObj.LMS_Case_Type__c = null;          
            this.caseObj.Access_Type__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Business_Purpose__c = null;
            //this.caseObj.Request_type__c = null;
            //this.caseObj.Request_Data_Columns__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Request_Information_for__c = null;
            //this.caseObj.Frequency__c = null;
            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Charter_School_Name__c = null;
            this.caseObj.Retirement_Benefits__c = null;  
            this.accommodationTypeValue = null;    
            this.selectedCarValue = '';
            this.hrisCaseType = '';
            this.caseObj.Old_Location_Address__c = ''; 
            this.caseObj.New_Location_Address__c = ''; 
            this.caseObj.Reason_For_Change__c = ''; 
            this.caseObj.Effective_Date__c = ''; 
        } else {
            this.caseObj.Inquiry_Type__c = null;
        }
        if (this.caseObj.Inquiry_Type__c == "Policy") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = true;
            this.eParChangeEffectiveDate = false;          

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;  
        } else {
            this.departmentPolicy = false;
        }
        if (this.caseObj.P_C_Type__c == "Grievances") {
            //this.handlePNCChange(this.caseObj.P_C_Type__c);
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.hrInfoType = false;
            this.hrisSystemType = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingDevType = false;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = false;
            this.performanceEssential = false;
            this.compensationType = false;
            this.isGrievence = true;

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;

            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
            this.caseObj.LMS_Case_Type__c = null;
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Access_Type__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Business_Purpose__c = null;
            //this.caseObj.Request_type__c = null;
            //this.caseObj.Request_Data_Columns__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Request_Information_for__c = null;
            //this.caseObj.Frequency__c = null;
            this.caseObj.Retirement_Benefits__c = null;
            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.Training_Development_Type__c = '';
            this.caseObj.Able_to_Perform_Essential_Job_Functions__c = '';
            this.caseObj.Accommodati_on_Type__c = '';
            this.caseObj.Emergency_Contact_Email__c = '';
            this.caseObj.Emergency_Contact_Phone__c = '';
            this.caseObj.Emergency_Contact_Name__c = '';
            this.caseObj.Benefit_Sub_Categories__c = '';
            this.caseObj.Benefit_Type__c = '';
            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Employee_Management_Type__c = '';
            this.caseObj.Performance_Type__c = '';
            this.caseObj.Tuition_Reimbursement_Type__c = '';
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Inquiry_Type__c = null;
            this.caseObj.Which_Department_s_Policy_Procedure__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Employee_Referral__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Referred_Dandidate_Position__c = null;         
            this.caseObj.Attestation__c = null;    
            this.accommodationTypeValue = null;     
            this.selectedCarValue = '';     
            this.hrisCaseType = '';
            this.caseObj.Old_Location_Address__c = ''; 
            this.caseObj.New_Location_Address__c = ''; 
            this.caseObj.Reason_For_Change__c = ''; 
            this.caseObj.Effective_Date__c = ''; 
        } else {
            this.isGrievence = false;
            this.adminisOfc = false;
            this.cmuntyCntr = false;
            this.workfrcCrr = false;
            this.nBrLctn = false;
            this.seniorCntr = false;
            this.headstrt = false;
            this.ChrtrSchol = false;

            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Charter_School_Name__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;


        }
        if (this.caseObj.P_C_Type__c == "HR Information System") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.locationChangeRequest = false;
            this.hrInfoType = true;
            //this.accessType = false;
            this.eParChangeEffectiveDate = false;
            //this.dateReports = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingAndDevelopmentType = false;
            this.trainingDevType = false;
            this.lmsCaseType = false;
            this.performanceEssential = false;
            this.compensationType = false;
            this.subCategory = false;

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;

            this.caseObj.Training_Development_Type__c = '';
            this.caseObj.Able_to_Perform_Essential_Job_Functions__c = '';
            this.caseObj.Accommodati_on_Type__c = '';
            this.caseObj.Emergency_Contact_Email__c = '';
            this.caseObj.Emergency_Contact_Phone__c = '';
            this.caseObj.Emergency_Contact_Name__c = '';
            this.caseObj.Benefit_Sub_Categories__c = '';
            this.caseObj.Benefit_Type__c = '';
            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Employee_Management_Type__c = '';
            this.caseObj.Performance_Type__c = '';
            this.caseObj.Inquiry_Type__c = '';
            this.caseObj.Tuition_Reimbursement_Type__c = '';
        
            this.caseObj.Retirement_Benefits__c = null;
            this.caseObj.Which_Department_s_Policy_Procedure__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Employee_Referral__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Referred_Dandidate_Position__c = null;           
            this.caseObj.Attestation__c = null;
            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Charter_School_Name__c = null;
            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
            this.caseObj.LMS_Case_Type__c = null; 
            this.accommodationTypeValue = null;
            this.selectedCarValue = '';
        } else {
            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
        }
        if (this.caseObj.HRIS_Case_Type__c == "Access") {
            this.hrisCaseType = "Access";
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = true;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.reportingRequest = false;

            //this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Business_Purpose__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Old_Location_Address__c = null;
            this.caseObj.New_Location_Address__c = null;
            this.caseObj.Reason_For_Change__c = null;
            this.caseObj.Effective_Date__c = null;
        }
        if (this.caseObj.HRIS_System_Type__c == "UKG") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.hrisSystemType = true;
            this.eParChangeEffectiveDate = false;
            //this.dateReports = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            //this.reportingRequest = false;

            //this.caseObj.HRIS_Case_Type__c = null;
            //this.caseObj.Data_Report_Type__c = null;
        } else {
            this.hrisSystemType = false;
        }

        if (this.caseObj.HRIS_Case_Type__c == "Data & Reports") {
            this.hrisCaseType = "Data & Reports";
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = true;
            this.locationChangeRequest = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;

            this.caseObj.Access_Type__c = null;
            this.caseObj.Old_Location_Address__c = null;
            this.caseObj.New_Location_Address__c = null;
            this.caseObj.Reason_For_Change__c = null;
            this.caseObj.Effective_Date__c = null;
        }

        if (this.caseObj.HRIS_Case_Type__c == "Location Change Request") {
            this.hrisCaseType = "Location Change Request";
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.accessType = false;
            this.locationChangeRequest = true;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;

            this.caseObj.Access_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Business_Purpose__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
        }
        
        if (this.caseObj.P_C_Type__c == "Training and Development") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingDevType = true;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = false;
            this.subCategory = false;
            this.hrInfoType = false;
            this.hrisSystemType = false;
            this.reportingRequest = false;
            this.performanceEssential = false;
            this.compensationType = false;

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;
            this.locationChangeRequest = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;

            this.caseObj.HRIS_Case_Type__c = null;
            this.caseObj.Data_Report_Type__c = null;
            this.caseObj.Able_to_Perform_Essential_Job_Functions__c = '';
            this.caseObj.Accommodati_on_Type__c = '';
            this.caseObj.Emergency_Contact_Email__c = '';
            this.caseObj.Emergency_Contact_Phone__c = '';
            this.caseObj.Emergency_Contact_Name__c = '';
            this.caseObj.Benefit_Sub_Categories__c = '';
            this.caseObj.Benefit_Type__c = '';
            this.caseObj.Compensation_Type__c = '';
            this.caseObj.Employee_Management_Type__c = '';
            this.caseObj.Performance_Type__c = '';
            this.caseObj.Inquiry_Type__c = '';
            this.caseObj.Tuition_Reimbursement_Type__c = '';
            this.caseObj.HRIS_System_Type__c = null;
            this.caseObj.Retirement_Benefits__c = null;

            this.caseObj.Which_Department_s_Policy_Procedure__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Employee_Referral__c = null;
            this.caseObj.Departmentt__c = null;
            this.caseObj.Referred_Dandidate_Position__c = null;            
            this.caseObj.Attestation__c = null;
            this.caseObj.Event_Incident_Location__c = null;
            this.caseObj.Adminstrative_Office_Name__c = null;
            this.caseObj.Incident_Date_Time__c = null;
            this.caseObj.Nature_of_Grievance__c = null;
            this.caseObj.Account_of_Event_s__c = null;
            this.caseObj.Community_Center_Name__c = null;
            this.caseObj.Head_Start_Campus_Name__c = null;
            this.caseObj.Senior_Centre_Name__c = null;
            this.caseObj.Workforce_Career_Office_Name__c = null;
            this.caseObj.Non_BakerRipley_Location_Name__c = null;
            this.caseObj.Charter_School_Name__c = null;
            this.caseObj.Access_Type__c = null;
            this.caseObj.Effective_Date__c = null;
            this.caseObj.Date_Needed__c = null;
            this.caseObj.Business_Purpose__c = null;
            //this.caseObj.Request_type__c = null;
            //this.caseObj.Request_Data_Columns__c = null;
            this.caseObj.Other_Data_Columns__c = null;
            this.caseObj.Other_Types__c = null;
            this.caseObj.Request_Information_for__c = null;
            //this.caseObj.Frequency__c = null;   
            this.accommodationTypeValue = null;   
            this.selectedCarValue = '';    
            this.hrisCaseType = '';
            this.caseObj.Old_Location_Address__c = ''; 
            this.caseObj.New_Location_Address__c = ''; 
            this.caseObj.Reason_For_Change__c = ''; 
            this.caseObj.Effective_Date__c = ''; 
        }
        if (this.caseObj.Training_Development_Type__c == "Training Request") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingAndDevelopmentType = true;
            this.lmsCaseType = false;
            this.caseObj.LMS_Case_Type__c = null;
        }
        if (this.caseObj.Training_Development_Type__c == "Learning Management System(LMS)") {
            this.benefitsType = false;
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingAndDevelopmentType = false;
            this.lmsCaseType = true;

            this.caseObj.Number_of_Employee_receiving_training__c = null;
            this.caseObj.Virtual_or_In_Person__c = null;
            this.caseObj.Propose_Date_of_Training__c = null;
            this.caseObj.Training_Subject_Topic__c = null;
            this.caseObj.Objectives__c = null;
            this.caseObj.Problem_Opportunity_Statement__c = null;
            this.caseObj.Desired_Outcome_s__c = null;
        }
        
        if (this.caseObj.Benefit_Type__c == "Dental Insurance" || this.caseObj.Benefit_Type__c == 'Critical Illness Insurance' || this.caseObj.Benefit_Type__c == 'Dental Insurance' || this.caseObj.Benefit_Type__c == 'Disability' || this.caseObj.Benefit_Type__c == "Flexible Spending Account" || this.caseObj.Benefit_Type__c == 'Medical Insurance' || this.caseObj.Benefit_Type__c == 'Disability Insurance') {
            console.log('this.caseObj.Benefit_Type__c -- ' + this.caseObj.Benefit_Type__c);
            //this.carColorValues = this.handleCarChange(this.caseObj.Benefit_Type__c);
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.dateReports = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingAndDevelopmentType = false;

            if(this.picklistValuesObj){
                this.subCategory = true;
                //this.caseObj.Benefit_Sub_Categories__c;// = this.benefitSubCategories;
                //console.log('this.benefitSubCategories: '+this.caseObj.Benefit_Sub_Categories__c+' -- ' +this.benefitSubCategories);
            }
            
        } else {
            this.subCategory = false;
        }

        if (this.caseObj.Data_Report_Type__c == "Reporting Request") {
            this.accomodationType = false;
            this.nonMedical = false;
            this.tuitionReimbursement = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
            this.referralInformation = false;
            //this.retirementBenefits = false;
            this.PerformanceManagement = false;
            this.PerformanceType = false;
            this.employeeManagType = false;
            this.departmentPolicy = false;
            this.InquiryType = false;
            this.departmentPolicy = false;
            this.accessType = false;
            this.eParChangeEffectiveDate = false;
            this.timeAllocation = false;
            this.paidTimeOff = false;
            this.verificationCheck = false;
            this.trainingAndDevelopmentType = false;
            //this.subCategory = false;
            this.reportingRequest = true;
        } else {
            this.reportingRequest = false;
            //this.caseObj.HRIS_Case_Type__c = null;
            //this.caseObj.Data_Report_Type__c = null;
        }

        if (this.caseObj.Inquiry_Type__c == "Referral Information") {
            this.referralInformation = true;
            this.preAutharization = false;       

            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;     
        } else {
            this.referralInformation = false;
            this.caseObj.Employee_Referral__c = '';
            this.caseObj.Departmentt__c = '';
            this.caseObj.Referred_Candidate_Position__c ='';
        }

        if (this.caseObj.Inquiry_Type__c == "Tuition Reimbursement") {
            this.tuitionReimbursement = true;         
        } else {
            this.tuitionReimbursement = false;
            //this.preAutharization = false;
            this.reimbursementRequest = false;             
        }

        if (this.caseObj.Inquiry_Type__c != "Tuition Reimbursement") {
            this.caseObj.Tuition_Reimbursement_Type__c = '';
        }

        if (this.caseObj.Inquiry_Type__c == "Recruiting") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;        }
        if (this.caseObj.Inquiry_Type__c == "Onboarding") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;        }
        if (this.caseObj.Inquiry_Type__c == "Offboarding") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;        }
        if (this.caseObj.Inquiry_Type__c == "Internal Jobs") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;        }
        if (this.caseObj.Inquiry_Type__c == "Interns") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;        }
        if (this.caseObj.Inquiry_Type__c == "PAR") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;        }
        if (this.caseObj.Inquiry_Type__c == "Directory") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;        }
        if (this.caseObj.Inquiry_Type__c == "Compensation Verification") {
            this.thisCourseWill = '';
            this.degreeType ='';
            this.degreePlan ='';
            this.expectedGraducation ='';
            this.couseList = [];
            this.courseObj ={};
            this.showCourseData = false;

            this.caseObj.Name_of_School_Institution__c = null;
            this.caseObj.Semester__c = null;
            this.caseObj.Date_of_First_Class__c = null;
            this.caseObj.Institution_s_Address__c = null;
            this.caseObj.Institution_s_City__c = null;
            this.caseObj.Institution_s_State__c = null;
            this.caseObj.Institution_s_Zip_code__c = null;
            this.caseObj.Institution_s_Phone__c = null;
        }

        if (this.caseObj.P_C_Type__c != "General Inquires" && this.caseObj.Inquiry_Type__c != "Tuition Reimbursement" && this.caseObj.Inquiry_Type__c != "Referral Information") {
            this.tuitionReimbursement = false;
            this.referralInformation = false;
            this.preAutharization = false;
            this.reimbursementRequest = false;
        }
        if (this.caseObj.Tuition_Reimbursement_Type__c == "Pre-Authorization") {
            this.preAutharization = true;
            this.reimbursementRequest = false;
            this.referralInformation = false;
        }
        if (this.caseObj.Tuition_Reimbursement_Type__c == "Reimbursement Request") {
            this.reimbursementRequest = true;
            this.preAutharization = true;
            this.referralInformation = false;
        }
    }

    isUSAZipCode(str) {
        return /^\d{5}(-\d{4})?$/.test(str);
    }

    @api
    handleNext() {
        console.log('@in this here-------for pnc--->>>>>>>>>>>>>>>>>>')
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDBValid = [...this.template.querySelectorAll("lightning-dual-listbox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDLValid = [...this.template.querySelectorAll("lightning-textarea")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if(this.caseObj.P_C_Type__c == 'P&C General Inquires' && this.caseObj.Inquiry_Type__c == 'Tuition Reimbursement' && this.couseList.length == 0){
            this.courseCheck = false;
        }else{
            this.courseCheck = true;
        }

        if (allValid && allCBValid && allDBValid && allDLValid && this.courseCheck) {         
            console.log('this.caseObj before save and next', JSON.stringify(this.caseObj));
            if(this.caseObj.P_C_Type__c == 'Accommodation') {
                if(this.validateEmail(this.caseObj.Emergency_Contact_Email__c)) {
                    this.dispatchEvent(new CustomEvent('updatedataa', {
                        detail: {
                            caseObj: this.caseObj,
                            incidentList: [],
                            courseData: this.couseList
                        }
                    }));
                } else {
                    this.displayMessage("Add Email!", "error", "Please add email in correct format. ex: abc@gmail.com");
                }
            } else if(this.caseObj.P_C_Type__c == 'P&C General Inquires' && this.caseObj.Inquiry_Type__c == 'Tuition Reimbursement') {
                if(this.isUSAZipCode(this.caseObj.Institution_s_Zip_code__c)) {
                    this.dispatchEvent(new CustomEvent('updatedataa', {
                        detail: {
                            caseObj: this.caseObj,
                            incidentList: [],
                            courseData: this.couseList
                        }
                    }));
                } else {
                    this.displayMessage("Add Zip Code!", "error", "Please put zip code as number and of 5 digits.");
                }
            } else {
                this.dispatchEvent(new CustomEvent('updatedataa', {
                    detail: {
                        caseObj: this.caseObj,
                        incidentList: [],
                        courseData: this.couseList
                    }
                })); 
            }

        } else {
            if(!this.courseCheck){
                this.displayMessage("Add Course!", "error", "Please add atleast one course record to proceed");                
            }else{
                this.displayMessage("Please check your entries.", "error", "Please fill required fields");
            }       
             }
    }

    validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    @api
    handleSaveAndExit() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDBValid = [...this.template.querySelectorAll("lightning-dual-listbox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allDLValid = [...this.template.querySelectorAll("lightning-textarea")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if(this.caseObj.P_C_Type__c == 'P&C General Inquires' && this.caseObj.Inquiry_Type__c == 'Tuition Reimbursement' && this.couseList.length == 0){
            this.courseCheck = false;
        }else{
            this.courseCheck = true;
        }

        if (allValid && allCBValid && allDBValid && allDLValid && this.courseCheck) {
            console.log('this.currentPage->' + this.currentPage);
            this.isLoaded = false;
            this.caseObj.Status = 'Draft';
            this.caseObj.CurrentPage__c = this.currentPage;
            console.log('caseobj data---subject---> ' , this.caseObj.Subject)
            let courseData = JSON.parse(JSON.stringify(this.couseList));
            courseData.forEach(Obj => {
                if (Obj.hasOwnProperty('rowId')) {
                    delete Obj.rowId;
                }
                console.log('obj->' + JSON.stringify(Obj));
            });
            console.log('damageData->' + JSON.stringify(courseData));
            if(this.caseObj.P_C_Type__c == 'P&C General Inquires' && this.caseObj.Inquiry_Type__c == 'Tuition Reimbursement') {
                if(this.isUSAZipCode(this.caseObj.Institution_s_Zip_code__c)) {
                    createCaseOnSubmit({
                        caseObj: this.caseObj,
                        fileData: [],
                        incidentUserList: [],
                        recordTypeName: this.recordTypeName,
                        injuryData: [],
                        damageData: [],
                        courseInformation: courseData
                    }).then(result => {
                        if (result) {
                            this.isLoaded = true;
                            console.log('P&C 852 ----> ' + result);
                            this.displayMessage("Success", "success", "Case record updated successfully.");
                            this[NavigationMixin.Navigate]({
                                "type": "standard__webPage",
                                "attributes": {
                                    "url": "/employeeservicesample/s/casehomepage"
                                }
                            });
                        }
                    }).catch(error => {
                        this.isLoaded = true;
                        console.log('HRIS: '+JSON.stringify(error));
                        this.displayMessage("Error", "error", JSON.stringify(error));                    
                    })
                } else {
                    this.displayMessage("Add Zip Code!", "error", "Please put zip code as number and of 5 digits.");
                }
            } else {
                createCaseOnSubmit({
                    caseObj: this.caseObj,
                    fileData: [],
                    incidentUserList: [],
                    recordTypeName: this.recordTypeName,
                    injuryData: [],
                    damageData: [],
                    courseInformation: courseData
                }).then(result => {
                    if (result) {
                        this.isLoaded = true;
                        console.log('P&C 852 ----> ' + result);
                        this.displayMessage("Success", "success", "Case record updated successfully.");
                        this[NavigationMixin.Navigate]({
                            "type": "standard__webPage",
                            "attributes": {
                                "url": "/employeeservicesample/s/casehomepage"
                            }
                        });
                    }
                }).catch(error => {
                    this.isLoaded = true;
                    console.log('HRIS: '+JSON.stringify(error));
                    this.displayMessage("Error", "error", JSON.stringify(error));                    
                })
            }
        } else {
            if(!this.courseCheck){
                this.displayMessage("Add Course!", "error", "Please add atleast one course record to proceed");                
            }else{
                this.displayMessage("Please check your entries.", "error", "Please fill required fields");
            }         
            }

    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }

    //@track degreePlanOptions = [];
    @track thisCourseOptions = [];
    @track degreeTypeOptions = [];
    @track courseRequiredOptions = [];
    @track couseList = [];
    showCourseData = false;

    addCourseInformation() {
        this.addCourseModal = true;
    }

    closeCourseModal() {
        this.addCourseModal = false;
    }

    addCourseRecord() {
        let allValid = true;
        allValid = [...this.template.querySelectorAll('.isValid')].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if (allValid) {
            let obj = JSON.parse(JSON.stringify(this.courseObj));
            this.couseList = [...this.couseList, obj];
            console.log('number:::', this.couseList.length);
            if (this.couseList.length > 0) {
                let counter = 1;
                this.couseList.forEach(el => {
                    el.rowId = counter;
                    counter++;
                })
                this.showCourseData = true;
            }
            console.log('this.couseList', JSON.stringify(this.couseList));
            this.addCourseModal = false;
            //this.courseObj = {};
            this.courseObj.Credit_Hours__c = null;
            this.courseObj.Course_Number__c = null;
            this.courseObj.Name = null;
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }
    }

    handleEditSave() {
        let allValid = true;
        allValid = [...this.template.querySelectorAll('.isValid')].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);

        if (allValid) {
            // let obj = JSON.parse(JSON.stringify(this.courseObj));
            // this.couseList = [...this.couseList, obj];
            // console.log('number:::', this.couseList.length);
            const i = this.couseList.findIndex(x => x.rowId === this.courseObj.rowId)
            this.couseList[i] = this.courseObj
            this.couseList.map(obj => this.courseObj.rowId === obj.rowId || obj);
            this.couseList = [...this.couseList];
            if (this.couseList.length > 0) {
                this.showDataTable = true;
                this.isEdit = false;
            }
            console.log('this.couseList', JSON.stringify(this.couseList));
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }
    }

    handleEditModalClose() {
        this.isEdit = false
        this.showCourseData = true
    }

    handleCourseChange(event) {

        if (event.target.name == 'Expected_Graducation_Date__c') {
            this.graducationDate = new Date(event.target.value);
            this.firstClassDate = new Date(this.caseObj.Date_of_First_Class__c);
            console.log('Course date: '+this.firstClassDate+ ' : '+this.graducationDate);
            if (this.firstClassDate > this.graducationDate) {
                this.displayMessage("Error.", "error", "Expected Graduation Date should be always after Date of First Class");
                event.target.value = '';
            } else {
                this.courseObj[event.target.name] = event.target.value;
                console.log('this.courseObj[event.target.name] - 1');
            }
        } else {
            this.courseObj[event.target.name] = event.target.value;
            console.log('this.courseObj[event.target.name] - 2');
        }
        this.courseObj[event.target.name] = event.target.value;
        console.log('this.courseObj', JSON.stringify(this.courseObj));   
    }

    @wire(getObjectInfo, { objectApiName: COURSE_OBJECT })
    courseInfoData;

    @wire(getPicklistValues, { recordTypeId: "$courseInfoData.data.defaultRecordTypeId", fieldApiName: COURSE_REQUIRED })
    courseRq({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.courseRequiredOptions = [...this.courseRequiredOptions, { value: val.value, label: val.label }];
            });
           // console.log('this.courseRequiredOptions--> ' + JSON.stringify(this.courseRequiredOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }


    @wire(getPicklistValues, { recordTypeId: "$courseInfoData.data.defaultRecordTypeId", fieldApiName: DEGREE_TYPE })
    degreeType({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.degreeTypeOptions = [...this.degreeTypeOptions, { value: val.value, label: val.label }];
            });
            //console.log('this.degreeTypeOptions--> ' + JSON.stringify(this.degreeTypeOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: "$courseInfoData.data.defaultRecordTypeId", fieldApiName: THIS_COURSE_Will })
    thisCourse({ data, error }) {
        if (data) {
            //console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.thisCourseOptions = [...this.thisCourseOptions, { value: val.value, label: val.label }];
            });
            //console.log('this.thisCourseOptions--> ' + JSON.stringify(this.thisCourseOptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    isEdit = false

    @track columnsList = [{
        label: "Course Title", fieldName: "Name", cellAttributes: {
            class: { fieldName: 'accountColor' }, alignment: 'center'
        }
    },
    {
        label: "Course Number", fieldName: "Course_Number__c", cellAttributes: {
            class: { fieldName: 'amountColor' },
            iconName: { fieldName: 'iconName' }, iconPosition: 'right', alignment: 'center'
        }
    },
    {
        label: "Credit Hours", fieldName: "Credit_Hours__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    /*{
        label: "Degree Plan", fieldName: "Degree_Plan__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },*/
    {
        label: "Course is part of my degree program", fieldName: "Course_Required__c", cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    { 
        type : 'action', initialWidth:100,
        typeAttributes:{rowActions:this.actions},
        cellAttributes: {
            class: { fieldName: 'industryColor' }, alignment: 'center'
        }
    },
    ];

    handleRowAction(event) {
        const action = event.detail.action;
        const rowss = event.detail.row;

        switch (action.name) {
            case 'edit':
                this.isEdit = true;
                this.courseObj = rowss
                break;
            case 'delete':
                this.couseList = this.couseList?.filter(data => data.rowId !== event.detail.row.rowId);
                const row = event.detail.row.rowId;
                if (this.couseList.length < 1) {
                    this.showCourseData = false;
                }
                break;
        }


        
        console.log('selected row:: ' + row);
        console.log('this.couseList', JSON.stringify(this.couseList));
    }
}