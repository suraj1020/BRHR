import { LightningElement, wire, track } from 'lwc';
import uId from '@salesforce/user/Id';
import getEmployeeData from '@salesforce/apex/TrainingController.getEmployeeData';
import getPath from '@salesforce/apex/LearningPathController.getLearningPath';
import getLearningPathTrainings from '@salesforce/apex/LearningPathController.getLearningPathTrainings';
import createRecordEmployeeWithLearning from '@salesforce/apex/LearningPathController.createRecordEmployeeWithLearning';
import updateLearningPathStatus from '@salesforce/apex/LearningPathController.updateLearningPathStatus';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { refreshApex } from '@salesforce/apex';
//import { reduceErrors } from 'c/ldsUtils';
export default class UapAvailableTrainingProgram extends LightningElement {
    @track wiredData = [];
    @track pathData = [];
    @track learningPathTrainingData = [];
    userId = uId;
    empId = '';
    isLoading = true;
    showMessage = false;
    msg = '';
    empProfile = '';
    highFlag = '/img/samples/flag_red.gif';
    mediumFlag = '/img/samples/flag_yellow.gif';
    lowFlag = '/img/samples/flag_green.gif';
    @track isModalOpen = false;
    @track filteredData = [];
    value = '-- None --';
    placeholder;
    fieldLabel;
    searchTermType;

    /******************************* Get Employee Data ************************************/
    constructor() {
        super();
        updateLearningPathStatus();
        console.log('constructor called learning path..');
    }

    connectedCallback() {
        // This doesn't work
        console.log('connectedCallback called learning path..');
    }

    @wire(getEmployeeData, { userId: '$userId' })
    getEmployee({ error, data }) {
        if (data) {
            if (data.length > 0) {
                this.empId = data[0].Id;
                this.empProfile = data[0].JobProfile;
                if (this.empProfile == undefined || this.empProfile == '') {
                    this.showMessage = true;
                    this.msg = `You don't have any Learning Path`
                    this.isLoading = false;
                }
            } else {
                this.msg = `No Employee found for your user`
                this.isLoading = false;
            }
        }
        if (error) {
            console.log('error', error);

        }
    }


    /**************************Get Learning Path **************************************/
    @wire(getPath, { empId: '$empId', jobProfile: '$empProfile' })
    lPath(result) {
        this.wiredData = result;
        if (result.data) {
            if (result.data.length > 0) {
                this.pathData = result.data;
                this.filteredData = result.data;
                this.showMessage = false;
                console.log('Learning Path ------ ' + this.pathData);
            }
            else {
                this.msg = `You don't have any Learning Path`;
                this.showMessage = true;
            }
            this.isLoading = false;
        } if (result.error) {
            console.log('error', result.error);
            this.isLoading = false;
        }
    }

    get options() {
        return [
            { label: '-- None --', value: '' },
            { label: 'Type', value: 'Type__c' }
        ];
    }

    handleChange(event) {
        this.value = event.detail.value;
        if (this.value == '' || this.value == null) {
            this.fieldLabel = null;
            this.placeholder = null;
        }
        else {
            if (this.searchTermType != undefined) {
                this.findRecords(this.searchTermType);
            }
            this.fieldLabel = this.value == 'Name' ? 'Learning Path Name' : 'Learning Path Type';
            this.placeholder = this.value == 'Name' ? 'Please search with Learning Path name' : 'Please search with Learning Path type';
        }
    }
    /**************************Handling Search based on Name and Type************************ */
    handleSearchType(event) {
        this.findRecords(event.target.value);
    }

    findRecords(searchString) {
        this.searchTermType = searchString.toLowerCase();

        // Filter the data based on the description
        if (this.value == 'Type__c') {
            this.pathData = this.filteredData.filter(item =>
                item.TrainingType.toLowerCase().includes(this.searchTermType)
            );
        }
        if (this.value == 'Name' || this.value=='' || this.value == null) {
            console.log('--- Learning Path Name filter in progress...');
            this.pathData = this.filteredData.filter(item =>
                item.TrainingName.toLowerCase().includes(this.searchTermType)
            );
            console.log('--- Name: ' + JSON.stringify(this.pathData));
        }

        // Show/hide the message based on whether there are results
        this.showMessage = this.filteredData.length == 0;
    }

    displayLearningPathTrainings(event) {
        this.isModalOpen = true;
        console.log('selectedRows ..' + event.target.dataset.id + ' -- ' + this.empId);

        getLearningPathTrainings({ learningPathId: event.target.dataset.id, employeeId: this.empId })
            .then(res => {
                this.learningPathTrainingData = res;
            })
            .catch(error => {
                this.displayMessage('Error Occured', 'error', error)

            });
    }

    closeModal() {
        this.isModalOpen = false;
    }

    enrollLearningPath(event) {
        let index = event.target.dataset.index;
        let learningPathData = JSON.parse(JSON.stringify(this.pathData));
        learningPathData[index].isEnrolled = true;
        this.pathData = learningPathData;

        let learningPathId = event.target.dataset.id;
        console.log('enrollLearningPath -- ' + learningPathId + ' -- ' + this.empId);
        createRecordEmployeeWithLearning({ learningPathId: learningPathId, employeeId: this.empId })
            .then(res => {
                this.displayMessage('Enrolled Succesfully', 'success', 'You have enrolled to this learning path succesfully');
                console.log('Learning path Refresh Called.. ');
                refreshApex(this.wiredData);
                this.template.querySelector('c-my-assigned-training').learningPathRefresh();
            })
            .catch(error => {
                this.displayMessage('Error Occured', 'error', error)
            })
    }

    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }
}