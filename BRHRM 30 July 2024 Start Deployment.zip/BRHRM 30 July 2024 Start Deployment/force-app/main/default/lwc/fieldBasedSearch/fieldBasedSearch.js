import { LightningElement, api } from 'lwc';
import priorityLabel from '@salesforce/label/c.fieldBasedSearch_Priority';
import statusLabel from '@salesforce/label/c.fieldBasedSearch_Status';
import statusLabelforEnrolledTrainingTab from '@salesforce/label/c.fieldBasedSearch_Status_for_My_Enrollred_Training_Tab';
import statusLabelforEnrolledTrainingTabTrainings from '@salesforce/label/c.fieldBasedSearch_Status_for_My_Enrollred_Training_Tab_Trainings';
import completedTraingPathTypeLabel from '@salesforce/label/c.fieldBasedSearch_Type';

import completedTraingTypeLabel from '@salesforce/label/c.fieldBasedSearch_CompletedTrainings_Type';
import { ShowToastEvent } from "lightning/platformShowToastEvent";


export default class FieldBasedSearch extends LightningElement {
    // isAvailablelearningtraining=false;
    includeEnrolledType = false;
    @api searchData;
    @api eventMethod = '';
    @api tabName = '';
    @api fieldcss;
    isDateFilter = false;
    isPicklistFilter = false;
    isInputFilter = false;
    enrolledTypes = [];
    filterFields = [];
    selectedEnrolledType = '';
    selectedField = '';
    searchOptionsToDisplay = [];
    searchValue = '';
    hideSearchvalues = false;

    connectedCallback() {
        this.tabName == [];

        if (this.tabName == 'completedTaining') {
            this.enrolledTypes = [
                { label: 'Completed Trainings', value: 'Completed Trainings' },
                { label: 'Completed Learning paths', value: 'Completed Learning paths' },                
            ];
            this.includeEnrolledType = true;
            this.handleEnrolledType({target:{value:'Completed Trainings'}});
            //this.isAvailablelearningtraining=false;
        } else if (this.tabName == 'assignedTaining') {
            this.enrolledTypes = [
                { label: 'Trainings', value: 'Trainings' },
                { label: 'Learning Paths', value: 'Learning Paths' },
            ];
            this.includeEnrolledType = true;
            this.handleEnrolledType({target:{value:'Trainings'}});
            //this.isAvailablelearningtraining=false;
        } else if (this.tabName == 'availableTraining' || this.tabName == 'learningPath' || this.tabName == 'completedTaining') {
            this.filterFields = [
                { label: 'Name', value: 'TrainingName' },
                { label: 'Type', value: 'TrainingType' },
                { label: 'Priority', value: 'Priority' },
                //{ label: 'Status', value: 'Status' },
                { label: 'Date', value: 'DueDate' },
            ];
            this.includeEnrolledType = false;
            // this.isAvailablelearningtraining=true;
        }
        // else if (this.tabName == 'learningPath') {
        //     this.filterFields = [
        //         { label: 'Type', value: 'TrainingType' },
        //         { label: 'Other Variables', value: 'Other Variables' },
        //     ];
        //    // this.isAvailablelearningtraining=true;
        // }
        console.log('this.tabName ' + this.tabName + ' includeEnrolledType ' + this.includeEnrolledType);
    }

    handleEnrolledType(event) {
        this.searchValue = '';
        this.selectedField = '';
        this.selectedEnrolledType = event.target.value;

        // if (event.target.value == 'Completed Trainings' || event.target.value == 'Trainings') {
        //     this.filterFields = [
        //         { label: 'Type', value: 'ConductType' },
        //         { label: 'Other Variables', value: 'Other Variables' },
        //     ];
        // } else
        if (//event.target.value == 'Completed Learning paths' || event.target.value == 'Completed Trainings' ||
            event.target.value == 'Trainings' || event.target.value == 'Learning Paths') {
            this.filterFields = [
                { label: 'Name', value: 'TrainingName' },
                { label: 'Type', value: 'TrainingType' },
                { label: 'Priority', value: 'Priority' },
                { label: 'Status', value: 'Status' },
                { label: 'Date', value: 'DueDate' }
            ];

        } else if (event.target.value == 'Completed Learning paths' || event.target.value == 'Completed Trainings') {
            this.filterFields = [
                { label: 'Name', value: 'TrainingName' },
                { label: 'Type', value: 'TrainingType' },
                { label: 'Priority', value: 'Priority' },
                //{ label: 'Status', value: 'Status' },
                { label: 'Date', value: 'DueDate' },
            ];
        }

        console.log('sendDataToDisplay event before firing');
        const typeEvent = new CustomEvent('senddatatodisplay',
            {
                detail: this.selectedEnrolledType
            }
        );
        this.dispatchEvent(typeEvent);
        console.log('sendDataToDisplay event after firing');

    }

    handleField(event) {
        this.hideSearchvalues = false;
        console.log('@@ previous selectedField ' + this.selectedField);
        if (this.selectedField != null && this.selectedField != undefined && this.selectedField != '') {
            this.displayAlldata();
        }

        this.searchValue = '';
        this.selectedField = event.target.value;
        console.log('@@ current selectedField ' + this.selectedField);
        console.log('this.filterFields ' + JSON.stringify(this.filterFields));
        if (this.selectedField == 'TrainingName' && (this.tabName == 'availableTraining' || this.tabName == 'assignedTaining' || this.tabName == 'completedTaining' || this.tabName == 'learningPath')) {
            this.isDateFilter = false;
            this.isPicklistFilter = false;
            this.isInputFilter = true;
        } else if (this.selectedField == 'TrainingType' || this.selectedField == 'ConductType') {
            this.isInputFilter = false;
            this.isDateFilter = false;
            this.isPicklistFilter = true;
            if (this.selectedEnrolledType == 'Completed Trainings' || this.selectedEnrolledType == 'Trainings'
                || this.tabName == "availableTraining") {
                this.getSearchOptions(completedTraingTypeLabel);


            } else if (this.selectedEnrolledType == 'Completed Learning paths' || this.selectedEnrolledType == 'Learning Paths'
                || this.tabName == 'learningPath') {
                this.getSearchOptions(completedTraingTypeLabel);
            }
        } else if (this.selectedField == 'Priority') {
            this.isInputFilter = false;
            this.isDateFilter = false;
            this.isPicklistFilter = true;
            this.getSearchOptions(priorityLabel);
        } else if (this.selectedField == 'Status') {
            this.isInputFilter = false;
            this.isDateFilter = false;
            this.isPicklistFilter = true;
            if (this.tabName == 'assignedTaining') {
                if (this.selectedEnrolledType == 'Trainings') {
                    this.getSearchOptions(statusLabelforEnrolledTrainingTabTrainings);
                } else
                    this.getSearchOptions(statusLabelforEnrolledTrainingTab); //replace this one with new imported cLabel
            }
            else {
                this.getSearchOptions(statusLabel);
            }
        } else if (this.selectedField == 'DueDate') {
            this.isInputFilter = false;
            this.isPicklistFilter = false;
            this.isDateFilter = true;
        } else if (this.selectedField == 'Other Variables') {
            this.hideSearchvalues = true;
            this.isInputFilter = false;
            this.isPicklistFilter = false;
            this.isDateFilter = false;
            this.getSearchOptions('');
        }
    }

    getSearchOptions(optionsString) {
        console.log('optionsString ' + optionsString);
        if (optionsString != null && optionsString != undefined && optionsString != '') {
            var optionsArr = optionsString.split(',');
            var tempArray = [];
            console.log('optionsArr ' + optionsArr.length);
            for (var i = 0; i < optionsArr.length; i++) {
                tempArray.push({ label: optionsArr[i], value: optionsArr[i] });
            }

            this.searchOptionsToDisplay = tempArray;
            console.log('this.searchOptionsToDisplay ' + JSON.stringify(this.searchOptionsToDisplay));
        } else {
            this.searchOptionsToDisplay = [];
            this.displayToast('No values to display for Search', 'error');
        }
    }
    

    handleSearchType(event) {
     console.log('Line 195');
        this.searchValue = event.target.value;
        var filteredData = [];

        console.log('@@ this.selectedField ' + this.selectedField);
        console.log('@@ this.searchValue ' + this.searchValue);
        console.log('@@ this.searchData ' + JSON.stringify(this.searchData));

        if (this.searchData != null && this.searchData != '') {
            if (this.searchValue != null && this.searchValue != undefined && this.searchValue != '') {
                for (var i = 0; i < this.searchData.length; i++) {
                    console.log('this.searchData[i] ' + JSON.stringify(this.searchData[i]));
                    console.log('this.searchData[i]2 ' + this.searchData[i][this.selectedField]);
                    var currentSelectedFieldData;
                    if(this.searchData[i].Status == 'Completed' && (this.TrainingId != null || this.TrainingId != undefined || this.TrainingId != '') && this.selectedField == 'DueDate') {
                         currentSelectedFieldData = this.searchData[i]['CompletedDate'];
                    } else {
                        currentSelectedFieldData = this.searchData[i][this.selectedField];
                    }
                    
                    if (this.selectedField == 'TrainingName') {
                        currentSelectedFieldData = currentSelectedFieldData.toLowerCase();
                        var searchValueLower = this.searchValue.toLowerCase();
                        if (currentSelectedFieldData.includes(searchValueLower)) {
                            filteredData.push(this.searchData[i]);
                        }
                    }
                    console.log('currentSelectedFieldData ' + JSON.stringify(currentSelectedFieldData));
                    console.log('this.selectedField ' + JSON.stringify(this.selectedField));
                    // if (this.searchValue != null && this.searchValue != undefined && this.searchValue != ''
                    //     && this.selectedField == 'TrainingName' && currentSelectedFieldData.includes(this.searchValue)) {
                    //     filteredData.push(this.searchData[i]);}
                    if (this.selectedField == 'Priority') {
                        if (this.searchData[i].isHigh && this.searchValue == 'High') {
                            filteredData.push(this.searchData[i]);
                        } else if (this.searchData[i].isMedium && this.searchValue == 'Medium') {
                            filteredData.push(this.searchData[i]);
                        } else if (this.searchData[i].isLow && this.searchValue == 'Low') {
                            filteredData.push(this.searchData[i]);
                        }
                    }
                    

                    else if (currentSelectedFieldData == this.searchValue) {
                        filteredData.push(this.searchData[i]);
                    }
                }

                /*for (let i = 0; i < this.searchData.length; i++) {
                    // Access the value of 'this.selectedField' for each object
                    let selectedFieldValue = this.searchData[i][this.selectedField];
    
                    // Do something with the selected field value
                    console.log(selectedFieldValue);
                }*/

                console.log('filteredData ' + JSON.stringify(filteredData));
                if (filteredData == null || filteredData.length == 0) {
                    this.displayToast('There is no matching Learning path or training found.', 'warning');
                }

                console.log('before dispatching event');
                const searchEvent = new CustomEvent(this.eventMethod, {
                    detail: {
                        type: this.selectedEnrolledType,
                        filteredData: filteredData
                    }
                });
                this.dispatchEvent(searchEvent);
                console.log('after dispatching event');
            } else {
                this.displayAlldata();
            }
        } else {
            this.displayToast('There is no matching Learning path or training found.', 'warning');
        }
    }

    displayAlldata() {
        const displayAllDataEvent = new CustomEvent('searchfieldchange', {
            detail: {
                tabName: this.tabName,
                enrolledType: this.selectedEnrolledType,
                dataToDisplay: this.searchData,
            }
        });
        this.dispatchEvent(displayAllDataEvent);
    }

    displayToast(message, variant) {
        const toast = new ShowToastEvent({
            message: message,
            variant: variant,
        });
        this.dispatchEvent(toast);
    }

    // normalizeDateFormat(dateString) {
    //     // Normalize date string to a common format
    //     // For example, you can convert it to YYYY-MM-DD format
    //     // You should adjust this function based on your date formats
    //     // For simplicity, let's assume the date format is MM/DD/YYYY

    //     var parts = dateString.split('/');
    //     if (parts.length === 3) {
    //         // Reformat to YYYY-MM-DD format
    //         return parts[2] + '-' + parts[0] + '-' + parts[1];
    //     } else {
    //         // Return original string if unable to parse
    //         return dateString;
    //     }
    // }

}