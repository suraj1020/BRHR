import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getMessage from '@salesforce/apex/BroadcastMessageController.getBroadcastMessage';

export default class BroadCastMessage extends LightningElement {


    connectedCallback()
    {
        getMessage()
        .then(res=>
            {
                res.forEach(element => {
                    this.displayMessage('Company Updates','info',element.Message__c)
                });
            })
    }

    /******************************* Display Toast Message *********************** */
    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'sticky'
        }));
    }
}