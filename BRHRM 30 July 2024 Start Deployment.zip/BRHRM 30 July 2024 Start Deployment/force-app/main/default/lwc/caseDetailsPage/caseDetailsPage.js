import { LightningElement, wire, api } from "lwc";
import { getRecord } from "lightning/uiRecordApi";
import { getObjectInfo } from "lightning/uiObjectInfoApi";
import Case_OBJECT from "@salesforce/schema/Case";
const CaseFields = ['Case.Email__c','Case.Name__c', 'Case.Phone__c','Case.Able_to_Perform_Essential_Job_Functions__c','Case.What_Accommodation_is_affecting_your_job__c','Case.Reason_for_Request__c','Case.How_Would_Accommodation_Improve_Job_Perf__c','Case.Limitation_Type__c','Case.Non_BakerRipley_Location_Name__c','Case.Description_of_Event_Leading_to_Grievanc__c','Case.Employee_Referral__c', 'Case.Proposed_Project_Due_Date__c','Case.Project_Sponsor__c','Case.Third_Party_Staffing__c','Case.E_Par_Change_Reason__c','Case.Paid_Time_Off_Type__c','Case.Which_Department_s_Policy_Procedure__c','Case.LMS_Case_Type__c','Case.Desired_Outcome_s__c','Case.Detailed_Description_of_Request__c','Case.Problem_Opportunity_Statement__c','Case.Project_Name__c','Case.Reason_for_Recruitment__c','Case.Limitation_Type__c','Case.Expected_Graduation__c','Case.Course_Part_of_Degree_Plan__c','Case.Course_Title__c', 'Case.Semester__c','Case.How_Would_Accommodation_Improve_Job_Perf__c','Case.What_Accommodation_is_affecting_your_job__c','Case.Timeframe_for_Limitation_Request__c','Case.Tuition_Fee__c','Case.Able_to_Perform_Essential_Job_Functions__c','Case.Reason_for_Request__c','Case.Training_Requested_For__c','Case.Name_of_School_Institution__c','Case.Date_of_First_Class__c','Case.Course_Outcome__c','Case.Type_of_Degree__c','Case.E_Par_Change_Effective_Date__c','Case.X1099_Contractor__c', 'Case.Department__c','Case.Performance_Type__c','Case.Offboarding_Type__c','Case.Date_Time_of_Event_Leading_to_Grievance__c','Case.Data_Report_Type__c','Case.Access_Type__c', 'Case.Insurances__c','Case.Candidates_Name__c','Case.Retirement_Benefits__c','Case.Sign_of_Abuse_Neglect__c','Case.Case_Type__c','Case.Medical_Benefits__c','Case.Health_Spending_Account__c','Case.Time_Allocation_Type__c','Case.Ambulance_Called__c','Case.Type_of_Illness__c','Case.Type_of_concern__c','Case.Cause_of_injury__c', 'Case.Relationship_to_the_victim__c','Case.Work_Status__c','Case.Provider_Phone__c', 'Case.Provider_Email__c','Case.Trunk__c','Case.Neck__c','Case.Type_of_Medical_Treatment_Provided__c','Case.Type_of_Security_Issue__c','Case.Type_of_Property_Damage__c','Case.Emergency_Services_called__c','Case.Alternative_Duty_Types__c','Case.VIN_Number__c','Case.Seat_Belt_Used__c','Case.Description_of_Damage__c','Case.Ambulance__c','Case.Fire__c','Case.Police__c','Case.Officer_Name__c','Case.Conditions__c', 'Case.Pavement__c','Case.Other_Vehicle_Type__c','Case.Year__c','Case.Make__c','Case.Other_Pavement__c','Case.Other_Conditions__c','Case.Police_Report_filed__c','Case.Badge_Number__c','Case.Report_Number__c','Case.Vehicle_Details__c','Case.Vehicle_Type__c','Case.Model__c','Case.License_Plate_Number__c','Case.Weather__c', 'Case.Other_Weather__c','Case.Facility_incident_Type__c','Case.Type_of_Building_Damage__c', 'Case.Action_Taken__c','Case.Accident__c','Case.Air_Bag_Deployed__c','Case.Provider_Name__c','Case.Provider_Address__c','Case.Did_Injury_result_absence_from_work__c','Case.Date_returned_to_work__c','Case.Medical_Treatment_Provided__c','Case.Upper_Extremities__c', 'Case.Lower_Extremities__c','Case.Multiple_Body_Parts__c','Case.Specify_if_Other_Family_Member__c','Case.Incident_Category__c','Case.Type_Of_Injury__c','Case.X911_Called__c','Case.Type_of_Abuse_Exploitation__c','Case.Case_Submitted__c','Case.Result_of_Abuse__c','Case.Abuser_Name__c','Case.Head_Start_Campus_Name__c','Case.Senior_Centre_Name__c','Case.Charter_School_Name__c','Case.Non_BakerRipley_Location_Name__c','Case.CaseNumber','Case.Subject','Case.Status','Case.Priority','Case.Description','Case.What_Part_of_the_employee_workday__c','Case.Event_Incident_Location__c','Case.Workforce_Career_Office_Name__c','Case.Incident_Date_Time__c','Case.Adminstrative_Office_Name__c','Case.Community_Center_Name__c',];

export default class CaseDetailsPage extends LightningElement {
  @api recordId;

  @wire(getRecord, {
    recordId: "$recordId",
    fields: CaseFields
  })
  caseRecord;

  @wire(getObjectInfo, { objectApiName: Case_OBJECT })
  caseObjectInfo;

  get caseFields() {
    let caseFieldsArray = [],
      key = 0;
    if (this.caseRecord.data && this.caseObjectInfo.data) {
      //console.log("Contact Record Data -->");
      console.log(JSON.stringify(this.caseRecord.data));
      //console.log("Contact Object Info Data -->");
      console.log(JSON.stringify(this.caseObjectInfo.data));

      for (let field in this.caseRecord.data.fields) {
        if (
          Object.prototype.hasOwnProperty.call(
            this.caseRecord.data.fields,
            field
          )
        ) {
          console.log(field);
          caseFieldsArray.push({
            key: key++,
            apiName: field,
            label: this.caseObjectInfo.data.fields[field].label,
            value: this.caseRecord.data.fields[field].value
          });
        }
      }
    }
    return caseFieldsArray;
  }
}