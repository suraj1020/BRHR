import { LightningElement,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import insertPRF from '@salesforce/apex/PerformanceReviewFeedbackController.insertPRF';
export default class PerformanceReviewFeedback extends LightningElement {
    @api prid;
    trainingId;
    name;
    additionalgoals;
    measureofsuccess;
    status;
    startdate;
    enddate;
    get statusoptions() {
        return [
            { label: 'Not Started', value: 'Not Started' },
            { label: 'In Progress', value: 'In Progress' },
            { label: 'Completed', value: 'Completed' },
        ];
    }
    @api isModalOpen;
    handleValueSelectedOnEmployee(event) {
        const selectedId = event.detail.id ? event.detail.id : event.target.value;
        this.trainingId = selectedId;
    }
    
    handleSubmit(){
        var prf = {};
        console.log(this.prid);
        prf.Performance_Review__c = this.prid;
        prf.Learning_and_Development__c = this.trainingId;
        prf.Type__c = 'Additional Goals';
        prf.Measure_of_success__c = this.measureofsuccess;
        prf.Status__c = this.status;
        prf.Start_Date__c = this.startdate;
        prf.End_Date__c = this.enddate;
        prf.Additional_Goal_Description__c =this.additionalgoals;
        prf.name = this.name;
        insertPRF({prf:JSON.stringify(prf)})
        .then(result => {
                console.log(result);
                if(result == 'Success'){
                    this.displayMessage('Success!!','success','Additional Goal is created.');
                this.isModalOpen = false;
                }
                else {
                    this.displayMessage('Error!!','error',result);                
                }
            }
        )
        .catch(error => {});
    }

    displayMessage(title, type, message) {
            this.dispatchEvent(new ShowToastEvent({
                title: title,
                message: message,
                variant: type,
                mode: 'dismissable'
            }));
        }

    handleName(event) {
        this.name = event.target.value;
    }
    handleAdditionalgoals(event) {
        this.additionalgoals = event.target.value;
    }
    handleMeasureOfSuccess(event){
        this.measureofsuccess = event.target.value;
    }
    handleStatus(event){
        this.status = event.detail.value;
    }
    handleStartDate(event){
        this.startdate = event.target.value;
    }
    handleEndDate(event){
        this.enddate = event.target.value;
    }

    closeModal() {
        this.isModalOpen = false;
    }
}