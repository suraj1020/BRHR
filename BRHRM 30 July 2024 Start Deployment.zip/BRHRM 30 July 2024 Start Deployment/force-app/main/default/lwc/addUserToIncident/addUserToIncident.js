import { LightningElement, track, api, wire } from 'lwc';
import createIncidentUsers from '@salesforce/apex/IncidentController.createIncidentUsers';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getPickValues from '@salesforce/apex/IncidentController.getPicklistValues';
import getRecType from '@salesforce/apex/IncidentController.getRecordTypeName';
import SAMPLEMC from "@salesforce/messageChannel/incident__c"
import {subscribe, MessageContext, APPLICATION_SCOPE, unsubscribe,publish} from 'lightning/messageService'

export default class AddUserToIncident extends LightningElement {

    @track options = []
    showTable = true;
    isLoaded = false;
     addInternal = true;
     toggleValue = false

     @wire(MessageContext)
     messageContext;
  
    @api recordId;
    toggleLabel = 'Add External Members'
    @track memberList = [
        { Incident_Member__c: '', Member_Role__c: '', DescriptionLong__c: '', showRemove: false }];
    @track iUser = 
    {
        External_User_Name__c:'',External_User_Phone__c:'',External_User_Email__c:'',External_User_Address__c:'',Member_Role__c:'',DescriptionLong__c:'',isExternal__c:true
    }
    @wire(getRecType, { recId: '$recordId' })
    wiredData({ data, error }) {
        if (data) {
            if (data === 'true') {
                this.showTable = true;
            } else {
                this.showTable = false;
            }
        }
        if (error) {
            this.showTable = false;
            console.log('error', error);

        }
    }



    @wire(getPickValues)
    wiredRole({ data, error }) {
        if (data) {
            this.options = data
        }
        if (error) {
            console.log('error============ > ', error);

        }
    }

    addRow() {
        var newItem = [{ Incident_Member__c: '', Member_Role__c: '', DescriptionLong__c: '', showRemove: true }];

        this.memberList = this.memberList.concat(newItem);
    }

    handleChange(e) {
        this.memberList[e.currentTarget.dataset.id][e.target.dataset.name] = e.target.value;

    }

    handleUserValue(event) {

        let userId = event.detail.id ? event.detail.id : event.target.value;
        this.memberList[event.target.dataset.id][event.target.dataset.name] = userId;
    }

    removeRow(e) {
        this.memberList.splice(e.target.dataset.id, 1);
    }

    handleSave() {


        this.isLoaded = true;
        const allPropertiesFilled = this.memberList.every(item => {
            return Object.values(item).every(value => value !== '' && value !== null);
        });

        if (!allPropertiesFilled) {
            this.displayMessage('Fields are Missing', 'error', 'Please fill all Internal User details')
            this.isLoaded = false
            return;
        }
        else {
            this.saveData();
        }
        this.isLoaded = false
    }

    saveData() {
        if(this.addInternal)
        {
            createIncidentUsers({ payLoad: JSON.stringify(this.memberList), caseId: this.recordId,isInternal:this.addInternal})
            .then(res => {
                this.displayMessage('Success', 'success', 'Members added successfully')
                this.memberList = [{ Incident_Member__c: null, Member_Role__c: null, DescriptionLong__c: '', showRemove: false }];
                this.isLoaded = false
            })
            .catch(error => {
                this.displayMessage('Error Occured', 'error', error.body.message);
                this.isLoaded = false
            }) 
        }
        else
        {
            createIncidentUsers({ payLoad: JSON.stringify(this.iUser), caseId: this.recordId,isInternal:this.addInternal })
            .then(res => {
                this.displayMessage('Success', 'success', 'Members added successfully')
                this.iUser = {
                    External_User_Name__c:'',External_User_Phone__c:'',External_User_Email__c:'',External_User_Address__c:'',Member_Role__c:'',DescriptionLong__c:'',isExternal__c:true
                }
                this.isLoaded = false
            })
            .catch(error => {
                this.displayMessage('Error Occured', 'error', error.body.message);
                this.isLoaded = false
            })
        }

        const messagePayload = {
            isCreated : true
        };
        publish(this.messageContext, SAMPLEMC, messagePayload);
       
    }
    /******************************* Display Toast Message *********************** */
    displayMessage(title, type, message) {
        this.dispatchEvent(new ShowToastEvent({
            title: title,
            message: message,
            variant: type,
            mode: 'dismissable'
        }));
    }


    handleToggle(event) {        
        this.toggleValue = event.target.value?event.target.value:event.detail.checked; 
        if (this.toggleValue) {
          this.addInternal = false;
          this.toggleLabel = 'Add Internal Members'; 
         }
        else {
            this.addInternal = true;
            this.toggleLabel = 'Add External Members';
        }
    }
    handleExternalChange(e)
    {
        this.iUser[e.target.name] = e.target.value;
    }

    handleSaveExternal()
    {
        this.isLoaded = true;
          
        

        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if(!allValid){
            this.displayMessage('Fields are Missing', 'error', 'Please fill all External User details')
            this.isLoaded = false
            return;
        }
        else {
            
             this.saveData();
        }
        this.isLoaded = false 
    }

 

}