import { LightningElement, api,track } from 'lwc';
import getCorrectiveAction from '@salesforce/apex/PerformanceImprovementPlanController.getCorrectiveAction';

export default class CorrectiveActionView extends LightningElement {
    @api recordId;
    pip;
    employeeName;
    dDate;
    correctiveActionLevel;
    RecordType;
    Causation;
    OtherCausation;
    Incident;
    Corrective;
    Statement;
    acknowledgment;
    showManagerComment = false; 
    editMode = false; 

    connectedCallback() {
        console.log(this.recordId);
        getCorrectiveAction({ caId : this.recordId })
            .then((result) => {
                console.log('---- result: ' + JSON.stringify(result));
                this.pip = result;
                this.employeeName = this.pip.Employee_Name__r.Name;
                console.log('---- this.pip.Date__c: ' + this.pip.Date__c);
                this.dDate = this.pip.Date__c;
                this.correctiveActionLevel = this.pip.Corrective_Action_Level__c;
                this.RecordType = this.pip.RecordType.Name;
                this.Causation = this.pip.Causation__c;
                if(this.Causation != undefined && this.pip.Causation__c.includes(';'))
                {
                    this.Causation = this.pip.Causation__c.replaceAll(';', ', ');
                }
                if(this.Causation === 'Others'){
                    this.OtherCausation ='NA';
                }
                else this.OtherCausation = this.pip.Give_Reason_Other__c;

                let incidentDescription = this.pip.Incident_Description_Supporting_Detail__c;
                this.Incident = incidentDescription;
                
                this.Corrective = this.pip.Corrective_Action_Required__c;
                this.Statement = this.pip.Employee_s_Statement__c;
                this.acknowledgment = this.pip.Employee_s_Acknowledgement__c;
            })
            .catch((error) => {
                console.error(error);
            });
    }
}