import { LightningElement, api, track } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class ConfirmationCaseChildPage  extends NavigationMixin (LightningElement) {
    @api caseNumber;

    connectedCallback(){
        console.log('caseNumber-->'+ this.caseNumber);
    }

    // @api 
    // handleDone(){
    //     this[NavigationMixin.Navigate]({
    //         "type": "standard__webPage",
    //         "attributes": {
    //             "url": "/employeeservicesample/s/casehomepage"
    //         }
    //     });
    // }
}