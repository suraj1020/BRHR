import { LightningElement, track, api, wire } from 'lwc';
import { getObjectInfo } from 'lightning/uiObjectInfoApi';
import { getPicklistValues } from 'lightning/uiObjectInfoApi';
import { getPicklistValuesByRecordType } from 'lightning/uiObjectInfoApi';
import Case_Object from '@salesforce/schema/Case';
import ItIncidenType_Field from '@salesforce/schema/Case.IT_Incident_Type__c';
import AffectedSysDevice_Field from '@salesforce/schema/Case.Affected_System_Device_Type__c';
import StepTaken_Field from '@salesforce/schema/Case.Steps_Taken__c';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import createCaseOnSubmit from '@salesforce/apex/CaseCreation.createCaseOnSubmit';
export default class IncidentDetailsITChildPage extends LightningElement {
    @api caseObj = {};
    @track caseIncidentRecordTypeId;
    @track typeOfIncidentoptions = [];
    @track affectedSysDvcoptions = [];
    @track affectedSysDvcoptions1 = [];
    @track stepTakenoptions = [];
    @track lostIncidentType = false;
    showField2;
    //@track sensitiveDatasuspctoptions = [];
    @track yesNoOptions = [
        { label: 'Yes', value: 'Yes' },
        { label: 'No', value: 'No' }
    ];
    showField
    isLoaded = true;
    @api recordTypeName;
    @api currentPage;

    connectedCallback() {
        let obj = JSON.parse(JSON.stringify(this.caseObj));
        this.caseObj = obj;
        if (this.caseObj.hasOwnProperty('Police_Report_filed__c')) {
            if (this.caseObj.Police_Report_filed__c == 'Yes') {
                this.showField = true;
            } else {
                this.showField = false;
            }
        }

        if (this.caseObj.hasOwnProperty('IT_Incident_Type__c')) {
            if(this.caseObj.IT_Incident_Type__c == 'Lost/Stolen Devices') {
                console.log('yes')
                this.lostIncidentType = true;
            }else {
                this.lostIncidentType = false;                
            }
            this.showField2 = true;
        } else {
            this.showField2 = false;
        }
    }


    @wire(getObjectInfo, { objectApiName: Case_Object })
    objectInfo({ data, error }) {
        if (data) {
            const rtis = data.recordTypeInfos;
            Object.keys(rtis).forEach(element => {
                // console.log(rtis[element]);
                if (rtis[element].available && rtis[element].name == 'Incident Related Case') {
                    this.caseIncidentRecordTypeId = rtis[element].recordTypeId;
                }
            });
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: ItIncidenType_Field })
    itTypeOfIncidentPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.typeOfIncidentoptions = [...this.typeOfIncidentoptions, { value: val.value, label: val.label }];
            });
            console.log('this.typeOfIncidentoptions--> ' + JSON.stringify(this.typeOfIncidentoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: AffectedSysDevice_Field })
    aftSysdvcPickValues({ data, error }) {
        if (data) {
            console.log('data affectedSysDvcoptions-->' + JSON.stringify(data.values));
            data.values.forEach(val => {
                this.affectedSysDvcoptions = [...this.affectedSysDvcoptions, { value: val.value, label: val.label }];
                this.affectedSysDvcoptions1 = [...this.affectedSysDvcoptions1, { value: val.value, label: val.label }];
            });
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    @wire(getPicklistValues, { recordTypeId: '$caseIncidentRecordTypeId', fieldApiName: StepTaken_Field })
    stepTakenPickValues({ data, error }) {
        if (data) {
            console.log('data-->' + JSON.stringify(data));
            data.values.forEach(val => {
                this.stepTakenoptions = [...this.stepTakenoptions, { value: val.value, label: val.label }];
            });
            console.log('this.stepTakenoptions--> ' + JSON.stringify(this.stepTakenoptions));
        }
        if (error) {
            console.log('error - ', this.error);
        }
    }

    handleChange(event) {
        this.caseObj[event.target.name] = event.target.value;
        console.log('this.caseObj--> ' + JSON.stringify(this.caseObj));

        if (event.target.name == 'IT_Incident_Type__c') {
            this.showField2 = true;
            if (event.target.value == 'Lost/Stolen Devices') {
                console.log('Yes');
                this.lostIncidentType = true;
                let data = [];
                data = this.affectedSysDvcoptions1.filter(el => el.value != 'Server' && el.value != 'Network' && el.value != 'Website' && el.value != 'Email');
                if (data.length > 0) {
                    this.affectedSysDvcoptions = [...data];
                }
            }
            else {
                this.lostIncidentType = false;
                this.affectedSysDvcoptions = this.affectedSysDvcoptions1;
                this.caseObj.Police_Report_filed__c = null;
                this.caseObj.Officer_Name__c = null;
                this.caseObj.Badge_Number__c = null;
                this.caseObj.Report_Number__c = null;
            }
        }

        if (event.target.name == 'Police_Report_filed__c') {
            if (event.target.value == 'Yes') {
                this.showField = true;
            } else {
                this.showField = false;
                this.caseObj.Date_reported_to_employer__c = '';
                if (this.caseObj.hasOwnProperty('Report_Number__c')) {
                    delete this.caseObj.Report_Number__c;
                }
                if (this.caseObj.hasOwnProperty('Officer_Name__c')) {
                    delete this.caseObj.Officer_Name__c;
                }
                if (this.caseObj.hasOwnProperty('Badge_Number__c')) {
                    delete this.caseObj.Badge_Number__c;
                }
            }
        }
    }

    @api
    handleNext() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid && allCBValid) {
            this.dispatchEvent(new CustomEvent('updatedataa', { detail: this.caseObj }));
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }
    }

    @api handlePrevious() {
        this.dispatchEvent(new CustomEvent('previousclick', { detail: this.caseObj }));
    }

    displayMessage(title, variant, msg) {
        const toastEvent = new ShowToastEvent({
            title: title,
            message: msg,
            variant: variant,
        });
        this.dispatchEvent(toastEvent);
    }

    @api
    handleSaveAndExit() {
        const allValid = [...this.template.querySelectorAll("lightning-input")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        const allCBValid = [...this.template.querySelectorAll("lightning-combobox")].reduce((validSoFar, inputCmp) => {
            inputCmp.reportValidity();
            return validSoFar && inputCmp.checkValidity();
        }, true);
        if (allValid && allCBValid) {
            this.isLoaded = false;
            this.caseObj.Status = 'Draft';
            this.caseObj.CurrentPage__c = this.currentPage;
            createCaseOnSubmit({
                caseObj: this.caseObj,
                fileData: [],
                incidentUserList: [],
                recordTypeName: this.recordTypeName,
                injuryData: [],
                damageData: [],
                courseInformation: []
            })
                .then(result => {
                    if (result) {
                        this.isLoaded = true;
                        console.log('--92--> ' + result);
                        this.displayMessage("Success", "success", "Case saved as draft.");
                        this.dispatchEvent(new CustomEvent('saveexit'));
                    } else {
                        this.isLoaded = true;
                    }
                }).catch(error => {
                    this.displayMessage("Error", "error", reduceErrors(error).toString());
                    this.isLoaded = true;
                })
        } else {
            this.displayMessage("Please check your entries.", "error", "Please fill required fields");
        }

    }

}