({
	doinit : function(component, event, helper) {    //  component, event, helper are parameter                                                                                                of doinit function
       
      var action=  component.get('c.getPrechatData');  // Calling apex method
        action.setCallback(this,function(response)   // getting response back from apex method
        {
           var state=response.getState();            // getting the state
        if(state==='SUCCESS')
        {
            console.log('--------'+response.getReturnValue());// setting the value in attribute
           
        }
                         
                         
        });
  			$A.enqueueAction(action);


 }
})